import React, { createContext, useContext, useState, useEffect, useMemo, useRef } from 'react';
import {
  NavPage,
  Language,
  ThemeMode,
  Surah,
  DevotionalItem,
  Article,
  Scholar,
  Course,
  KidStory,
  MediaDocument,
  AuditLog,
  ActiveAudioTrack,
  BookmarkItem,
  UserNote,
  PrayerTimesData,
  ManagedFileItem,
  FileVersion,
} from '../types';
import { StorageService } from '../services/storageService';
import {
  auth,
  signInWithGoogle,
  signOutFromFirebase,
  testFirestoreConnection,
  FirebaseDataService,
  BOOTSTRAP_ADMIN_EMAIL,
} from '../services/firebase';
import { onAuthStateChanged, User as FirebaseUser } from 'firebase/auth';
import {
  INITIAL_SURAHS,
  INITIAL_HADITHS,
  INITIAL_DEVOTIONALS,
  INITIAL_ARTICLES,
  INITIAL_SCHOLARS,
  INITIAL_COURSES,
  INITIAL_KIDS_STORIES,
  INITIAL_MEDIA_DOCUMENTS,
  INITIAL_AUDIT_LOGS,
} from '../data/initialData';

export interface QuranSettings {
  arabicFontSize: number;
  translationFontSize: number;
  showTranslation: boolean;
  showTransliteration: boolean;
  reciter: string;
  focusMode: boolean;
  hifzMode: boolean;
}

export interface AppContextType {
  activePage: NavPage;
  setActivePage: (page: NavPage) => void;
  language: Language;
  setLanguage: (lang: Language) => void;
  theme: ThemeMode;
  setTheme: (theme: ThemeMode) => void;

  // Quran
  surahs: Surah[];
  selectedSurahNumber: number;
  setSelectedSurahNumber: (num: number) => void;
  quranSettings: QuranSettings;
  updateQuranSettings: (settings: Partial<QuranSettings>) => void;

  // Audio Player
  activeAudioTrack: ActiveAudioTrack | null;
  isPlaying: boolean;
  playAudioTrack: (track: ActiveAudioTrack) => void;
  pauseAudio: () => void;
  togglePlayPause: () => void;
  audioProgress: number;
  audioDuration: number;
  seekAudio: (seconds: number) => void;
  playbackSpeed: number;
  setPlaybackSpeed: (speed: number) => void;

  // Devotionals & Content
  devotionals: DevotionalItem[];
  addDevotionalItem: (item: Omit<DevotionalItem, 'id' | 'createdAt'>) => void;
  updateDevotionalItem: (id: string, updates: Partial<DevotionalItem>) => void;
  deleteDevotionalItem: (id: string) => void;
  publishDevotionalItem: (id: string) => void;
  unpublishDevotionalItem: (id: string) => void;

  articles: Article[];
  addArticle: (item: Omit<Article, 'id'>) => void;
  updateArticle: (id: string, updates: Partial<Article>) => void;
  deleteArticle: (id: string) => void;

  courses: Course[];
  updateCourseProgress: (courseId: string, lessonId: string) => void;

  scholars: Scholar[];
  kidsStories: KidStory[];
  mediaDocs: MediaDocument[];
  addMediaDocument: (doc: Omit<MediaDocument, 'id' | 'uploadedAt' | 'downloadCount'>) => void;
  deleteMediaDocument: (id: string) => void;

  auditLogs: AuditLog[];

  // 16 Categories Managed Files & Storage Engine
  managedFiles: ManagedFileItem[];
  uploadNewFile: (
    data: Omit<ManagedFileItem, 'id' | 'version' | 'previousVersions' | 'uploadDate' | 'updatedDate'>
  ) => void;
  replaceFile: (
    fileId: string,
    newFileData: {
      storagePath: string;
      fileName: string;
      fileSize: string;
      mimeType?: string;
      changeNote?: string;
    },
    publishImmediately?: boolean
  ) => void;
  restoreFileVersion: (fileId: string, versionNumber: number) => void;
  removeFile: (fileId: string) => void;
  updateFileMetadata: (fileId: string, updates: Partial<ManagedFileItem>) => void;
  toggleFilePublish: (fileId: string) => void;
  downloadManagedFile: (fileItem: ManagedFileItem) => void;
  previewManagedFile: (fileItem: ManagedFileItem) => void;

  // Bookmarks & Notes
  bookmarks: BookmarkItem[];
  toggleBookmark: (item: Omit<BookmarkItem, 'date'>) => void;
  isBookmarked: (id: string) => boolean;
  notes: UserNote[];
  addNote: (note: Omit<UserNote, 'id' | 'date'>) => void;
  deleteNote: (id: string) => void;

  // Tasbih
  tasbihCount: number;
  tasbihTarget: number;
  tasbihDhikr: string;
  tasbihTotal: number;
  incrementTasbih: () => void;
  resetTasbih: () => void;
  setTasbihTarget: (target: number) => void;
  setTasbihDhikr: (dhikr: string) => void;

  // Prayer Times & City
  selectedCity: string;
  setSelectedCity: (city: string) => void;
  prayerTimesData: PrayerTimesData;
  nextPrayer: { name: string; time: string; remainingText: string };

  // Global Modals & Controls
  isSearchOpen: boolean;
  openSearch: () => void;
  closeSearch: () => void;
  isChatOpen: boolean;
  openChat: () => void;
  closeChat: () => void;
  activePdfModal: { title: string; author?: string; url: string } | null;
  openPdf: (title: string, url: string, author?: string) => void;
  closePdf: () => void;
  certificateModal: { courseTitle: string; studentName: string; grade: string; dateStr: string } | null;
  openCertificate: (courseTitle: string, studentName?: string) => void;
  closeCertificate: () => void;

  // Admin & Firebase Auth
  adminRole: 'super_admin' | 'admin' | 'editor' | 'scholar';
  setAdminRole: (role: 'super_admin' | 'admin' | 'editor' | 'scholar') => void;
  currentUser: FirebaseUser | null;
  isAuthLoading: boolean;
  isFirestoreConnected: boolean;
  signInGoogle: () => Promise<void>;
  signOutUser: () => Promise<void>;
  purgeOldVersions: (fileId: string) => Promise<void>;

  // Toast
  toast: { message: string; type: 'success' | 'info' | 'warning' } | null;
  showToast: (message: string, type?: 'success' | 'info' | 'warning') => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const PRAYER_SCHEDULES: Record<string, { country: string; times: PrayerTimesData['times'] }> = {
  Mecca: {
    country: 'Saudi Arabia',
    times: { Fajr: '05:04', Sunrise: '06:22', Dhuhr: '12:28', Asr: '15:51', Maghrib: '18:31', Isha: '20:01' },
  },
  Medina: {
    country: 'Saudi Arabia',
    times: { Fajr: '05:06', Sunrise: '06:25', Dhuhr: '12:30', Asr: '15:53', Maghrib: '18:32', Isha: '20:02' },
  },
  Kozhikode: {
    country: 'Kerala, India',
    times: { Fajr: '05:14', Sunrise: '06:26', Dhuhr: '12:31', Asr: '15:47', Maghrib: '18:34', Isha: '19:45' },
  },
  Dubai: {
    country: 'UAE',
    times: { Fajr: '05:08', Sunrise: '06:26', Dhuhr: '12:27', Asr: '15:50', Maghrib: '18:25', Isha: '19:55' },
  },
  Cairo: {
    country: 'Egypt',
    times: { Fajr: '04:36', Sunrise: '06:01', Dhuhr: '12:03', Asr: '15:28', Maghrib: '18:03', Isha: '19:21' },
  },
  Istanbul: {
    country: 'Turkey',
    times: { Fajr: '05:42', Sunrise: '07:08', Dhuhr: '13:12', Asr: '16:24', Maghrib: '19:07', Isha: '20:27' },
  },
  London: {
    country: 'United Kingdom',
    times: { Fajr: '04:28', Sunrise: '06:06', Dhuhr: '12:12', Asr: '15:24', Maghrib: '18:14', Isha: '19:48' },
  },
  'New York': {
    country: 'USA',
    times: { Fajr: '05:41', Sunrise: '07:05', Dhuhr: '13:06', Asr: '16:29', Maghrib: '19:05', Isha: '20:25' },
  },
  'Kuala Lumpur': {
    country: 'Malaysia',
    times: { Fajr: '05:58', Sunrise: '07:11', Dhuhr: '13:19', Asr: '16:25', Maghrib: '19:22', Isha: '20:31' },
  },
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activePage, setActivePage] = useState<NavPage>('home');
  const [language, setLanguage] = useState<Language>('en');
  const [theme, setTheme] = useState<ThemeMode>('light');

  // Synchronize HTML lang and dir attribute for Arabic/Malayalam/English
  useEffect(() => {
    if (language === 'ar') {
      document.documentElement.dir = 'rtl';
      document.documentElement.lang = 'ar';
    } else {
      document.documentElement.dir = 'ltr';
      document.documentElement.lang = language;
    }
  }, [language]);

  // Firebase Auth & Cloud Persistence State
  const [currentUser, setCurrentUser] = useState<FirebaseUser | null>(null);
  const [isAuthLoading, setIsAuthLoading] = useState<boolean>(true);
  const [isFirestoreConnected, setIsFirestoreConnected] = useState<boolean>(false);

  // 16 Categories Managed Files Storage & Database Engine
  const [managedFiles, setManagedFiles] = useState<ManagedFileItem[]>(() => {
    return StorageService.loadFiles();
  });

  useEffect(() => {
    StorageService.saveFiles(managedFiles);
  }, [managedFiles]);

  // Real-time Firebase Auth and Firestore Subscriptions
  useEffect(() => {
    // 1. Check connectivity to Firestore
    testFirestoreConnection().then((ok) => {
      setIsFirestoreConnected(ok);
    });

    // 2. Auth listener
    const unsubAuth = onAuthStateChanged(auth, (user) => {
      setCurrentUser(user);
      setIsAuthLoading(false);
      if (user?.email?.toLowerCase() === BOOTSTRAP_ADMIN_EMAIL.toLowerCase()) {
        setAdminRole('super_admin');
      }
    });

    // 3. Real-time Firestore sync for Managed Files
    const unsubFiles = FirebaseDataService.subscribeToManagedFiles(
      (files) => {
        if (files && files.length > 0) {
          setManagedFiles(files);
        }
      },
      (err) => console.warn('Firestore files sync info:', err)
    );

    // 4. Real-time Firestore sync for Devotionals
    const unsubDevs = FirebaseDataService.subscribeToDevotionals(
      (devs) => {
        if (devs && devs.length > 0) {
          setDevotionals(devs);
        }
      },
      (err) => console.warn('Firestore devotionals sync info:', err)
    );

    // 5. Real-time Firestore sync for Articles
    const unsubArticles = FirebaseDataService.subscribeToArticles(
      (arts) => {
        if (arts && arts.length > 0) {
          setArticles(arts);
        }
      },
      (err) => console.warn('Firestore articles sync info:', err)
    );

    return () => {
      unsubAuth();
      unsubFiles();
      unsubDevs();
      unsubArticles();
    };
  }, []);

  // Quran
  const [surahs] = useState<Surah[]>(INITIAL_SURAHS);
  const [selectedSurahNumber, setSelectedSurahNumber] = useState<number>(1);
  const [quranSettings, setQuranSettings] = useState<QuranSettings>({
    arabicFontSize: 28,
    translationFontSize: 16,
    showTranslation: true,
    showTransliteration: true,
    reciter: 'Mishary Rashid Alafasy',
    focusMode: false,
    hifzMode: false,
  });

  const updateQuranSettings = (settings: Partial<QuranSettings>) => {
    setQuranSettings((prev) => ({ ...prev, ...settings }));
  };

  // Devotionals (Persistent in localStorage)
  const [devotionals, setDevotionals] = useState<DevotionalItem[]>(() => {
    try {
      const saved = localStorage.getItem('noor_devotionals');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return INITIAL_DEVOTIONALS;
  });

  useEffect(() => {
    try {
      localStorage.setItem('noor_devotionals', JSON.stringify(devotionals));
    } catch (e) {
      console.error(e);
    }
  }, [devotionals]);

  // Articles
  const [articles, setArticles] = useState<Article[]>(() => {
    try {
      const saved = localStorage.getItem('noor_articles');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return INITIAL_ARTICLES;
  });

  useEffect(() => {
    try {
      localStorage.setItem('noor_articles', JSON.stringify(articles));
    } catch (e) {
      console.error(e);
    }
  }, [articles]);

  // Courses
  const [courses, setCourses] = useState<Course[]>(() => {
    try {
      const saved = localStorage.getItem('noor_courses');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return INITIAL_COURSES;
  });

  const updateCourseProgress = (courseId: string, lessonId: string) => {
    setCourses((prev) =>
      prev.map((c) => {
        if (c.id !== courseId) return c;
        const updatedLessons = c.lessons.map((l) => (l.id === lessonId ? { ...l, completed: true } : l));
        const completedCount = updatedLessons.filter((l) => l.completed).length;
        const progress = Math.round((completedCount / updatedLessons.length) * 100);
        return { ...c, lessons: updatedLessons, progress, enrolled: true };
      })
    );
  };

  // Scholars & Kids stories
  const [scholars] = useState<Scholar[]>(INITIAL_SCHOLARS);
  const [kidsStories] = useState<KidStory[]>(INITIAL_KIDS_STORIES);

  // Media Documents
  const [mediaDocs, setMediaDocs] = useState<MediaDocument[]>(() => {
    try {
      const saved = localStorage.getItem('noor_media');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return INITIAL_MEDIA_DOCUMENTS;
  });

  useEffect(() => {
    try {
      localStorage.setItem('noor_media', JSON.stringify(mediaDocs));
    } catch (e) {
      console.error(e);
    }
  }, [mediaDocs]);

  // Audit Logs
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(() => {
    try {
      const saved = localStorage.getItem('noor_audit');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return INITIAL_AUDIT_LOGS;
  });

  const addAudit = (action: AuditLog['action'], entity: string, entityTitle: string) => {
    const newLog: AuditLog = {
      id: 'log-' + Date.now(),
      adminName: 'Chief Administrator (Super Admin)',
      action,
      entity,
      entityTitle,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
    };
    setAuditLogs((prev) => [newLog, ...prev]);
  };

  // Devotional CRUD with Cloud Firestore persistence
  const addDevotionalItem = async (item: Omit<DevotionalItem, 'id' | 'createdAt'>) => {
    const newItem: DevotionalItem = {
      ...item,
      id: 'dev-' + Date.now(),
      createdAt: new Date().toISOString().split('T')[0],
    };
    setDevotionals((prev) => [newItem, ...prev]);
    try {
      await FirebaseDataService.saveDevotional(newItem);
    } catch (e) {
      console.error('Failed to sync devotional to Firestore:', e);
    }
    addAudit(newItem.status === 'published' ? 'Published' : 'Created', newItem.category, newItem.title);
    showToast(`"${newItem.title}" added and saved to database.`, 'success');
  };

  const updateDevotionalItem = async (id: string, updates: Partial<DevotionalItem>) => {
    let updatedTarget: DevotionalItem | null = null;
    setDevotionals((prev) =>
      prev.map((it) => {
        if (it.id === id) {
          const updated = { ...it, ...updates };
          updatedTarget = updated;
          addAudit('Updated', updated.category, updated.title);
          return updated;
        }
        return it;
      })
    );
    if (updatedTarget) {
      try {
        await FirebaseDataService.saveDevotional(updatedTarget);
      } catch (e) {
        console.error('Failed to update devotional in Firestore:', e);
      }
    }
    showToast('Devotional item updated in database (old version overwritten).', 'success');
  };

  const deleteDevotionalItem = async (id: string) => {
    const target = devotionals.find((d) => d.id === id);
    if (target) {
      addAudit('Deleted', target.category, target.title);
    }
    setDevotionals((prev) => prev.filter((it) => it.id !== id));
    try {
      await FirebaseDataService.deleteDevotional(id);
    } catch (e) {
      console.error('Failed to delete devotional from Firestore:', e);
    }
    showToast('Item permanently deleted from database.', 'info');
  };

  const publishDevotionalItem = async (id: string) => {
    let updatedTarget: DevotionalItem | null = null;
    setDevotionals((prev) =>
      prev.map((it) => {
        if (it.id === id) {
          const updated = { ...it, status: 'published' as const };
          updatedTarget = updated;
          return updated;
        }
        return it;
      })
    );
    if (updatedTarget) {
      try {
        await FirebaseDataService.saveDevotional(updatedTarget);
      } catch (e) {
        console.error(e);
      }
    }
    const target = devotionals.find((d) => d.id === id);
    if (target) addAudit('Published', target.category, target.title);
    showToast('Published to database and public view.', 'success');
  };

  const unpublishDevotionalItem = async (id: string) => {
    let updatedTarget: DevotionalItem | null = null;
    setDevotionals((prev) =>
      prev.map((it) => {
        if (it.id === id) {
          const updated = { ...it, status: 'draft' as const };
          updatedTarget = updated;
          return updated;
        }
        return it;
      })
    );
    if (updatedTarget) {
      try {
        await FirebaseDataService.saveDevotional(updatedTarget);
      } catch (e) {
        console.error(e);
      }
    }
    const target = devotionals.find((d) => d.id === id);
    if (target) addAudit('Unpublished', target.category, target.title);
    showToast('Item unpublished in database.', 'info');
  };

  // Article CRUD with Cloud Firestore persistence
  const addArticle = async (item: Omit<Article, 'id'>) => {
    const newArt: Article = {
      ...item,
      id: 'art-' + Date.now(),
    };
    setArticles((prev) => [newArt, ...prev]);
    try {
      await FirebaseDataService.saveArticle(newArt);
    } catch (e) {
      console.error('Failed to save article to Firestore:', e);
    }
    addAudit(newArt.status === 'published' ? 'Published' : 'Created', 'Article', newArt.title);
    showToast(`Article "${newArt.title}" created in database.`, 'success');
  };

  const updateArticle = async (id: string, updates: Partial<Article>) => {
    let updatedTarget: Article | null = null;
    setArticles((prev) =>
      prev.map((a) => {
        if (a.id === id) {
          const updated = { ...a, ...updates };
          updatedTarget = updated;
          addAudit('Updated', 'Article', updated.title);
          return updated;
        }
        return a;
      })
    );
    if (updatedTarget) {
      try {
        await FirebaseDataService.saveArticle(updatedTarget);
      } catch (e) {
        console.error('Failed to update article in Firestore:', e);
      }
    }
    showToast('Article updated in database.', 'success');
  };

  const deleteArticle = async (id: string) => {
    const target = articles.find((a) => a.id === id);
    if (target) addAudit('Deleted', 'Article', target.title);
    setArticles((prev) => prev.filter((a) => a.id !== id));
    try {
      await FirebaseDataService.deleteArticle(id);
    } catch (e) {
      console.error('Failed to delete article from Firestore:', e);
    }
    showToast('Article deleted from database.', 'info');
  };

  // Media Document CRUD
  const addMediaDocument = (doc: Omit<MediaDocument, 'id' | 'uploadedAt' | 'downloadCount'>) => {
    const newDoc: MediaDocument = {
      ...doc,
      id: 'med-' + Date.now(),
      downloadCount: 0,
      uploadedAt: new Date().toISOString().split('T')[0],
    };
    setMediaDocs((prev) => [newDoc, ...prev]);
    addAudit('Created', 'Document', newDoc.title);
    showToast(`Media document "${newDoc.title}" uploaded.`, 'success');
  };

  const deleteMediaDocument = (id: string) => {
    const target = mediaDocs.find((m) => m.id === id);
    if (target) addAudit('Deleted', 'Document', target.title);
    setMediaDocs((prev) => prev.filter((m) => m.id !== id));
    showToast('Document deleted.', 'info');
  };

  // Bookmarks
  const [bookmarks, setBookmarks] = useState<BookmarkItem[]>(() => {
    try {
      const saved = localStorage.getItem('noor_bookmarks');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return [
      { id: 'b-1', type: 'quran', title: 'Surah Al-Fatihah', subtitle: 'The Opening · 7 Verses', pathOrRef: 'Surah 1', date: '2026-03-10' },
      { id: 'b-2', type: 'devotional', title: 'Manqoos Maulid', subtitle: 'Shaykh Zainuddin Makhdum', pathOrRef: 'Maulidukal', date: '2026-03-12' },
    ];
  });

  const toggleBookmark = (item: Omit<BookmarkItem, 'date'>) => {
    setBookmarks((prev) => {
      const exists = prev.some((b) => b.id === item.id);
      if (exists) {
        showToast('Bookmark removed', 'info');
        return prev.filter((b) => b.id !== item.id);
      } else {
        showToast('Saved to bookmarks', 'success');
        return [{ ...item, date: new Date().toISOString().split('T')[0] }, ...prev];
      }
    });
  };

  const isBookmarked = (id: string) => bookmarks.some((b) => b.id === id);

  // Notes
  const [notes, setNotes] = useState<UserNote[]>(() => {
    try {
      const saved = localStorage.getItem('noor_notes');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return [
      {
        id: 'n-1',
        title: 'Reflection on Ayatul Kursi',
        surahOrTopic: 'Al-Baqarah 255',
        content: 'Contemplating the name Al-Hayy (The Ever-Living) and Al-Qayyum (The Self-Sustaining upon whom all existence rests).',
        date: '2026-03-12',
      },
    ];
  });

  const addNote = (note: Omit<UserNote, 'id' | 'date'>) => {
    const newNote: UserNote = {
      ...note,
      id: 'note-' + Date.now(),
      date: new Date().toISOString().split('T')[0],
    };
    setNotes((prev) => [newNote, ...prev]);
    showToast('Reflection note saved.', 'success');
  };

  const deleteNote = (id: string) => {
    setNotes((prev) => prev.filter((n) => n.id !== id));
    showToast('Note deleted.', 'info');
  };

  // Tasbih
  const [tasbihCount, setTasbihCount] = useState<number>(() => {
    return Number(localStorage.getItem('noor_tasbih_count') || 0);
  });
  const [tasbihTarget, setTasbihTarget] = useState<number>(33);
  const [tasbihDhikr, setTasbihDhikr] = useState<string>('سُبْحَانَ اللَّهِ (Subhanallah)');
  const [tasbihTotal, setTasbihTotal] = useState<number>(() => {
    return Number(localStorage.getItem('noor_tasbih_total') || 330);
  });

  const incrementTasbih = () => {
    const next = tasbihCount + 1;
    setTasbihCount(next);
    setTasbihTotal((t) => t + 1);
    localStorage.setItem('noor_tasbih_count', String(next));
    localStorage.setItem('noor_tasbih_total', String(tasbihTotal + 1));
  };

  const resetTasbih = () => {
    setTasbihCount(0);
    localStorage.setItem('noor_tasbih_count', '0');
  };

  // Audio Player State & Native Audio Element
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [activeAudioTrack, setActiveAudioTrack] = useState<ActiveAudioTrack | null>(null);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [audioProgress, setAudioProgress] = useState<number>(0);
  const [audioDuration, setAudioDuration] = useState<number>(0);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1);

  useEffect(() => {
    if (!audioRef.current) {
      audioRef.current = new Audio();
      audioRef.current.ontimeupdate = () => {
        if (audioRef.current) {
          setAudioProgress(audioRef.current.currentTime);
        }
      };
      audioRef.current.onloadedmetadata = () => {
        if (audioRef.current) {
          setAudioDuration(audioRef.current.duration || 0);
        }
      };
      audioRef.current.onended = () => {
        setIsPlaying(false);
      };
    }
  }, []);

  const playAudioTrack = (track: ActiveAudioTrack) => {
    setActiveAudioTrack(track);
    if (audioRef.current) {
      audioRef.current.src = track.audioUrl;
      audioRef.current.playbackRate = playbackSpeed;
      audioRef.current.play().then(() => {
        setIsPlaying(true);
      }).catch((err) => {
        console.warn('Playback error or blocked autoplay:', err);
        setIsPlaying(true); // show state active
      });
    }
  };

  const pauseAudio = () => {
    if (audioRef.current) {
      audioRef.current.pause();
    }
    setIsPlaying(false);
  };

  const togglePlayPause = () => {
    if (!audioRef.current) return;
    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current.play().then(() => {
        setIsPlaying(true);
      }).catch(() => {
        setIsPlaying(true);
      });
    }
  };

  const seekAudio = (seconds: number) => {
    if (audioRef.current) {
      audioRef.current.currentTime = seconds;
      setAudioProgress(seconds);
    }
  };

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.playbackRate = playbackSpeed;
    }
  }, [playbackSpeed]);

  // Prayer Times Calculator
  const [selectedCity, setSelectedCity] = useState<string>('Mecca');
  const prayerTimesData: PrayerTimesData = useMemo(() => {
    const config = PRAYER_SCHEDULES[selectedCity] || PRAYER_SCHEDULES['Mecca'];
    return {
      city: selectedCity,
      country: config.country,
      dateStr: new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' }),
      hijriDateStr: 'Ramadan 28, 1447 AH',
      times: config.times,
    };
  }, [selectedCity]);

  // Next Prayer calculation
  const nextPrayer = useMemo(() => {
    const times = prayerTimesData.times;
    const now = new Date();
    const currentMinutes = now.getHours() * 60 + now.getMinutes();

    const prayerOrder: Array<{ name: string; timeStr: string }> = [
      { name: 'Fajr', timeStr: times.Fajr },
      { name: 'Sunrise', timeStr: times.Sunrise },
      { name: 'Dhuhr', timeStr: times.Dhuhr },
      { name: 'Asr', timeStr: times.Asr },
      { name: 'Maghrib', timeStr: times.Maghrib },
      { name: 'Isha', timeStr: times.Isha },
    ];

    for (const p of prayerOrder) {
      const [h, m] = p.timeStr.split(':').map(Number);
      const prayerMinutes = h * 60 + m;
      if (prayerMinutes > currentMinutes) {
        const diff = prayerMinutes - currentMinutes;
        const diffHours = Math.floor(diff / 60);
        const diffMins = diff % 60;
        return {
          name: p.name,
          time: p.timeStr,
          remainingText: diffHours > 0 ? `in ${diffHours}h ${diffMins}m` : `in ${diffMins}m`,
        };
      }
    }
    // After Isha -> next is tomorrow's Fajr
    return {
      name: 'Fajr (Tomorrow)',
      time: times.Fajr,
      remainingText: 'at dawn',
    };
  }, [prayerTimesData]);

  // 16 Categories Managed Files Handlers with Live Cloud Firestore Persistence
  // USER MANDATE: "IF ADMIN CHANGES AN CHANGE THAT SHOULD CHANGE IN DATABASE, AND OLD WILL BEDELETED"
  const uploadNewFile = async (
    data: Omit<ManagedFileItem, 'id' | 'version' | 'previousVersions' | 'uploadDate' | 'updatedDate'>
  ) => {
    const today = new Date().toISOString().split('T')[0];
    const newFile: ManagedFileItem = {
      ...data,
      id: 'file-' + Date.now(),
      version: 1,
      previousVersions: [],
      uploadDate: today,
      updatedDate: today,
    };
    setManagedFiles((prev) => [newFile, ...prev]);
    try {
      await FirebaseDataService.addManagedFile(newFile);
    } catch (e) {
      console.error('Failed to add file to Firestore:', e);
    }
    addAudit('Created', 'File Storage', `${data.title} (${data.category})`);
    showToast(
      language === 'ml'
        ? 'പുതിയ ഫയൽ ഡാറ്റാബേസിൽ വിജയകരമായി അപ്‌ലോഡ് ചെയ്തു!'
        : language === 'ar'
        ? 'تم رفع وحفظ الملف بنجاح في قاعدة البيانات!'
        : 'New file successfully uploaded and saved to database!',
      'success'
    );
  };

  /**
   * CRITICAL ADMIN CHANGE RULE:
   * When admin replaces a file, changes are written to the database,
   * AND the old version is deleted/purged completely (previousVersions = []).
   */
  const replaceFile = async (
    fileId: string,
    newFileData: {
      storagePath: string;
      fileName: string;
      fileSize: string;
      mimeType?: string;
      changeNote?: string;
    },
    publishImmediately: boolean = true
  ) => {
    const today = new Date().toISOString().split('T')[0];

    // Update state immediately: overwrite file and delete/purge old versions
    setManagedFiles((prev) =>
      prev.map((item) => {
        if (item.id !== fileId) return item;

        const updated: ManagedFileItem = {
          ...item,
          version: item.version + 1,
          storagePath: newFileData.storagePath,
          fileName: newFileData.fileName,
          fileSize: newFileData.fileSize,
          mimeType: newFileData.mimeType || item.mimeType,
          updatedDate: today,
          status: publishImmediately ? 'published' : 'draft',
          publicVisibility: publishImmediately,
          // CRITICAL: Old versions are deleted as mandated by the user
          previousVersions: [],
          lastReplacedNote: newFileData.changeNote || `Updated with ${newFileData.fileName}. Old version purged from database.`,
        };

        return updated;
      })
    );

    // Commit change to Firestore and delete old versions in the document
    try {
      await FirebaseDataService.replaceManagedFileAndPurgeOld(fileId, newFileData, publishImmediately);
    } catch (e) {
      console.error('Failed to replace file in Firestore:', e);
    }

    addAudit('Updated', 'File Storage', `Replaced ${fileId} in database (old version deleted)`);
    showToast(
      language === 'ml'
        ? 'ഡാറ്റാബേസിൽ ഫയൽ റീപ്ലേസ് ചെയ്തു! പഴയ വേർഷൻ നീക്കം ചെയ്തു.'
        : language === 'ar'
        ? 'تم تحديث الملف في قاعدة البيانات وحذف النسخة القديمة نهائياً!'
        : 'Database updated with new file! Old version deleted.',
      'success'
    );
  };

  const purgeOldVersions = async (fileId: string) => {
    setManagedFiles((prev) =>
      prev.map((item) => {
        if (item.id !== fileId) return item;
        return { ...item, previousVersions: [] };
      })
    );
    try {
      await FirebaseDataService.purgeOldVersions(fileId);
    } catch (e) {
      console.error('Failed to purge old versions in Firestore:', e);
    }
    showToast('Old versions permanently deleted from database.', 'info');
  };

  const restoreFileVersion = (fileId: string, versionNumber: number) => {
    const today = new Date().toISOString().split('T')[0];
    setManagedFiles((prev) =>
      prev.map((item) => {
        if (item.id !== fileId) return item;

        const targetHistorical = item.previousVersions.find((v) => v.versionNumber === versionNumber);
        if (!targetHistorical) return item;

        const currentActiveAsBackup: FileVersion = {
          versionNumber: item.version,
          fileName: item.fileName,
          storagePath: item.storagePath,
          fileSize: item.fileSize,
          updatedDate: item.updatedDate,
          uploadedBy: item.uploadedBy,
          changeNote: `Archived prior to restoring v${versionNumber}`,
          statusAtTime: item.status,
        };

        const remainingVersions = item.previousVersions.filter((v) => v.versionNumber !== versionNumber);

        const restored: ManagedFileItem = {
          ...item,
          version: item.version + 1,
          fileName: targetHistorical.fileName,
          storagePath: targetHistorical.storagePath,
          fileSize: targetHistorical.fileSize,
          updatedDate: today,
          status: 'published',
          publicVisibility: true,
          previousVersions: [currentActiveAsBackup, ...remainingVersions],
        };

        // Also persist restored file to Firestore
        FirebaseDataService.updateManagedFile(fileId, {
          fileName: restored.fileName,
          storagePath: restored.storagePath,
          fileSize: restored.fileSize,
          version: restored.version,
          status: 'published',
          publicVisibility: true,
          previousVersions: restored.previousVersions,
        }).catch(console.error);

        return restored;
      })
    );

    addAudit('Updated', 'File Storage', `Restored v${versionNumber} for ${fileId}`);
    showToast(`Version ${versionNumber} restored to active state in database.`, 'success');
  };

  const removeFile = async (fileId: string) => {
    const item = managedFiles.find((f) => f.id === fileId);
    setManagedFiles((prev) => prev.filter((f) => f.id !== fileId));
    try {
      await FirebaseDataService.deleteManagedFile(fileId);
    } catch (e) {
      console.error('Failed to delete file from Firestore:', e);
    }
    if (item) {
      addAudit('Deleted', 'File Storage', `${item.title} (${item.category})`);
    }
    showToast(
      language === 'ml'
        ? 'ഫയൽ ഡാറ്റാബേസിൽ നിന്നും സ്ഥിരമായി നീക്കം ചെയ്തു.'
        : language === 'ar'
        ? 'تم حذف الملف من قاعدة البيانات والتخزين!'
        : 'File permanently deleted from database.',
      'info'
    );
  };

  const updateFileMetadata = async (fileId: string, updates: Partial<ManagedFileItem>) => {
    const today = new Date().toISOString().split('T')[0];
    setManagedFiles((prev) =>
      prev.map((item) => {
        if (item.id !== fileId) return item;
        return {
          ...item,
          ...updates,
          updatedDate: today,
        };
      })
    );
    try {
      await FirebaseDataService.updateManagedFile(fileId, updates);
    } catch (e) {
      console.error('Failed to update file in Firestore:', e);
    }
    addAudit('Updated', 'File Storage', `Updated metadata in database for ${fileId}`);
    showToast(
      language === 'ml'
        ? 'ഡാറ്റാബേസിൽ ഫയൽ വിവരങ്ങൾ അപ്ഡേറ്റ് ചെയ്തു.'
        : language === 'ar'
        ? 'تم تحديث البيانات في قاعدة البيانات بنجاح!'
        : 'Database updated successfully with new changes.',
      'success'
    );
  };

  const toggleFilePublish = async (fileId: string) => {
    const item = managedFiles.find((f) => f.id === fileId);
    if (!item) return;
    const newStatus = item.status === 'published' ? 'draft' : 'published';
    const isPublic = newStatus === 'published';
    setManagedFiles((prev) =>
      prev.map((item) => {
        if (item.id !== fileId) return item;
        return {
          ...item,
          status: newStatus,
          publicVisibility: isPublic,
          updatedDate: new Date().toISOString().split('T')[0],
        };
      })
    );
    try {
      await FirebaseDataService.updateManagedFile(fileId, {
        status: newStatus,
        publicVisibility: isPublic,
      });
    } catch (e) {
      console.error(e);
    }
  };

  // Google Sign-In & Sign-Out handlers
  const signInGoogle = async () => {
    try {
      const user = await signInWithGoogle();
      if (user) {
        showToast(
          user.email?.toLowerCase() === BOOTSTRAP_ADMIN_EMAIL.toLowerCase()
            ? `Signed in as Super Admin (${user.email}). Database sync active.`
            : `Signed in as ${user.displayName || user.email}.`,
          'success'
        );
      }
    } catch (e: any) {
      console.warn('Sign-in notice:', e?.message || e);
      showToast(
        e?.message?.includes('blocked')
          ? 'Pop-up blocked by browser. Please allow pop-ups or open the app in a new browser tab to sign in.'
          : (e?.message || 'Google sign-in was not completed.'),
        'warning'
      );
    }
  };

  const signOutUser = async () => {
    try {
      await signOutFromFirebase();
      showToast('Signed out from Firebase.', 'info');
    } catch (e) {
      console.error('Sign-out error:', e);
    }
  };

  const downloadManagedFile = (fileItem: ManagedFileItem) => {
    StorageService.downloadFile(fileItem);
    showToast(
      language === 'ml' ? `ഡൗൺലോഡ് ചെയ്യുന്നു: ${fileItem.fileName}` : `Downloading ${fileItem.fileName}`,
      'info'
    );
  };

  const previewManagedFile = (fileItem: ManagedFileItem) => {
    if (fileItem.fileType === 'pdf') {
      openPdf(fileItem.title, fileItem.storagePath, fileItem.author);
    } else if (fileItem.fileType === 'audio') {
      playAudioTrack({
        id: fileItem.id,
        title: fileItem.title,
        subtitle: fileItem.author || fileItem.category,
        arabicTitle: fileItem.titleArabic,
        audioUrl: fileItem.storagePath,
        category: fileItem.category,
      });
    } else {
      window.open(fileItem.storagePath, '_blank');
    }
  };

  // Modals & UI Controls
  const [isSearchOpen, setIsSearchOpen] = useState<boolean>(false);
  const openSearch = () => setIsSearchOpen(true);
  const closeSearch = () => setIsSearchOpen(false);

  const [isChatOpen, setIsChatOpen] = useState<boolean>(false);
  const openChat = () => setIsChatOpen(true);
  const closeChat = () => setIsChatOpen(false);

  const [activePdfModal, setActivePdfModal] = useState<{ title: string; author?: string; url: string } | null>(null);
  const openPdf = (title: string, url: string, author?: string) => {
    setActivePdfModal({ title, url, author });
  };
  const closePdf = () => setActivePdfModal(null);

  const [certificateModal, setCertificateModal] = useState<{ courseTitle: string; studentName: string; grade: string; dateStr: string } | null>(null);
  const openCertificate = (courseTitle: string, studentName = 'Dedicated Seeker') => {
    setCertificateModal({
      courseTitle,
      studentName,
      grade: 'Distinction (Mumtaz)',
      dateStr: new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }),
    });
  };
  const closeCertificate = () => setCertificateModal(null);

  // Admin Role
  const [adminRole, setAdminRole] = useState<'super_admin' | 'admin' | 'editor' | 'scholar'>('super_admin');

  // Toast
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'info' | 'warning' } | null>(null);
  const showToast = (message: string, type: 'success' | 'info' | 'warning' = 'success') => {
    setToast({ message, type });
    setTimeout(() => {
      setToast((prev) => (prev?.message === message ? null : prev));
    }, 4000);
  };

  // Keyboard shortcut Ctrl+K for search
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsSearchOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <AppContext.Provider
      value={{
        activePage,
        setActivePage,
        language,
        setLanguage,
        theme,
        setTheme,
        surahs,
        selectedSurahNumber,
        setSelectedSurahNumber,
        quranSettings,
        updateQuranSettings,
        activeAudioTrack,
        isPlaying,
        playAudioTrack,
        pauseAudio,
        togglePlayPause,
        audioProgress,
        audioDuration,
        seekAudio,
        playbackSpeed,
        setPlaybackSpeed,
        devotionals,
        addDevotionalItem,
        updateDevotionalItem,
        deleteDevotionalItem,
        publishDevotionalItem,
        unpublishDevotionalItem,
        articles,
        addArticle,
        updateArticle,
        deleteArticle,
        courses,
        updateCourseProgress,
        scholars,
        kidsStories,
        mediaDocs,
        addMediaDocument,
        deleteMediaDocument,
        auditLogs,
        managedFiles,
        uploadNewFile,
        replaceFile,
        restoreFileVersion,
        removeFile,
        updateFileMetadata,
        toggleFilePublish,
        downloadManagedFile,
        previewManagedFile,
        bookmarks,
        toggleBookmark,
        isBookmarked,
        notes,
        addNote,
        deleteNote,
        tasbihCount,
        tasbihTarget,
        tasbihDhikr,
        tasbihTotal,
        incrementTasbih,
        resetTasbih,
        setTasbihTarget,
        setTasbihDhikr,
        selectedCity,
        setSelectedCity,
        prayerTimesData,
        nextPrayer,
        isSearchOpen,
        openSearch,
        closeSearch,
        isChatOpen,
        openChat,
        closeChat,
        activePdfModal,
        openPdf,
        closePdf,
        certificateModal,
        openCertificate,
        closeCertificate,
        adminRole,
        setAdminRole,
        currentUser,
        isAuthLoading,
        isFirestoreConnected,
        signInGoogle,
        signOutUser,
        purgeOldVersions,
        toast,
        showToast,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within an AppProvider');
  return context;
};
