import { ManagedFileItem, FileVersion, ManagedCategory } from '../types/storage';

const STORAGE_KEY = 'noor_managed_files_db_v2';

export const INITIAL_MANAGED_FILES: ManagedFileItem[] = [
  // 1. Maulid PDFs (Includes the user's specific example: Maulid Manqoos)
  {
    id: 'file-maulid-manqoos',
    title: 'Maulid Manqoos',
    titleArabic: 'المولود المنقوص',
    titleMalayalam: 'മൻഖൂസ് മൗലിദ്',
    description: 'The historic devotional ode composed by Shaykh Zayn al-Din Makhdoom I of Ponnani, recited for protection, solace, and spiritual blessings.',
    category: 'maulid-pdf',
    language: 'ar',
    author: 'Shaykh Zayn al-Din Makhdoom I (Ponnani)',
    storagePath: 'https://archive.org/download/ManqoosMawlid/Manqoos%20Mawlid.pdf',
    fileName: 'maulid-manqoos-verified.pdf',
    fileType: 'pdf',
    mimeType: 'application/pdf',
    fileSize: '3.4 MB',
    version: 2,
    uploadedBy: 'Admin / Editorial Board',
    uploadDate: '2026-08-12',
    updatedDate: '2026-09-17',
    status: 'published',
    publicVisibility: true,
    previousVersions: [
      {
        versionNumber: 1,
        fileName: 'maulid-manqoos-old.pdf',
        storagePath: 'https://archive.org/download/ManqoosMawlid/Manqoos%20Mawlid.pdf',
        fileSize: '3.1 MB',
        updatedDate: '2026-08-12',
        uploadedBy: 'Chief Editor',
        changeNote: 'Initial manuscript digitization from traditional Ponnani print.',
      },
    ],
    metadata: {
      associatedItemSlug: 'maulid-manqoos',
      pageCount: 32,
      publisher: 'Maktabah Noor Ponnani Edition',
      downloadCount: 1420,
    },
  },
  {
    id: 'file-maulid-sharafal-anam',
    title: 'Sharaf al-Anam Maulid',
    titleArabic: 'شرف الأنام في مولد خير الأنام',
    titleMalayalam: 'ശറഫുൽ അനാം മൗലിദ്',
    description: 'Classical panegyric ode celebrating the birth, qualities, and virtues of the Holy Prophet Muhammad ﷺ with poetic baiths.',
    category: 'maulid-pdf',
    language: 'ar',
    author: 'Shaykh Ibn al-Jawzi / Classical Tradition',
    storagePath: 'https://archive.org/download/sharaf-al-anam/sharaf-al-anam.pdf',
    fileName: 'sharafal-anam-manuscript.pdf',
    fileType: 'pdf',
    mimeType: 'application/pdf',
    fileSize: '4.2 MB',
    version: 1,
    uploadedBy: 'Admin',
    uploadDate: '2026-08-15',
    updatedDate: '2026-08-15',
    status: 'published',
    publicVisibility: true,
    previousVersions: [],
    metadata: {
      associatedItemSlug: 'sharafal-anam',
      pageCount: 48,
      downloadCount: 980,
    },
  },
  {
    id: 'file-subhana-maulid',
    title: 'Subhana Maulid',
    titleArabic: 'مولد سبحان من خص',
    titleMalayalam: 'സുബ്ഹാന മൗലിദ്',
    description: 'Rhythmic and spiritually uplifting Rabi al-Awwal devotional celebrating the creation of the Prophetic Light.',
    category: 'maulid-pdf',
    language: 'ar',
    author: 'Classical Scholar Tradition',
    storagePath: 'https://archive.org/download/subhana-mawlid/subhana-mawlid.pdf',
    fileName: 'subhana-maulid-print.pdf',
    fileType: 'pdf',
    mimeType: 'application/pdf',
    fileSize: '2.8 MB',
    version: 1,
    uploadedBy: 'Admin',
    uploadDate: '2026-08-20',
    updatedDate: '2026-08-20',
    status: 'published',
    publicVisibility: true,
    previousVersions: [],
    metadata: {
      associatedItemSlug: 'subhana-mawlid',
      pageCount: 28,
      downloadCount: 650,
    },
  },

  // 2. Qur’an PDFs
  {
    id: 'file-quran-mushaf-madinah',
    title: 'Noble Qur’an - Madinah Mushaf (Uthmani Script)',
    titleArabic: 'مصحف المدينة المنورة بالرسم العثماني',
    titleMalayalam: 'വിശുദ്ധ ഖുർആൻ - മദീന മുസ്ഹഫ്',
    description: 'High-resolution King Fahd Glorious Quran Printing Complex authorized digital Mushaf with verified Tajweed markings.',
    category: 'quran-pdf',
    language: 'ar',
    author: 'King Fahd Glorious Quran Printing Complex',
    storagePath: 'https://archive.org/download/Quran-Mushaf-Madinah-HighRes/Madinah_Mushaf.pdf',
    fileName: 'mushaf-madinah-uthmani.pdf',
    fileType: 'pdf',
    mimeType: 'application/pdf',
    fileSize: '78.5 MB',
    version: 1,
    uploadedBy: 'Super Admin',
    uploadDate: '2026-07-01',
    updatedDate: '2026-07-01',
    status: 'published',
    publicVisibility: true,
    previousVersions: [],
    metadata: {
      pageCount: 604,
      downloadCount: 5420,
    },
  },

  // 3. Qur’an translations
  {
    id: 'file-quran-translation-malayalam',
    title: 'Holy Qur’an Malayalam Translation',
    titleArabic: 'ترجمة معاني القرآن الكريم باللغة المليبارية',
    titleMalayalam: 'വിശുദ്ധ ഖുർആൻ മലയാള വിവർത്തനം',
    description: 'Authentic Malayalam translation and explanatory footnotes by Cheriyamundam Abdul Hameed & Kunhi Mohammed Parappoor.',
    category: 'quran-translation',
    language: 'ml',
    author: 'Cheriyamundam Abdul Hameed Madani & Kunhi Mohammed Parappoor',
    storagePath: 'https://archive.org/download/QuranMalayalamTranslation/QuranMalayalam.pdf',
    fileName: 'quran-malayalam-translation.pdf',
    fileType: 'pdf',
    mimeType: 'application/pdf',
    fileSize: '32.1 MB',
    version: 1,
    uploadedBy: 'Admin',
    uploadDate: '2026-07-10',
    updatedDate: '2026-07-10',
    status: 'published',
    publicVisibility: true,
    previousVersions: [],
    metadata: {
      pageCount: 840,
      downloadCount: 3120,
    },
  },
  {
    id: 'file-quran-translation-english',
    title: 'The Clear Quran / Saheeh International Translation',
    titleArabic: 'ترجمة صحيح إنترناشيونال للقرآن الكريم',
    titleMalayalam: 'ഖുർആൻ ഇംഗ്ലീഷ് വിവർത്തനം',
    description: 'Accurate and modern English translation of the meanings of the Noble Qur’an.',
    category: 'quran-translation',
    language: 'en',
    author: 'Saheeh International / Dr. Mustafa Khattab',
    storagePath: 'https://archive.org/download/SaheehInternationalQuran/Saheeh_Quran.pdf',
    fileName: 'quran-english-saheeh.pdf',
    fileType: 'pdf',
    mimeType: 'application/pdf',
    fileSize: '18.4 MB',
    version: 1,
    uploadedBy: 'Admin',
    uploadDate: '2026-07-15',
    updatedDate: '2026-07-15',
    status: 'published',
    publicVisibility: true,
    previousVersions: [],
    metadata: {
      pageCount: 650,
      downloadCount: 2890,
    },
  },

  // 4. Tafsir PDFs
  {
    id: 'file-tafsir-ibn-kathir',
    title: 'Tafsir al-Qur’an al-Azim (Tafsir Ibn Kathir)',
    titleArabic: 'تفسير القرآن العظيم للإمام ابن كثير',
    titleMalayalam: 'തഫ്സീർ ഇബ്നു കസീർ',
    description: 'The monumental primary commentary on the Qur’an connecting verses with hadiths, companion sayings, and Arabic linguistic analysis.',
    category: 'tafsir-pdf',
    language: 'ar',
    author: 'Al-Hafiz Ibn Kathir ad-Dimashqi',
    storagePath: 'https://archive.org/download/TafseerIbnKatheer/Tafseer_Ibn_Katheer.pdf',
    fileName: 'tafsir-ibn-kathir-complete.pdf',
    fileType: 'pdf',
    mimeType: 'application/pdf',
    fileSize: '45.0 MB',
    version: 1,
    uploadedBy: 'Scholar Admin',
    uploadDate: '2026-07-22',
    updatedDate: '2026-07-22',
    status: 'published',
    publicVisibility: true,
    previousVersions: [],
    metadata: {
      pageCount: 1400,
      downloadCount: 1840,
    },
  },

  // 5. Swalath PDFs
  {
    id: 'file-dalail-al-khayrat',
    title: 'Dala’il al-Khayrat wa Shawariq al-Anwar',
    titleArabic: 'دلائل الخيرات وشوارق الأنوار',
    titleMalayalam: 'ദലാഇലുൽ ഖൈറാത്ത്',
    description: 'The renowned classical compilation of salutations and blessings upon the Beloved Messenger ﷺ by Imam al-Jazuli.',
    category: 'swalath-pdf',
    language: 'ar',
    author: 'Imam Muhammad bin Sulayman al-Jazuli',
    storagePath: 'https://archive.org/download/DalailAlKhairat_201608/Dalail_Al_Khairat.pdf',
    fileName: 'dalail-al-khayrat-illuminated.pdf',
    fileType: 'pdf',
    mimeType: 'application/pdf',
    fileSize: '12.8 MB',
    version: 1,
    uploadedBy: 'Admin',
    uploadDate: '2026-08-01',
    updatedDate: '2026-08-01',
    status: 'published',
    publicVisibility: true,
    previousVersions: [],
    metadata: {
      associatedItemSlug: 'swalath-fatih',
      pageCount: 160,
      downloadCount: 2450,
    },
  },

  // 6. Baith / Mala PDFs
  {
    id: 'file-qasida-burdah',
    title: 'Qasidat al-Burdah (Al-Kawakib ad-Durriyyah)',
    titleArabic: 'قصيدة البردة الشريفة للإمام البوصيري',
    titleMalayalam: 'ഖസീദത്തുൽ ബുർദ',
    description: 'Imam Sharaf al-Din al-Busiri’s timeless ode of praise and longing for the Prophet Muhammad ﷺ, featuring all 160 couplets.',
    category: 'baith-mala-pdf',
    language: 'ar',
    author: 'Imam Sharaf al-Din al-Busiri',
    storagePath: 'https://archive.org/download/QasidaBurdahShareef/QasidaBurdah.pdf',
    fileName: 'qasida-burdah-manuscript.pdf',
    fileType: 'pdf',
    mimeType: 'application/pdf',
    fileSize: '5.6 MB',
    version: 1,
    uploadedBy: 'Admin',
    uploadDate: '2026-08-05',
    updatedDate: '2026-08-05',
    status: 'published',
    publicVisibility: true,
    previousVersions: [],
    metadata: {
      associatedItemSlug: 'baith-burdah',
      pageCount: 40,
      downloadCount: 3900,
    },
  },
  {
    id: 'file-muhiyidheen-mala',
    title: 'Muhiyidheen Mala',
    titleArabic: 'منقبة الشيخ عبد القادر الجيلاني (محي الدين مالا)',
    titleMalayalam: 'മുഹ്‌യിദ്ദീൻ മാല',
    description: 'The foundational 1607 CE devotional poem composed in Arabi-Malayalam praising Ghawth al-Azam Shaykh Abdul Qadir al-Jilani.',
    category: 'baith-mala-pdf',
    language: 'ml',
    author: 'Qadi Muhammad al-Kaliyath (Kozhikode, 1607 CE)',
    storagePath: 'https://archive.org/download/muhiyidheen-mala/muhiyidheen-mala.pdf',
    fileName: 'muhiyidheen-mala-v1.pdf',
    fileType: 'pdf',
    mimeType: 'application/pdf',
    fileSize: '3.2 MB',
    version: 1,
    uploadedBy: 'Heritage Board',
    uploadDate: '2026-08-10',
    updatedDate: '2026-08-10',
    status: 'published',
    publicVisibility: true,
    previousVersions: [],
    metadata: {
      associatedItemSlug: 'muhiyidheen-mala',
      pageCount: 24,
      downloadCount: 1650,
    },
  },

  // 7. Ratheeb PDFs
  {
    id: 'file-ratheeb-al-haddad',
    title: 'Ratheeb al-Haddad',
    titleArabic: 'راتب الإمام عبد الله بن علوي الحداد',
    titleMalayalam: 'റാത്തീബുൽ ഹദ്ദാദ്',
    description: 'Litany composed by Qutb al-Irshad Imam Abdullah bin Alawi al-Haddad for spiritual fortification, daily peace, and preservation of faith.',
    category: 'ratheeb-pdf',
    language: 'ar',
    author: 'Imam Abdullah bin Alawi al-Haddad',
    storagePath: 'https://archive.org/download/ratib-al-haddad/ratib-al-haddad.pdf',
    fileName: 'ratheeb-al-haddad-verified.pdf',
    fileType: 'pdf',
    mimeType: 'application/pdf',
    fileSize: '2.1 MB',
    version: 1,
    uploadedBy: 'Admin',
    uploadDate: '2026-08-12',
    updatedDate: '2026-08-12',
    status: 'published',
    publicVisibility: true,
    previousVersions: [],
    metadata: {
      associatedItemSlug: 'ratheeb-haddad',
      pageCount: 16,
      downloadCount: 4210,
    },
  },

  // 8. Dua & Dhikr PDFs
  {
    id: 'file-hizb-al-bahr',
    title: 'Hizb al-Bahr (Litany of the Sea)',
    titleArabic: 'حزب البحر للإمام أبي الحسن الشاذلي',
    titleMalayalam: 'ഹിസ്ബുൽ ബഹ്റ്',
    description: 'Revered spiritual litany of divine protection, relief from difficulty, and safety transmitted by Imam Abu al-Hasan ash-Shadhili.',
    category: 'dua-dhikr-pdf',
    language: 'ar',
    author: 'Imam Abu al-Hasan ash-Shadhili',
    storagePath: 'https://archive.org/download/hizb-al-bahr/hizb-al-bahr.pdf',
    fileName: 'hizb-al-bahr-dua.pdf',
    fileType: 'pdf',
    mimeType: 'application/pdf',
    fileSize: '1.9 MB',
    version: 1,
    uploadedBy: 'Admin',
    uploadDate: '2026-08-14',
    updatedDate: '2026-08-14',
    status: 'published',
    publicVisibility: true,
    previousVersions: [],
    metadata: {
      pageCount: 12,
      downloadCount: 2190,
    },
  },

  // 9. Islamic books
  {
    id: 'file-fathul-mueen',
    title: 'Fath al-Mu’in bi Sharh Qurrat al-Ayn',
    titleArabic: 'فتح المعين بشرح قرة العين بمهمات الدين',
    titleMalayalam: 'ഫത്ഹുൽ മുഈൻ',
    description: 'The masterwork of Shafi’i jurisprudence taught across traditional Islamic madrasas and universities globally, authored in Ponnani.',
    category: 'islamic-books',
    language: 'ar',
    author: 'Allama Zayn al-Din Ahmad al-Makhdoom II',
    storagePath: 'https://archive.org/download/fath-al-mueen/fath-al-mueen.pdf',
    fileName: 'fathul-mueen-fiqh.pdf',
    fileType: 'pdf',
    mimeType: 'application/pdf',
    fileSize: '24.5 MB',
    version: 1,
    uploadedBy: 'Heritage Board',
    uploadDate: '2026-07-28',
    updatedDate: '2026-07-28',
    status: 'published',
    publicVisibility: true,
    previousVersions: [],
    metadata: {
      pageCount: 450,
      downloadCount: 3820,
    },
  },

  // 10. Course materials
  {
    id: 'file-course-tajweed-handbook',
    title: 'Noor Academy Tajweed Masterclass Curriculum Guide',
    titleArabic: 'دليل مادة أحكام التجويد ومخارج الحروف',
    titleMalayalam: 'തജ്‌വീദ് പാഠ്യപദ്ധതി & പ്രാക്ടിക്കൽ ഗൈഡ്',
    description: 'Comprehensive study manual containing articulation points (Makharij), rules of Noon Sakinah, Meem Sakinah, and Madd.',
    category: 'course-materials',
    language: 'en',
    author: 'Shaykh Dr. Farhan al-Azhari',
    storagePath: 'https://archive.org/download/tajweed-guide/tajweed-guide.pdf',
    fileName: 'tajweed-academy-handbook.pdf',
    fileType: 'pdf',
    mimeType: 'application/pdf',
    fileSize: '8.7 MB',
    version: 1,
    uploadedBy: 'Academy Board',
    uploadDate: '2026-08-01',
    updatedDate: '2026-08-01',
    status: 'published',
    publicVisibility: true,
    previousVersions: [],
    metadata: {
      pageCount: 96,
      downloadCount: 1540,
    },
  },

  // 11. Kids materials
  {
    id: 'file-kids-arabic-workbook',
    title: 'Noor Kids Arabic Alphabet & Manners Activity Book',
    titleArabic: 'دفتر أنشطة الحروف والأخلاق الإسلامية للأطفال',
    titleMalayalam: 'കുട്ടികൾക്കുള്ള അറബിക് അക്ഷരമാല വർക്ക്ബുക്ക്',
    description: 'Delightful printable worksheets with letter tracing, coloring sheets, and prophetic manners for young Muslim children.',
    category: 'kids-materials',
    language: 'en',
    author: 'Noor Early Childhood Education Dept',
    storagePath: 'https://archive.org/download/kids-arabic-activity/kids-arabic.pdf',
    fileName: 'noor-kids-arabic-workbook.pdf',
    fileType: 'pdf',
    mimeType: 'application/pdf',
    fileSize: '14.2 MB',
    version: 1,
    uploadedBy: 'Kids Team',
    uploadDate: '2026-08-25',
    updatedDate: '2026-08-25',
    status: 'published',
    publicVisibility: true,
    previousVersions: [],
    metadata: {
      pageCount: 42,
      downloadCount: 2280,
    },
  },

  // 12. Articles/resources
  {
    id: 'file-article-kerala-heritage',
    title: 'The Makhdoom Heritage: Islamic Scholarship in Malabar',
    titleArabic: 'تراث المخدوميين في نشر العلوم الشرعية بمليبار',
    titleMalayalam: 'മഖ്ദൂം പാരമ്പര്യം: മലബാറിലെ ഇസ്ലാമിക വിജ്ഞാന ചരിത്രം',
    description: 'Academic treatise documenting the transmission of Shafi’i jurisprudence and spirituality from southern India to the wider Indian Ocean world.',
    category: 'articles-resources',
    language: 'en',
    author: 'Prof. Sayyid Hamid Ba’Alawi',
    storagePath: 'https://archive.org/download/makhdoom-heritage/makhdoom-heritage.pdf',
    fileName: 'makhdoom-heritage-research.pdf',
    fileType: 'pdf',
    mimeType: 'application/pdf',
    fileSize: '6.3 MB',
    version: 1,
    uploadedBy: 'Editorial Board',
    uploadDate: '2026-09-02',
    updatedDate: '2026-09-02',
    status: 'published',
    publicVisibility: true,
    previousVersions: [],
    metadata: {
      pageCount: 38,
      downloadCount: 790,
    },
  },

  // 13. Audio files
  {
    id: 'file-audio-fatiha',
    title: 'Surah Al-Fatiha Recitation (Murattal)',
    titleArabic: 'تلاوة سورة الفاتحة المباركة',
    titleMalayalam: 'സൂറത്തുൽ ഫാത്തിഹ പാരായണം',
    description: 'Soul-stirring studio recitation of Surah Al-Fatiha by Qari Mishary Rashid Alafasy.',
    category: 'audio-files',
    language: 'ar',
    author: 'Qari Mishary Rashid Alafasy',
    storagePath: 'https://server8.mp3quran.net/afs/001.mp3',
    fileName: 'surah-al-fatiha-alafasy.mp3',
    fileType: 'audio',
    mimeType: 'audio/mpeg',
    fileSize: '1.2 MB',
    version: 1,
    uploadedBy: 'Audio Dept',
    uploadDate: '2026-08-01',
    updatedDate: '2026-08-01',
    status: 'published',
    publicVisibility: true,
    previousVersions: [],
    metadata: {
      duration: '0:48',
      downloadCount: 6510,
    },
  },

  // 14. Images
  {
    id: 'file-image-manuscript',
    title: 'Illuminated 14th Century Qur’an Folio',
    titleArabic: 'مخطوطة قرآنية مذهبة من القرن الثامن الهجري',
    titleMalayalam: 'പുരാതന സ്വർണ്ണ അലങ്കാര ഖുർആൻ കൈയെഴുത്തുപ്രതി',
    description: 'High-definition preservation scan of gold leaf calligraphy with lapis lazuli borders.',
    category: 'images',
    language: 'ar',
    author: 'Historical Islamic Archive Collection',
    storagePath: 'https://images.unsplash.com/photo-1585036156171-384164a8c675?auto=format&fit=crop&q=80&w=1200',
    fileName: 'gold-illuminated-manuscript.jpg',
    fileType: 'image',
    mimeType: 'image/jpeg',
    fileSize: '4.8 MB',
    version: 1,
    uploadedBy: 'Archivist',
    uploadDate: '2026-08-10',
    updatedDate: '2026-08-10',
    status: 'published',
    publicVisibility: true,
    previousVersions: [],
    metadata: {
      downloadCount: 1120,
    },
  },

  // 15. Videos
  {
    id: 'file-video-tajweed',
    title: 'Makharidj al-Huroof - Interactive Visual Guide',
    titleArabic: 'شرح مخارج الحروف العربية بالرسوم التوضيحية',
    titleMalayalam: 'അറബിക് അക്ഷരങ്ങളുടെ മഖ്റജുകൾ - വീഡിയോ ഗൈഡ്',
    description: 'Visual demonstration showing throat, tongue, and lip points of articulation for correct Quranic recitation.',
    category: 'videos',
    language: 'en',
    author: 'Noor Media Studio',
    storagePath: 'https://archive.org/download/tajweed-tutorial-preview/preview.mp4',
    fileName: 'tajweed-articulation-guide.mp4',
    fileType: 'video',
    mimeType: 'video/mp4',
    fileSize: '42.6 MB',
    version: 1,
    uploadedBy: 'Media Director',
    uploadDate: '2026-08-18',
    updatedDate: '2026-08-18',
    status: 'published',
    publicVisibility: true,
    previousVersions: [],
    metadata: {
      duration: '14:20',
      downloadCount: 890,
    },
  },

  // 16. Documents
  {
    id: 'file-doc-charter',
    title: 'Noor Islamic Academy Sanad Accreditation Charter',
    titleArabic: 'ميثاق الإسناد والإجازة الأكاديمية لمؤسسة النور',
    titleMalayalam: 'നൂർ അക്കാദമി സനദ് ചാർട്ടർ & മാർഗ്ഗരേഖകൾ',
    description: 'Official certification protocol and criteria for issuing unbroken chains of transmission (Sanad Muttasil) in Hadith and Tajweed.',
    category: 'documents',
    language: 'en',
    author: 'Supreme Board of Traditional Scholars',
    storagePath: 'https://archive.org/download/noor-sanad-charter/charter.pdf',
    fileName: 'noor-sanad-accreditation-charter.pdf',
    fileType: 'doc',
    mimeType: 'application/pdf',
    fileSize: '1.8 MB',
    version: 1,
    uploadedBy: 'Academic Registrar',
    uploadDate: '2026-08-20',
    updatedDate: '2026-08-20',
    status: 'published',
    publicVisibility: true,
    previousVersions: [],
    metadata: {
      pageCount: 18,
      downloadCount: 450,
    },
  },
];

export class StorageService {
  /**
   * Loads managed files from localStorage or initializes seeds
   */
  static loadFiles(): ManagedFileItem[] {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch (e) {
      console.warn('Could not read stored managed files, using defaults', e);
    }
    this.saveFiles(INITIAL_MANAGED_FILES);
    return INITIAL_MANAGED_FILES;
  }

  /**
   * Persists managed files into localStorage
   */
  static saveFiles(files: ManagedFileItem[]): void {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(files));
    } catch (e) {
      console.error('Error saving files to localStorage', e);
    }
  }

  /**
   * Reads a user-selected File object as Data URL (base64)
   */
  static async readFileAsDataUrl(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          resolve(reader.result);
        } else {
          reject(new Error('Failed to read file as data URL'));
        }
      };
      reader.onerror = () => reject(reader.error);
      reader.readAsDataURL(file);
    });
  }

  /**
   * Formats file size in bytes to human-readable string (KB, MB)
   */
  static formatFileSize(bytes: number): string {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  }

  /**
   * Triggers a real browser file download
   */
  static downloadFile(fileItem: ManagedFileItem): void {
    const link = document.createElement('a');
    link.href = fileItem.storagePath;
    link.download = fileItem.fileName || `${fileItem.title.toLowerCase().replace(/\s+/g, '-')}.${fileItem.fileType}`;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
}
