import { initializeApp } from 'firebase/app';
import {
  getAuth,
  signInWithPopup,
  signOut,
  GoogleAuthProvider,
  onAuthStateChanged,
  User as FirebaseUser,
} from 'firebase/auth';
import {
  getFirestore,
  doc,
  collection,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  onSnapshot,
  query,
  getDocFromServer,
  Unsubscribe,
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';
import { ManagedFileItem, FileVersion } from '../types/storage';
import { DevotionalItem, Article, AuditLog, BookmarkItem, UserNote, DailyDhikrProgress } from '../types';
import { INITIAL_MANAGED_FILES } from './storageService';
import { INITIAL_DEVOTIONALS, INITIAL_ARTICLES } from '../data/initialData';

// 1. Initialize Firebase App and Firestore with dedicated databaseId
export const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();

// Designate primary admin email
export const BOOTSTRAP_ADMIN_EMAIL = 'narutokunjappan@gmail.com';

// 2. Strict Error Handling conforming to FirestoreErrorInfo
export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map((provider) => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// 3. Test Connection to Firestore
export async function testFirestoreConnection(): Promise<boolean> {
  try {
    await getDoc(doc(db, 'test', 'connection'));
    console.log('Successfully connected to Firestore database:', firebaseConfig.firestoreDatabaseId);
    return true;
  } catch (error) {
    console.warn('Firestore connection check note:', error);
    return false;
  }
}

// 4. Authentication helpers
let isSignInInProgress = false;

export async function signInWithGoogle(): Promise<FirebaseUser | null> {
  if (isSignInInProgress) {
    console.warn('Sign-in already in progress, avoiding duplicate popup.');
    return null;
  }
  isSignInInProgress = true;
  try {
    const result = await signInWithPopup(auth, googleProvider);
    const user = result.user;
    if (user) {
      // Sync user profile to Firestore
      const userRef = doc(db, 'users', user.uid);
      const isAdmin = user.email?.toLowerCase() === BOOTSTRAP_ADMIN_EMAIL.toLowerCase();
      
      try {
        await setDoc(
          userRef,
          {
            uid: user.uid,
            email: user.email || '',
            displayName: user.displayName || 'Seeker',
            photoURL: user.photoURL || '',
            role: isAdmin ? 'super_admin' : 'user',
            updatedAt: new Date().toISOString(),
          },
          { merge: true }
        );

        // If bootstrap admin, ensure presence in admins collection
        if (isAdmin) {
          const adminRef = doc(db, 'admins', user.uid);
          await setDoc(
            adminRef,
            {
              email: user.email,
              role: 'super_admin',
              createdAt: new Date().toISOString(),
            },
            { merge: true }
          );
        }
      } catch (profileErr) {
        console.warn('User profile sync to Firestore notice:', profileErr);
      }
    }
    return user;
  } catch (error: any) {
    if (error?.code === 'auth/cancelled-popup-request') {
      console.info('A previous sign-in request was cancelled by a new click.');
      return null;
    }
    if (error?.code === 'auth/popup-closed-by-user') {
      console.info('Google sign-in popup was closed by the user.');
      return null;
    }
    if (error?.code === 'auth/popup-blocked') {
      console.warn('Google sign-in popup was blocked by browser.');
      throw new Error('Sign-in pop-up was blocked by your browser. Please allow pop-ups for this site or open in a new tab.');
    }
    console.error('Google Sign-In Error:', error);
    throw error;
  } finally {
    isSignInInProgress = false;
  }
}

export async function signOutFromFirebase(): Promise<void> {
  await signOut(auth);
}

// 5. Managed Files Firestore Service
const FILES_COLLECTION = 'managed_files';

export class FirebaseDataService {
  /**
   * Listen to real-time changes in managed files collection
   */
  static subscribeToManagedFiles(
    onData: (files: ManagedFileItem[]) => void,
    onError?: (err: unknown) => void
  ): Unsubscribe {
    const colRef = collection(db, FILES_COLLECTION);
    return onSnapshot(
      colRef,
      (snapshot) => {
        if (snapshot.empty) {
          // If empty in Firestore, seed initial dataset
          FirebaseDataService.seedInitialFiles().then(() => {
            onData(INITIAL_MANAGED_FILES);
          }).catch(console.error);
        } else {
          const files: ManagedFileItem[] = [];
          snapshot.forEach((docSnap) => {
            files.push(docSnap.data() as ManagedFileItem);
          });
          onData(files);
        }
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, FILES_COLLECTION);
        if (onError) onError(error);
      }
    );
  }

  /**
   * Seeds initial files to Firestore if database collection is empty
   */
  static async seedInitialFiles(): Promise<void> {
    try {
      for (const item of INITIAL_MANAGED_FILES) {
        const fileRef = doc(db, FILES_COLLECTION, item.id);
        await setDoc(fileRef, item, { merge: true });
      }
      console.log('Seeded initial managed files to Firestore.');
    } catch (e) {
      console.warn('Initial file seeding note:', e);
    }
  }

  /**
   * Admin adds a new file to Firestore
   */
  static async addManagedFile(file: ManagedFileItem): Promise<void> {
    const path = `${FILES_COLLECTION}/${file.id}`;
    try {
      const fileRef = doc(db, FILES_COLLECTION, file.id);
      await setDoc(fileRef, file);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, path);
    }
  }

  /**
   * Admin updates file metadata: saves directly to database
   */
  static async updateManagedFile(fileId: string, updates: Partial<ManagedFileItem>): Promise<void> {
    const path = `${FILES_COLLECTION}/${fileId}`;
    try {
      const fileRef = doc(db, FILES_COLLECTION, fileId);
      await updateDoc(fileRef, {
        ...updates,
        updatedDate: new Date().toISOString().split('T')[0],
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  }

  /**
   * ADMIN REPLACES A FILE:
   * CRITICAL USER MANDATE: "IF ADMIN CHANGES AN CHANGE THAT SHOULD CHANGE IN DATABASE, AND OLD WILL BEDELETED"
   * The file in the database is updated with the new storage path, file name, size, mimeType,
   * AND any old versions/previous versions are purged/deleted from the database record!
   */
  static async replaceManagedFileAndPurgeOld(
    fileId: string,
    newFileData: {
      storagePath: string;
      fileName: string;
      fileSize: string;
      mimeType?: string;
      changeNote?: string;
    },
    publishImmediately: boolean = true
  ): Promise<void> {
    const path = `${FILES_COLLECTION}/${fileId}`;
    try {
      const fileRef = doc(db, FILES_COLLECTION, fileId);
      const snap = await getDoc(fileRef);
      const currentData = snap.exists() ? (snap.data() as ManagedFileItem) : null;

      const newVersion = (currentData?.version || 1) + 1;
      const today = new Date().toISOString().split('T')[0];

      // Update in database and delete/purge old versions (previousVersions is set to empty array,
      // old storage reference is completely replaced)
      await updateDoc(fileRef, {
        storagePath: newFileData.storagePath,
        fileName: newFileData.fileName,
        fileSize: newFileData.fileSize,
        mimeType: newFileData.mimeType || currentData?.mimeType || 'application/pdf',
        version: newVersion,
        updatedDate: today,
        status: publishImmediately ? 'published' : 'draft',
        publicVisibility: publishImmediately,
        // Old versions purged from database upon admin change:
        previousVersions: [],
        lastReplacedNote: newFileData.changeNote || `Replaced with ${newFileData.fileName}. Old version deleted from database.`,
      });

      console.log(`File ${fileId} updated in database; old version deleted.`);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  }

  /**
   * Admin explicitly purges any accumulated old versions from database for a file
   */
  static async purgeOldVersions(fileId: string): Promise<void> {
    const path = `${FILES_COLLECTION}/${fileId}`;
    try {
      const fileRef = doc(db, FILES_COLLECTION, fileId);
      await updateDoc(fileRef, {
        previousVersions: [],
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  }

  /**
   * Admin removes a file from Firestore: deletes document permanently
   */
  static async deleteManagedFile(fileId: string): Promise<void> {
    const path = `${FILES_COLLECTION}/${fileId}`;
    try {
      const fileRef = doc(db, FILES_COLLECTION, fileId);
      await deleteDoc(fileRef);
      console.log(`File ${fileId} deleted from database.`);
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, path);
    }
  }

  // 6. Devotionals Firestore Sync
  static subscribeToDevotionals(
    onData: (devs: DevotionalItem[]) => void,
    onError?: (err: unknown) => void
  ): Unsubscribe {
    const colRef = collection(db, 'devotionals');
    return onSnapshot(
      colRef,
      (snapshot) => {
        if (snapshot.empty) {
          FirebaseDataService.seedInitialDevotionals().then(() => {
            onData(INITIAL_DEVOTIONALS);
          }).catch(console.error);
        } else {
          const items: DevotionalItem[] = [];
          snapshot.forEach((docSnap) => items.push(docSnap.data() as DevotionalItem));
          onData(items);
        }
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, 'devotionals');
        if (onError) onError(error);
      }
    );
  }

  static async seedInitialDevotionals(): Promise<void> {
    try {
      for (const item of INITIAL_DEVOTIONALS) {
        await setDoc(doc(db, 'devotionals', item.id), item, { merge: true });
      }
    } catch (e) {
      console.warn('Initial devotionals seeding:', e);
    }
  }

  static async saveDevotional(item: DevotionalItem): Promise<void> {
    const path = `devotionals/${item.id}`;
    try {
      await setDoc(doc(db, 'devotionals', item.id), item, { merge: true });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  }

  static async deleteDevotional(id: string): Promise<void> {
    const path = `devotionals/${id}`;
    try {
      await deleteDoc(doc(db, 'devotionals', id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, path);
    }
  }

  // 7. Articles Firestore Sync
  static subscribeToArticles(
    onData: (articles: Article[]) => void,
    onError?: (err: unknown) => void
  ): Unsubscribe {
    const colRef = collection(db, 'articles');
    return onSnapshot(
      colRef,
      (snapshot) => {
        if (snapshot.empty) {
          FirebaseDataService.seedInitialArticles().then(() => {
            onData(INITIAL_ARTICLES);
          }).catch(console.error);
        } else {
          const items: Article[] = [];
          snapshot.forEach((docSnap) => items.push(docSnap.data() as Article));
          onData(items);
        }
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, 'articles');
        if (onError) onError(error);
      }
    );
  }

  static async seedInitialArticles(): Promise<void> {
    try {
      for (const item of INITIAL_ARTICLES) {
        await setDoc(doc(db, 'articles', item.id), item, { merge: true });
      }
    } catch (e) {
      console.warn('Initial articles seeding:', e);
    }
  }

  static async saveArticle(item: Article): Promise<void> {
    const path = `articles/${item.id}`;
    try {
      await setDoc(doc(db, 'articles', item.id), item, { merge: true });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  }

  static async deleteArticle(id: string): Promise<void> {
    const path = `articles/${id}`;
    try {
      await deleteDoc(doc(db, 'articles', id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, path);
    }
  }

  // 8. Audit Logs
  static async recordAuditLog(log: AuditLog): Promise<void> {
    const path = `audit_logs/${log.id}`;
    try {
      await setDoc(doc(db, 'audit_logs', log.id), log);
    } catch (error) {
      // Audit log might fail silently if rules prevent, but log to console
      console.warn('Could not record audit log to Firestore:', error);
    }
  }

  // 9. Daily Dhikr Progress (Aurad Tracker)
  static async saveDailyDhikrProgress(progress: DailyDhikrProgress): Promise<void> {
    const path = `user_dhikr_logs/${progress.id}`;
    try {
      await setDoc(doc(db, 'user_dhikr_logs', progress.id), progress, { merge: true });
      if (progress.userId) {
        await setDoc(doc(db, 'users', progress.userId, 'dhikr_progress', progress.date), progress, { merge: true });
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  }

  static async getDailyDhikrProgress(id: string): Promise<DailyDhikrProgress | null> {
    try {
      const snap = await getDoc(doc(db, 'user_dhikr_logs', id));
      if (snap.exists()) {
        return snap.data() as DailyDhikrProgress;
      }
      return null;
    } catch (error) {
      console.warn('Could not fetch Dhikr progress from Firestore:', error);
      return null;
    }
  }

  static subscribeToDailyDhikrProgress(
    id: string,
    onData: (data: DailyDhikrProgress | null) => void
  ): Unsubscribe {
    const docRef = doc(db, 'user_dhikr_logs', id);
    return onSnapshot(
      docRef,
      (snap) => {
        if (snap.exists()) {
          onData(snap.data() as DailyDhikrProgress);
        } else {
          onData(null);
        }
      },
      (err) => {
        console.warn('Daily dhikr snapshot notice:', err);
      }
    );
  }
}
