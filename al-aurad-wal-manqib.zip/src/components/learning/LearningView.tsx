import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Course, Lesson, QuizQuestion } from '../../types';
import {
  GraduationCap,
  BookOpen,
  Award,
  CheckCircle,
  Clock,
  ChevronRight,
  Sparkles,
  ArrowLeft,
  Search,
  User,
  Star,
} from 'lucide-react';

export const LearningView: React.FC = () => {
  const { courses, updateCourseProgress, openCertificate, showToast } = useApp();
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);
  const [activeLessonIndex, setActiveLessonIndex] = useState<number>(0);
  const [studentName, setStudentName] = useState<string>('Seeker of Knowledge');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Quiz State
  const [quizAnswers, setQuizAnswers] = useState<Record<number, number>>({});
  const [quizSubmitted, setQuizSubmitted] = useState<boolean>(false);

  const handleSelectCourse = (course: Course) => {
    setSelectedCourse(course);
    setActiveLessonIndex(0);
    setQuizAnswers({});
    setQuizSubmitted(false);
  };

  const handleAnswerChange = (qIndex: number, optIndex: number) => {
    setQuizAnswers((prev) => ({ ...prev, [qIndex]: optIndex }));
  };

  const calculateScore = () => {
    if (!selectedCourse?.quiz || selectedCourse.quiz.length === 0) return 0;
    let correct = 0;
    selectedCourse.quiz.forEach((q, idx) => {
      if (quizAnswers[idx] === q.correctIndex) {
        correct++;
      }
    });
    return Math.round((correct / selectedCourse.quiz.length) * 100);
  };

  const handleCompleteQuiz = () => {
    if (!selectedCourse?.quiz) return;
    if (Object.keys(quizAnswers).length < selectedCourse.quiz.length) {
      showToast('Please answer all questions before submitting', 'warning');
      return;
    }
    setQuizSubmitted(true);
    const score = calculateScore();
    if (score >= 70) {
      showToast(`Mabrook! You passed with ${score}%. Certificate is unlocked!`, 'success');
    } else {
      showToast(`You scored ${score}%. Pass mark is 70%. Review the lessons and try again!`, 'warning');
    }
  };

  const filteredCourses = courses.filter((c) =>
    c.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.instructor.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-emerald-950 via-emerald-900 to-teal-950 text-white rounded-2xl p-6 sm:p-8 border border-emerald-800 shadow-xl space-y-3">
        <div className="flex items-center gap-1.5 text-amber-400 text-xs font-bold font-cinzel uppercase tracking-wider">
          <GraduationCap className="w-4 h-4" />
          <span>Noor Traditional Academy</span>
        </div>
        <h1 className="text-2xl sm:text-4xl font-serif font-bold text-white">
          Authentic Curriculum, Quizzes & Verified Sanad Certification
        </h1>
        <p className="text-xs sm:text-sm text-emerald-100/90 leading-relaxed max-w-2xl font-light">
          Structured modular learning for Quranic Tajweed, Prophetic Hadith, Shafi'i/Hanafi jurisprudence, and spirituality under qualified traditional scholars.
        </p>

        {/* Student Name config */}
        <div className="pt-2 flex flex-col sm:flex-row items-start sm:items-center gap-3">
          <div className="flex items-center gap-2 text-xs text-amber-200">
            <User className="w-4 h-4 text-amber-400" />
            <span className="font-semibold">Certificate Name:</span>
          </div>
          <input
            type="text"
            value={studentName}
            onChange={(e) => setStudentName(e.target.value)}
            placeholder="Enter your full name..."
            className="px-3 py-1.5 rounded-xl bg-white/10 border border-white/20 text-white text-xs placeholder-white/40 focus:outline-none focus:ring-1 focus:ring-amber-400 w-64"
          />
        </div>
      </div>

      {/* Course Catalog or Active Course View */}
      {!selectedCourse ? (
        /* Course Grid View */
        <div className="space-y-6 animate-in fade-in">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-xl font-bold font-serif text-slate-900 dark:text-white">
                Available Courses & Sanad Programs
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Enroll at your pace, complete lessons, and take the evaluation to earn certificates.
              </p>
            </div>

            <div className="relative w-full sm:w-72">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Search courses or teachers..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 text-xs bg-white dark:bg-emerald-950 rounded-xl border border-slate-200 dark:border-emerald-800 text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {filteredCourses.map((course) => (
              <div
                key={course.id}
                onClick={() => handleSelectCourse(course)}
                className="bg-white dark:bg-emerald-950/40 rounded-2xl border border-slate-200/80 dark:border-emerald-800/40 shadow-sm hover:shadow-xl transition-all duration-300 cursor-pointer overflow-hidden flex flex-col justify-between group"
              >
                <div className={`h-36 w-full p-6 flex flex-col justify-between text-white bg-gradient-to-br ${course.coverGradient}`}>
                  <span className="text-[10px] uppercase font-bold tracking-wider px-2.5 py-0.5 rounded-full bg-black/40 text-amber-300 w-fit backdrop-blur-sm">
                    {course.level}
                  </span>
                  <div>
                    <span className="text-xs text-emerald-100 font-cinzel block">Certified Course</span>
                    <h4 className="text-base font-bold font-serif line-clamp-1">{course.badgeTitle}</h4>
                  </div>
                </div>

                <div className="p-6 flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center gap-2 text-xs text-slate-400 dark:text-emerald-400/70 mb-2">
                      <Clock className="w-3.5 h-3.5" />
                      <span>{course.duration}</span>
                      <span>·</span>
                      <span>{course.lessons.length} Lessons</span>
                    </div>

                    <h3 className="text-base font-bold text-slate-900 dark:text-white group-hover:text-emerald-800 dark:group-hover:text-amber-300 transition">
                      {course.title}
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                      Instructor: {course.instructor}
                    </p>

                    <p className="text-xs text-slate-600 dark:text-slate-300 mt-3 leading-relaxed line-clamp-2">
                      {course.description}
                    </p>
                  </div>

                  <div className="pt-4 mt-4 border-t border-slate-100 dark:border-emerald-900/40 flex items-center justify-between">
                    <span className="text-xs font-semibold text-emerald-800 dark:text-amber-400 flex items-center gap-1 group-hover:underline">
                      Start Course <ChevronRight className="w-3.5 h-3.5" />
                    </span>
                    <div className="flex items-center gap-1 text-[11px] text-amber-500 font-bold">
                      <Star className="w-3.5 h-3.5 fill-amber-400" />
                      <span>4.9</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        /* Active Course Classroom View */
        <div className="space-y-6 animate-in fade-in">
          {/* Back button */}
          <div className="flex items-center justify-between">
            <button
              onClick={() => setSelectedCourse(null)}
              className="flex items-center gap-1.5 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:text-emerald-800 dark:hover:text-amber-300 transition"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Course Directory</span>
            </button>

            <span className="text-xs px-3 py-1 rounded-full bg-emerald-100 dark:bg-emerald-900/50 text-emerald-800 dark:text-amber-300 font-semibold">
              Level: {selectedCourse.level}
            </span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Left Column: Lesson Navigation */}
            <div className="lg:col-span-4 bg-white dark:bg-emerald-950/40 rounded-2xl p-5 border border-slate-200 dark:border-emerald-800/40 space-y-4">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white font-serif">
                Course Curriculum ({selectedCourse.lessons.length} Lessons)
              </h3>

              <div className="space-y-2">
                {selectedCourse.lessons.map((lesson: Lesson, idx: number) => {
                  const isCurrent = activeLessonIndex === idx;
                  return (
                    <button
                      key={lesson.id}
                      onClick={() => setActiveLessonIndex(idx)}
                      className={`w-full text-left p-3 rounded-xl text-xs transition flex items-center justify-between ${
                        isCurrent
                          ? 'bg-emerald-800 text-white font-bold shadow-sm'
                          : 'bg-slate-50 dark:bg-emerald-900/30 text-slate-700 dark:text-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <span className="w-5 h-5 rounded-md bg-emerald-900 text-amber-300 flex items-center justify-center text-[10px] font-mono">
                          {idx + 1}
                        </span>
                        <span className="truncate max-w-[200px]">{lesson.title}</span>
                      </div>
                      <span className="text-[10px] opacity-70">{lesson.duration}</span>
                    </button>
                  );
                })}
              </div>

              {/* Assessment / Quiz shortcut */}
              {selectedCourse.quiz && selectedCourse.quiz.length > 0 && (
                <div className="pt-3 border-t border-slate-100 dark:border-emerald-900/40">
                  <button
                    onClick={() => setActiveLessonIndex(999)}
                    className={`w-full p-3 rounded-xl text-xs font-bold flex items-center justify-between transition ${
                      activeLessonIndex === 999
                        ? 'bg-amber-400 text-slate-950 shadow-md'
                        : 'bg-amber-50 dark:bg-amber-950/40 text-amber-900 dark:text-amber-300 border border-amber-200 dark:border-amber-800/50'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <Award className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                      <span>Course Final Evaluation</span>
                    </div>
                    <span>{selectedCourse.quiz.length} Questions</span>
                  </button>
                </div>
              )}
            </div>

            {/* Right Column: Active Lesson Viewer or Quiz */}
            <div className="lg:col-span-8 bg-white dark:bg-emerald-950/40 rounded-2xl p-6 sm:p-8 border border-slate-200 dark:border-emerald-800/40 shadow-sm">
              {activeLessonIndex !== 999 ? (
                /* Lesson Content */
                <div className="space-y-6">
                  {(() => {
                    const currentLesson = selectedCourse.lessons[activeLessonIndex] || selectedCourse.lessons[0];
                    return (
                      <>
                        <div className="pb-4 border-b border-slate-100 dark:border-emerald-900/40">
                          <span className="text-[10px] uppercase font-bold text-amber-600 dark:text-amber-400 font-cinzel">
                            Lesson {activeLessonIndex + 1} of {selectedCourse.lessons.length}
                          </span>
                          <h2 className="text-xl sm:text-2xl font-bold font-serif text-slate-900 dark:text-white mt-1">
                            {currentLesson.title}
                          </h2>
                          <span className="text-xs text-slate-400 flex items-center gap-1 mt-1">
                            <Clock className="w-3.5 h-3.5" /> Estimated Duration: {currentLesson.duration}
                          </span>
                        </div>

                        {/* Lesson Lecture Body */}
                        <div className="max-w-none text-xs sm:text-sm leading-relaxed text-slate-700 dark:text-slate-300 space-y-4">
                          <div className="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-900/30 border border-emerald-200 dark:border-emerald-800">
                            <p className="font-semibold text-emerald-900 dark:text-amber-300 mb-1">
                              Lesson Objective & Explanation:
                            </p>
                            <p>{currentLesson.content}</p>
                          </div>

                          {currentLesson.arabicSnippet && (
                            <div className="p-4 rounded-xl bg-slate-50 dark:bg-emerald-950 border border-slate-200 dark:border-emerald-800 space-y-2">
                              <span className="text-xs font-bold text-slate-600 dark:text-slate-300">
                                Textual Evidence / Arabic Matn:
                              </span>
                              <p className="font-arabic text-xl text-emerald-950 dark:text-emerald-100 text-right" dir="rtl">
                                {currentLesson.arabicSnippet}
                              </p>
                            </div>
                          )}
                        </div>

                        {/* Navigation between lessons */}
                        <div className="flex items-center justify-between pt-6 border-t border-slate-100 dark:border-emerald-900/40">
                          <button
                            disabled={activeLessonIndex === 0}
                            onClick={() => setActiveLessonIndex((prev) => prev - 1)}
                            className="px-4 py-2 rounded-xl border text-xs font-semibold disabled:opacity-40"
                          >
                            Previous Lesson
                          </button>

                          {activeLessonIndex < selectedCourse.lessons.length - 1 ? (
                            <button
                              onClick={() => {
                                updateCourseProgress(selectedCourse.id, currentLesson.id);
                                setActiveLessonIndex((prev) => prev + 1);
                              }}
                              className="px-5 py-2 rounded-xl bg-emerald-800 text-white text-xs font-bold hover:bg-emerald-700 transition"
                            >
                              Next Lesson →
                            </button>
                          ) : (
                            <button
                              onClick={() => setActiveLessonIndex(999)}
                              className="px-5 py-2 rounded-xl bg-amber-400 text-slate-950 text-xs font-bold hover:bg-amber-300 transition flex items-center gap-1.5"
                            >
                              <Award className="w-4 h-4" /> Take Final Assessment
                            </button>
                          )}
                        </div>
                      </>
                    );
                  })()}
                </div>
              ) : (
                /* Assessment Quiz Mode */
                <div className="space-y-6">
                  <div className="pb-4 border-b border-slate-100 dark:border-emerald-900/40">
                    <span className="text-xs font-bold text-amber-600 dark:text-amber-400 uppercase font-cinzel">
                      Course Final Assessment
                    </span>
                    <h2 className="text-xl sm:text-2xl font-bold font-serif text-slate-900 dark:text-white mt-1">
                      {selectedCourse.title} Evaluation
                    </h2>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                      Passing score is 70%. Successful completion generates your certified graduation diploma!
                    </p>
                  </div>

                  {/* Questions list */}
                  <div className="space-y-6">
                    {selectedCourse.quiz?.map((q: QuizQuestion, qIdx: number) => (
                      <div
                        key={q.id}
                        className="p-5 rounded-xl bg-slate-50 dark:bg-emerald-900/20 border border-slate-200 dark:border-emerald-800/40 space-y-3"
                      >
                        <h4 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
                          {qIdx + 1}. {q.question}
                        </h4>

                        <div className="space-y-2">
                          {q.options.map((opt: string, optIdx: number) => {
                            const isSelected = quizAnswers[qIdx] === optIdx;
                            const isCorrect = optIdx === q.correctIndex;
                            const showStatus = quizSubmitted;

                            return (
                              <button
                                key={optIdx}
                                disabled={quizSubmitted}
                                onClick={() => handleAnswerChange(qIdx, optIdx)}
                                className={`w-full text-left p-2.5 rounded-lg text-xs transition border flex items-center justify-between ${
                                  isSelected
                                    ? showStatus
                                      ? isCorrect
                                        ? 'bg-emerald-100 dark:bg-emerald-900 border-emerald-500 font-bold'
                                        : 'bg-rose-100 dark:bg-rose-950 border-rose-500 font-bold'
                                      : 'bg-emerald-800 text-white font-semibold border-emerald-700'
                                    : 'bg-white dark:bg-emerald-950 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-emerald-800 hover:bg-slate-100'
                                }`}
                              >
                                <span>{opt}</span>
                                {showStatus && isCorrect && (
                                  <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold">
                                    ✓ Correct
                                  </span>
                                )}
                              </button>
                            );
                          })}
                        </div>

                        {quizSubmitted && (
                          <div className="p-3 bg-emerald-50 dark:bg-emerald-950 rounded-lg text-[11px] text-emerald-900 dark:text-emerald-200">
                            <strong>Explanation:</strong> {q.explanation}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>

                  {/* Quiz Outcome & Certificate Trigger */}
                  <div className="pt-4 border-t border-slate-100 dark:border-emerald-900/40">
                    {!quizSubmitted ? (
                      <button
                        onClick={handleCompleteQuiz}
                        className="w-full py-3 rounded-xl bg-emerald-800 hover:bg-emerald-700 text-white font-bold text-xs shadow-md transition"
                      >
                        Submit Assessment
                      </button>
                    ) : (
                      <div className="p-6 rounded-2xl bg-emerald-50 dark:bg-emerald-900/40 border border-emerald-300 dark:border-emerald-700 text-center space-y-3">
                        <span className="font-mono text-3xl font-extrabold text-emerald-800 dark:text-amber-300 block">
                          Score: {calculateScore()}%
                        </span>

                        {calculateScore() >= 70 ? (
                          <>
                            <p className="text-xs text-emerald-900 dark:text-emerald-200">
                              Alhamdulillah! You passed the comprehensive assessment. Your official certificate is ready.
                            </p>
                            <button
                              onClick={() => openCertificate(selectedCourse.title, studentName)}
                              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-bold text-xs shadow-lg hover:from-amber-300 transition flex items-center gap-2 mx-auto"
                            >
                              <Award className="w-4 h-4" />
                              <span>View & Download Certificate</span>
                            </button>
                          </>
                        ) : (
                          <>
                            <p className="text-xs text-rose-700 dark:text-rose-300">
                              You scored below the passing mark of 70%. Review the lessons and retake the quiz.
                            </p>
                            <button
                              onClick={() => {
                                setQuizSubmitted(false);
                                setQuizAnswers({});
                              }}
                              className="px-5 py-2 rounded-xl bg-slate-800 text-white text-xs font-semibold hover:bg-slate-700"
                            >
                              Retake Assessment
                            </button>
                          </>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
