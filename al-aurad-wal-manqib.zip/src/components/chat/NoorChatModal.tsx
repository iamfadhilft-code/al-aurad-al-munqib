import React, { useState, useRef, useEffect } from 'react';
import Markdown from 'react-markdown';
import {
  Sparkles,
  Send,
  X,
  MapPin,
  Compass,
  BookOpen,
  Trash2,
  RefreshCw,
  Navigation,
  ExternalLink,
  MessageSquare,
  Bot,
  User,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  content: string;
  timestamp: string;
  groundingMetadata?: {
    webSearchQueries?: string[];
    groundingChunks?: Array<{
      web?: { uri: string; title: string };
      maps?: { uri?: string; title?: string; address?: string };
    }>;
  };
}

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const NoorChatModal: React.FC<Props> = ({ isOpen, onClose }) => {
  const { language, selectedCity } = useApp();

  const [messages, setMessages] = useState<ChatMessage[]>(() => [
    {
      id: 'welcome',
      role: 'model',
      content:
        language === 'ml'
          ? 'അസ്സലാമു അലൈക്കും. ഞാൻ **നൂർ അസിസ്റ്റന്റ് (Noor AI)**. വിശുദ്ധ ഖുർആൻ, ഹദീസുകൾ, ഔറാദുകൾ, ദുആകൾ, ചരിത്രം എന്നിവയെക്കുറിച്ചുള്ള സംശയങ്ങൾ ചോദിക്കാം. കൂടാതെ സമീപത്തെ പള്ളികളും ഇസ്ലാമിക് കേന്ദ്രങ്ങളും കണ്ടെത്താനും മാപ്സ് സഹായം ഉപയോഗിക്കാം.'
          : language === 'ar'
          ? 'السلام عليكم ورحمة الله وبركاته. أنا **نور المساعد (Noor AI)**. يمكنني مساعدتك في الإجابة عن استفسارات القرآن والحديث والأوراد والتاريخ الإسلامي، أو العثور على المساجد والمراكز الإسلامية.'
          : 'As-salamu alaykum. I am **Noor AI**, your Islamic spiritual and scholarly companion. Ask about Quran verses, Hadith, daily Adhkar & litanies, Islamic history, or use Maps Grounding to locate nearby mosques and Islamic heritage sites.',
      timestamp: 'Just now',
    },
  ]);

  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [chatMode, setChatMode] = useState<'general' | 'maps'>('general');
  const [userLocation, setUserLocation] = useState<{ lat?: number; lng?: number; city?: string }>({
    city: selectedCity,
  });

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Auto scroll to bottom
  useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
      inputRef.current?.focus();
    }
  }, [messages, isOpen]);

  // Try fetching user geolocation when Maps mode is selected
  const requestLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setUserLocation({
            lat: pos.coords.latitude,
            lng: pos.coords.longitude,
            city: selectedCity,
          });
        },
        (err) => {
          console.warn('Geolocation access declined/unavailable:', err.message);
        }
      );
    }
  };

  const handleSendMessage = async (textToSend?: string) => {
    const text = (textToSend || input).trim();
    if (!text || isLoading) return;

    const userMsg: ChatMessage = {
      id: 'usr-' + Date.now(),
      role: 'user',
      content: text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    const newHistory = [...messages, userMsg];
    setMessages(newHistory);
    setInput('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: newHistory.map((m) => ({ role: m.role, content: m.content })),
          mode: chatMode,
          userLocation,
        }),
      });

      let data: any = null;
      try {
        data = await response.json();
      } catch (jsonErr) {
        console.warn('Response was not JSON:', jsonErr);
      }

      const modelMsg: ChatMessage = {
        id: 'mod-' + Date.now(),
        role: 'model',
        content: data?.text || 'Unable to generate response at this moment. Please try again.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        groundingMetadata: data?.groundingMetadata,
      };

      setMessages((prev) => [...prev, modelMsg]);
    } catch (err: any) {
      console.warn('Chat connection notice:', err?.message || err);
      const errorMsg: ChatMessage = {
        id: 'err-' + Date.now(),
        role: 'model',
        content:
          language === 'ml'
            ? 'സെർവർ താത്കാലികമായി തിരക്കിലാണ്. ദയവായി അല്പം കഴിഞ്ഞ് വീണ്ടും ചോദിക്കുക.'
            : 'The AI service is momentarily busy or reconnecting. Please ask again in a moment.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const clearChat = () => {
    setMessages([
      {
        id: 'welcome-new',
        role: 'model',
        content:
          language === 'ml'
            ? 'സംഭാഷണം പുനഃക്രമീകരിച്ചു. പുതിയ ചോദ്യങ്ങൾ ചോദിക്കാം!'
            : 'Conversation reset. How may I assist you today?',
        timestamp: 'Just now',
      },
    ]);
  };

  const samplePrompts = [
    {
      label: language === 'ml' ? 'പ്രഭാത ദിക്റുകൾ' : 'Morning Adhkar',
      query: 'What are the essential authentic Morning Adhkar (പ്രഭാത ദിക്റുകൾ) with Arabic text and meaning?',
      mode: 'general' as const,
    },
    {
      label: language === 'ml' ? 'സമീപത്തെ പള്ളികൾ' : 'Historic Mosques',
      query: `Find historic mosques and prayer facilities in and around ${selectedCity || 'Kozhikode, Kerala'} with their location details.`,
      mode: 'maps' as const,
    },
    {
      label: language === 'ml' ? 'സൂറത്തുൽ കഹ്ഫ് പ്രാധാന്യം' : 'Surah Al-Kahf Virtues',
      query: 'Explain the virtues and rulings of reciting Surah Al-Kahf on Friday with Hadith references.',
      mode: 'general' as const,
    },
    {
      label: language === 'ml' ? 'സൈനുദ്ദീൻ മഖ്ദൂം പൈതൃകം' : 'Zainuddin Makhdoom Heritage',
      query: 'Tell me about Sheikh Zainuddin Makhdoom and the historical significance of Ponnani Juma Masjid in Kerala.',
      mode: 'general' as const,
    },
  ];

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white dark:bg-slate-900 rounded-2xl w-full max-w-2xl h-[85vh] max-h-[750px] border border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-200 dark:border-slate-800 bg-emerald-950 text-white">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-400/40 text-amber-300 flex items-center justify-center">
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold tracking-tight">Noor AI Scholar</h2>
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-emerald-500/30 text-emerald-200 border border-emerald-500/40">
                  Gemini Grounded
                </span>
              </div>
              <p className="text-[11px] text-emerald-200/80">
                Islamic Knowledge · Multi-Turn · Google Maps Grounding
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={clearChat}
              className="p-1.5 rounded-lg text-emerald-200 hover:text-white hover:bg-white/10 transition"
              title="Clear Conversation"
            >
              <Trash2 className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-emerald-200 hover:text-white hover:bg-white/10 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Mode & Location Bar */}
        <div className="px-4 py-2 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between flex-wrap gap-2 text-xs">
          <div className="flex items-center gap-1 bg-white dark:bg-slate-900 p-1 rounded-lg border border-slate-200 dark:border-slate-700">
            <button
              onClick={() => setChatMode('general')}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-md font-semibold transition ${
                chatMode === 'general'
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>Spiritual & Scholarly</span>
            </button>
            <button
              onClick={() => {
                setChatMode('maps');
                requestLocation();
              }}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-md font-semibold transition ${
                chatMode === 'maps'
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              <MapPin className="w-3.5 h-3.5" />
              <span>Maps Grounding (Mosques)</span>
            </button>
          </div>

          {chatMode === 'maps' && (
            <div className="flex items-center gap-1.5 text-amber-700 dark:text-amber-400 font-medium">
              <Navigation className="w-3.5 h-3.5 animate-pulse" />
              <span>Location: {selectedCity || 'Auto-detecting'}</span>
            </div>
          )}
        </div>

        {/* Messages Scroll Area */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4 text-sm">
          {messages.map((msg) => {
            const isUser = msg.role === 'user';

            return (
              <div
                key={msg.id}
                className={`flex gap-3 ${isUser ? 'justify-end' : 'justify-start'}`}
              >
                {!isUser && (
                  <div className="w-8 h-8 rounded-full bg-emerald-800 text-amber-300 flex items-center justify-center shrink-0 mt-0.5 shadow-sm">
                    <Sparkles className="w-4 h-4" />
                  </div>
                )}

                <div
                  className={`max-w-[85%] sm:max-w-[80%] rounded-2xl p-4 space-y-2 shadow-xs ${
                    isUser
                      ? 'bg-emerald-800 text-white rounded-br-xs'
                      : 'bg-slate-100 dark:bg-slate-800/90 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700/60 rounded-bl-xs'
                  }`}
                >
                  <div className="markdown-body leading-relaxed prose dark:prose-invert text-xs sm:text-sm">
                    <Markdown>{msg.content}</Markdown>
                  </div>

                  {/* Grounding Citations & Map Chips */}
                  {msg.groundingMetadata?.groundingChunks && msg.groundingMetadata.groundingChunks.length > 0 && (
                    <div className="mt-3 pt-2.5 border-t border-slate-200 dark:border-slate-700/60 text-xs">
                      <p className="font-semibold text-emerald-700 dark:text-emerald-400 text-[11px] mb-1.5 flex items-center gap-1">
                        <Compass className="w-3.5 h-3.5" />
                        <span>Grounded References & Places:</span>
                      </p>
                      <div className="flex flex-wrap gap-1.5">
                        {msg.groundingMetadata.groundingChunks.map((chunk, idx) => {
                          if (chunk.maps) {
                            return (
                              <a
                                key={idx}
                                href={chunk.maps.uri || '#'}
                                target="_blank"
                                rel="noreferrer"
                                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-amber-50 dark:bg-amber-950/60 border border-amber-300 dark:border-amber-800 text-amber-900 dark:text-amber-200 hover:bg-amber-100 transition text-[11px]"
                              >
                                <MapPin className="w-3 h-3 text-amber-600" />
                                <span>{chunk.maps.title || chunk.maps.address || 'View on Google Maps'}</span>
                                <ExternalLink className="w-2.5 h-2.5 opacity-60" />
                              </a>
                            );
                          }
                          if (chunk.web) {
                            return (
                              <a
                                key={idx}
                                href={chunk.web.uri}
                                target="_blank"
                                rel="noreferrer"
                                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200 hover:bg-slate-300 transition text-[11px]"
                              >
                                <ExternalLink className="w-3 h-3 text-slate-500" />
                                <span className="truncate max-w-[180px]">{chunk.web.title}</span>
                              </a>
                            );
                          }
                          return null;
                        })}
                      </div>
                    </div>
                  )}

                  <div className="text-[10px] opacity-60 text-right font-mono mt-1">
                    {msg.timestamp}
                  </div>
                </div>

                {isUser && (
                  <div className="w-8 h-8 rounded-full bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 flex items-center justify-center shrink-0 mt-0.5">
                    <User className="w-4 h-4" />
                  </div>
                )}
              </div>
            );
          })}

          {isLoading && (
            <div className="flex gap-3 justify-start">
              <div className="w-8 h-8 rounded-full bg-emerald-800 text-amber-300 flex items-center justify-center shrink-0">
                <RefreshCw className="w-4 h-4 animate-spin" />
              </div>
              <div className="p-3.5 rounded-2xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700/60 text-xs text-slate-500 dark:text-slate-400 flex items-center gap-2">
                <div className="flex space-x-1">
                  <div className="w-2 h-2 rounded-full bg-emerald-600 animate-bounce" style={{ animationDelay: '0ms' }} />
                  <div className="w-2 h-2 rounded-full bg-emerald-600 animate-bounce" style={{ animationDelay: '150ms' }} />
                  <div className="w-2 h-2 rounded-full bg-emerald-600 animate-bounce" style={{ animationDelay: '300ms' }} />
                </div>
                <span>
                  {chatMode === 'maps'
                    ? 'Grounding location details with Google Maps...'
                    : 'Consulting authentic sources...'}
                </span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Suggested Prompts Pill Carousel */}
        <div className="px-4 py-2 border-t border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50 flex gap-2 overflow-x-auto text-xs">
          {samplePrompts.map((p, idx) => (
            <button
              key={idx}
              onClick={() => {
                setChatMode(p.mode);
                handleSendMessage(p.query);
              }}
              className="shrink-0 px-3 py-1 rounded-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:border-emerald-500 hover:text-emerald-700 dark:hover:text-emerald-400 transition"
            >
              {p.label}
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <div className="p-3 sm:p-4 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex items-center gap-2">
          <input
            ref={inputRef}
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSendMessage();
              }
            }}
            placeholder={
              chatMode === 'maps'
                ? 'Ask to find mosques, prayer rooms, or halal spots in any city...'
                : 'Ask a question about Quran, Hadith, Duas, or Kerala heritage...'
            }
            className="flex-1 px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
            disabled={isLoading}
          />

          <button
            onClick={() => handleSendMessage()}
            disabled={!input.trim() || isLoading}
            className="p-2.5 sm:px-4 sm:py-2.5 rounded-xl bg-emerald-800 hover:bg-emerald-900 disabled:opacity-40 text-white font-semibold text-xs sm:text-sm flex items-center justify-center gap-1.5 transition shadow-sm"
          >
            <Send className="w-4 h-4" />
            <span className="hidden sm:inline">Send</span>
          </button>
        </div>
      </div>
    </div>
  );
};
