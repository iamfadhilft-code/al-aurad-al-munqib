import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Bookmark,
  BookOpen,
  Trash2,
  Plus,
  Heart,
  Sparkles,
  Flame,
  Clock,
  Compass,
  FileText,
} from 'lucide-react';

export const DashboardView: React.FC = () => {
  const {
    bookmarks,
    toggleBookmark,
    notes,
    addNote,
    deleteNote,
    tasbihTotal,
    setActivePage,
    setSelectedSurahNumber,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'overview' | 'bookmarks' | 'notes'>('overview');
  const [newNoteTitle, setNewNoteTitle] = useState('');
  const [newNoteTopic, setNewNoteTopic] = useState('');
  const [newNoteContent, setNewNoteContent] = useState('');
  const [showNoteForm, setShowNoteForm] = useState(false);

  const handleCreateNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNoteTitle.trim() || !newNoteContent.trim()) return;
    addNote({
      title: newNoteTitle,
      surahOrTopic: newNoteTopic || 'General Reflection',
      content: newNoteContent,
    });
    setNewNoteTitle('');
    setNewNoteTopic('');
    setNewNoteContent('');
    setShowNoteForm(false);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Header Profile Banner */}
      <div className="bg-gradient-to-r from-emerald-950 via-emerald-900 to-slate-900 text-white rounded-2xl p-6 sm:p-8 border border-emerald-800 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-amber-400 to-amber-500 text-slate-950 flex items-center justify-center font-serif text-2xl font-bold shadow-lg">
            ن
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-bold font-serif">Seeker of Noor</h1>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-800 text-amber-300 font-semibold border border-amber-400/30">
                Active Student
              </span>
            </div>
            <p className="text-xs text-emerald-200 mt-0.5">
              Personal Worship, Daily Adhkar, Reading Habits & Saved Reflections
            </p>
          </div>
        </div>

        {/* Quick Streak & Dhikr Badge */}
        <div className="flex items-center gap-4 bg-white/10 backdrop-blur-md px-4 py-2.5 rounded-xl border border-white/20">
          <div className="flex items-center gap-1.5">
            <Flame className="w-5 h-5 text-amber-400 fill-amber-400" />
            <div>
              <span className="block text-[10px] text-emerald-200 uppercase font-semibold">Reading Streak</span>
              <span className="text-sm font-bold font-mono text-white">7 Days Active</span>
            </div>
          </div>
          <div className="w-px h-8 bg-white/20"></div>
          <div>
            <span className="block text-[10px] text-emerald-200 uppercase font-semibold">Total Tasbih</span>
            <span className="text-sm font-bold font-mono text-amber-300">{tasbihTotal} Praises</span>
          </div>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 dark:border-emerald-800 pb-2 text-xs">
        <button
          onClick={() => setActiveTab('overview')}
          className={`px-4 py-2 rounded-xl font-semibold transition ${
            activeTab === 'overview'
              ? 'bg-emerald-800 text-white'
              : 'bg-white dark:bg-emerald-950 text-slate-700 dark:text-slate-300 border'
          }`}
        >
          Spiritual Overview
        </button>

        <button
          onClick={() => setActiveTab('bookmarks')}
          className={`px-4 py-2 rounded-xl font-semibold transition flex items-center gap-1.5 ${
            activeTab === 'bookmarks'
              ? 'bg-emerald-800 text-white'
              : 'bg-white dark:bg-emerald-950 text-slate-700 dark:text-slate-300 border'
          }`}
        >
          <Bookmark className="w-3.5 h-3.5" />
          <span>Saved Bookmarks ({bookmarks.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('notes')}
          className={`px-4 py-2 rounded-xl font-semibold transition flex items-center gap-1.5 ${
            activeTab === 'notes'
              ? 'bg-emerald-800 text-white'
              : 'bg-white dark:bg-emerald-950 text-slate-700 dark:text-slate-300 border'
          }`}
        >
          <FileText className="w-3.5 h-3.5" />
          <span>My Reflection Notes ({notes.length})</span>
        </button>
      </div>

      {/* Tab 1: Overview */}
      {activeTab === 'overview' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 animate-in fade-in">
          {/* Card 1: Quran Reading Habit */}
          <div className="bg-white dark:bg-emerald-950/40 p-6 rounded-2xl border border-slate-200 dark:border-emerald-800 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-sm text-slate-900 dark:text-white font-serif">
                Qur'an Recitation Journey
              </h3>
              <BookOpen className="w-4 h-4 text-emerald-600 dark:text-amber-400" />
            </div>
            <div className="space-y-2">
              <div className="flex justify-between text-xs text-slate-500 dark:text-slate-400">
                <span>Recent Surah: Al-Baqarah (2)</span>
                <span>Verse 255</span>
              </div>
              <div className="w-full h-2 bg-slate-100 dark:bg-emerald-900 rounded-full overflow-hidden">
                <div className="w-2/5 h-full bg-emerald-600 rounded-full"></div>
              </div>
            </div>
            <button
              onClick={() => {
                setSelectedSurahNumber(1);
                setActivePage('quran');
              }}
              className="w-full py-2 rounded-xl bg-emerald-50 dark:bg-emerald-900/60 text-emerald-800 dark:text-amber-300 text-xs font-bold hover:bg-emerald-100 transition"
            >
              Resume Qur'an Reading
            </button>
          </div>

          {/* Card 2: Dhikr & Worship Tracker */}
          <div className="bg-white dark:bg-emerald-950/40 p-6 rounded-2xl border border-slate-200 dark:border-emerald-800 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-sm text-slate-900 dark:text-white font-serif">
                Daily Adhkar Routine
              </h3>
              <Sparkles className="w-4 h-4 text-amber-500" />
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              You have completed <strong>{tasbihTotal}</strong> total praises using the Digital Tasbih. Consistency in Dhikr polishes the heart.
            </p>
            <button
              onClick={() => setActivePage('worship')}
              className="w-full py-2 rounded-xl bg-slate-100 dark:bg-emerald-900/40 text-slate-700 dark:text-slate-200 text-xs font-semibold hover:bg-slate-200 transition"
            >
              Open Digital Tasbih
            </button>
          </div>

          {/* Card 3: Academy Enrollments */}
          <div className="bg-white dark:bg-emerald-950/40 p-6 rounded-2xl border border-slate-200 dark:border-emerald-800 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-sm text-slate-900 dark:text-white font-serif">
                Enrolled Academy Courses
              </h3>
              <Heart className="w-4 h-4 text-rose-500" />
            </div>
            <div className="space-y-1 text-xs text-slate-600 dark:text-slate-300">
              <p>• Foundations of Tajweed & Recitation (Module 1)</p>
              <p>• 40 Hadith of Imam An-Nawawi (Enrolled)</p>
            </div>
            <button
              onClick={() => setActivePage('learning')}
              className="w-full py-2 rounded-xl bg-amber-400 text-slate-950 text-xs font-bold hover:bg-amber-300 transition"
            >
              Go to Noor Academy
            </button>
          </div>
        </div>
      )}

      {/* Tab 2: Bookmarks */}
      {activeTab === 'bookmarks' && (
        <div className="space-y-4 animate-in fade-in">
          {bookmarks.length === 0 ? (
            <div className="text-center py-12 bg-white dark:bg-emerald-950/40 rounded-2xl border border-dashed border-slate-200 dark:border-emerald-800 p-8 space-y-2">
              <Bookmark className="w-8 h-8 text-slate-300 dark:text-emerald-700 mx-auto" />
              <h4 className="text-sm font-bold text-slate-700 dark:text-slate-200">No saved bookmarks yet</h4>
              <p className="text-xs text-slate-400">
                Click the bookmark icon while reading the Qur'an, Hadith, or Devotionals to save items here.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {bookmarks.map((b) => (
                <div
                  key={b.id}
                  className="p-5 bg-white dark:bg-emerald-950/40 rounded-2xl border border-slate-200 dark:border-emerald-800 shadow-sm flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between text-[10px] uppercase font-bold text-amber-600 dark:text-amber-400 mb-2">
                      <span>{b.type}</span>
                      <button
                        onClick={() => toggleBookmark(b)}
                        className="text-slate-400 hover:text-rose-500"
                        title="Remove bookmark"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <h4 className="text-sm font-bold text-slate-900 dark:text-white">{b.title}</h4>
                    {b.subtitle && (
                      <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 line-clamp-2">
                        {b.subtitle}
                      </p>
                    )}
                  </div>
                  <div className="pt-3 mt-3 border-t border-slate-100 dark:border-emerald-900/40 flex items-center justify-between text-xs text-slate-400">
                    <span>{b.pathOrRef}</span>
                    <span className="text-emerald-700 dark:text-amber-300 font-semibold cursor-pointer hover:underline">
                      View
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tab 3: Notes */}
      {activeTab === 'notes' && (
        <div className="space-y-6 animate-in fade-in">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold font-serif text-slate-900 dark:text-white">
              Personal Spiritual Reflections
            </h2>
            <button
              onClick={() => setShowNoteForm(!showNoteForm)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-800 text-white text-xs font-semibold hover:bg-emerald-700 transition"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Reflection</span>
            </button>
          </div>

          {/* New Note Form */}
          {showNoteForm && (
            <form
              onSubmit={handleCreateNote}
              className="p-6 bg-white dark:bg-emerald-950/60 rounded-2xl border border-emerald-300 dark:border-emerald-700 shadow-md space-y-4"
            >
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">Write New Note</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Title</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Lesson from Surah Al-Kahf"
                    value={newNoteTitle}
                    onChange={(e) => setNewNoteTitle(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-emerald-900 border border-slate-200 dark:border-emerald-700 text-slate-800 dark:text-slate-100"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Topic or Reference</label>
                  <input
                    type="text"
                    placeholder="e.g. Al-Kahf 18:10 or Gratitude"
                    value={newNoteTopic}
                    onChange={(e) => setNewNoteTopic(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl bg-slate-50 dark:bg-emerald-900 border border-slate-200 dark:border-emerald-700 text-slate-800 dark:text-slate-100"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">Reflection Content</label>
                <textarea
                  rows={4}
                  required
                  placeholder="Record your thoughts, lessons, and du'as..."
                  value={newNoteContent}
                  onChange={(e) => setNewNoteContent(e.target.value)}
                  className="w-full p-3 text-xs rounded-xl bg-slate-50 dark:bg-emerald-900 border border-slate-200 dark:border-emerald-700 text-slate-800 dark:text-slate-100"
                />
              </div>

              <div className="flex justify-end gap-2 text-xs">
                <button
                  type="button"
                  onClick={() => setShowNoteForm(false)}
                  className="px-4 py-2 rounded-xl border text-slate-600 dark:text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-800 text-white font-bold hover:bg-emerald-700"
                >
                  Save Note
                </button>
              </div>
            </form>
          )}

          {/* Notes Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {notes.map((note: any) => (
              <div
                key={note.id}
                className="p-5 bg-white dark:bg-emerald-950/40 rounded-2xl border border-slate-200 dark:border-emerald-800 shadow-sm space-y-2 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between text-xs text-slate-400">
                    <span className="font-semibold text-amber-600 dark:text-amber-400">{note.surahOrTopic}</span>
                    <button
                      onClick={() => deleteNote(note.id)}
                      className="text-slate-400 hover:text-rose-500"
                      title="Delete note"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <h4 className="text-sm font-bold text-slate-900 dark:text-white mt-1">{note.title}</h4>
                  <p className="text-xs text-slate-600 dark:text-slate-300 mt-2 leading-relaxed">
                    {note.content}
                  </p>
                </div>
                <div className="pt-3 text-[10px] text-slate-400 border-t border-slate-100 dark:border-emerald-900/40">
                  Recorded: {new Date(note.date).toLocaleDateString()}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
