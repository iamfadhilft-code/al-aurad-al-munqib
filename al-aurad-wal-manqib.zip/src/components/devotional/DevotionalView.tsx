import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { DevotionalItem } from '../../types';
import {
  Heart,
  Search,
  BookOpen,
  FileText,
  Music,
  Bookmark,
  Share2,
  Copy,
  ChevronRight,
  Sparkles,
  SlidersHorizontal,
} from 'lucide-react';

export const DevotionalView: React.FC = () => {
  const {
    devotionals,
    managedFiles,
    openPdf,
    playAudioTrack,
    isPlaying,
    activeAudioTrack,
    toggleBookmark,
    isBookmarked,
    showToast,
  } = useApp();

  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeReadingItem, setActiveReadingItem] = useState<DevotionalItem | null>(null);
  const [showTranslation, setShowTranslation] = useState(true);
  const [showTransliteration, setShowTransliteration] = useState(true);

  const categories = [
    { id: 'all', label: 'All Heritage' },
    { id: 'Maulid', label: 'Maulidukal (موالد)' },
    { id: 'Swalath', label: 'Swalathukal (صلوات)' },
    { id: 'Baith', label: 'Baith & Malappattu (بيوت)' },
    { id: 'Ratheeb', label: 'Ratheebat (رواتب)' },
    { id: 'Adhkar', label: 'Adhkar & Aurad (أذكار)' },
  ];

  const filteredItems = devotionals.filter((item) => {
    if (item.status !== 'published') return false;
    const matchesCat = selectedCategory === 'all' || item.category === selectedCategory;
    const matchesSearch =
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.arabicTitle.includes(searchQuery) ||
      (item.author && item.author.toLowerCase().includes(searchQuery.toLowerCase())) ||
      item.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  const handleCopyText = (item: DevotionalItem) => {
    navigator.clipboard.writeText(`${item.arabicTitle}\n${item.title}\n\n${item.arabicText}`);
    showToast(`${item.title} copied`, 'success');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-emerald-900 via-teal-950 to-amber-950 text-white rounded-2xl p-6 sm:p-8 border border-emerald-800 shadow-xl relative overflow-hidden">
        <div className="max-w-2xl space-y-2 relative z-10">
          <div className="flex items-center gap-2 text-amber-400 text-xs font-bold font-cinzel uppercase tracking-wider">
            <Heart className="w-4 h-4 text-rose-400 fill-rose-400/20" />
            <span>Sacred Devotional Heritage Diwan</span>
          </div>
          <h1 className="text-2xl sm:text-4xl font-serif font-bold tracking-tight">
            Maulid, Swalath, Baith & Ratheeb
          </h1>
          <p className="text-xs sm:text-sm text-emerald-100/90 leading-relaxed font-light">
            Immerse into centuries of praise, prophetic litanies, Malabar devotional poetry, and classical protection fortresses with synchronized recitation and illuminated manuscripts.
          </p>
        </div>
      </div>

      {/* Category Pills & Search */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 text-xs">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition font-medium ${
                selectedCategory === cat.id
                  ? 'bg-emerald-800 text-white shadow-sm'
                  : 'bg-white dark:bg-emerald-950 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-emerald-800 hover:bg-slate-50'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search Maulid, Burda, Ratheeb..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-white dark:bg-emerald-950 rounded-xl border border-slate-200 dark:border-emerald-800 text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none"
          />
        </div>
      </div>

      {/* Grid of Devotionals */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredItems.map((item) => {
          const isItemPlaying = activeAudioTrack?.id === item.id && isPlaying;
          const bookmarked = isBookmarked(item.id);

          return (
            <div
              key={item.id}
              className="bg-white dark:bg-emerald-950/40 rounded-2xl p-6 border border-slate-200/80 dark:border-emerald-800/40 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between group"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-900 text-emerald-900 dark:text-emerald-200">
                    {item.category}
                  </span>

                  <button
                    onClick={() =>
                      toggleBookmark({
                        id: item.id,
                        type: 'devotional',
                        title: item.title,
                        subtitle: item.author || item.category,
                        pathOrRef: 'Devotional Archive',
                      })
                    }
                    className={`p-1.5 rounded-lg border transition ${
                      bookmarked
                        ? 'bg-amber-400 text-slate-950 border-amber-300'
                        : 'text-slate-400 hover:text-slate-600 border-transparent hover:border-slate-200'
                    }`}
                  >
                    <Bookmark className={`w-3.5 h-3.5 ${bookmarked ? 'fill-current' : ''}`} />
                  </button>
                </div>

                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h3 className="text-base font-bold text-slate-900 dark:text-white group-hover:text-emerald-800 dark:group-hover:text-amber-300 transition">
                      {item.title}
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                      {item.author || 'Classical Islamic Heritage'}
                    </p>
                  </div>
                  <span className="font-arabic text-xl font-bold text-emerald-800 dark:text-amber-400 shrink-0">
                    {item.arabicTitle}
                  </span>
                </div>

                <p className="text-xs text-slate-600 dark:text-slate-300 mt-3 line-clamp-2 leading-relaxed">
                  {item.description}
                </p>

                {/* Excerpt of Arabic verses */}
                <div className="mt-3 p-3 rounded-xl bg-emerald-50/70 dark:bg-emerald-900/30 border border-emerald-100 dark:border-emerald-800/40 text-right">
                  <p className="font-arabic text-sm sm:text-base text-emerald-950 dark:text-emerald-200 line-clamp-2 leading-relaxed" dir="rtl">
                    {item.arabicText}
                  </p>
                </div>
              </div>

              {/* Action Buttons with Real-Time CMS Version Sync */}
              {(() => {
                // Find if an updated/live version exists in managedFiles
                const matchedFile = managedFiles.find(
                  (f) =>
                    f.status === 'published' &&
                    (f.metadata?.associatedItemSlug === item.id ||
                      f.title.toLowerCase().includes(item.title.toLowerCase()) ||
                      item.title.toLowerCase().includes(f.title.toLowerCase()))
                );
                const activePdfUrl = matchedFile?.storagePath || item.pdfUrl;
                const activeVersionStr = matchedFile ? `v${matchedFile.version}` : 'v1';

                return (
                  <div className="flex flex-wrap items-center justify-between gap-2 pt-4 mt-4 border-t border-slate-100 dark:border-emerald-900/40 text-xs">
                    <div className="flex items-center gap-2">
                      {activePdfUrl && (
                        <button
                          onClick={() => openPdf(item.title, activePdfUrl, item.author)}
                          className="flex items-center gap-1 text-slate-600 dark:text-emerald-300 hover:text-emerald-800 font-medium px-2 py-1 rounded-md bg-amber-500/10 hover:bg-amber-500/20 transition"
                          title={`Open ${matchedFile?.fileName || 'PDF'} (${activeVersionStr})`}
                        >
                          <FileText className="w-3.5 h-3.5 text-amber-500" />
                          <span>PDF</span>
                          <span className="text-[10px] font-mono px-1 py-0.2 rounded bg-amber-200 dark:bg-amber-900/60 text-amber-900 dark:text-amber-200 font-bold">
                            {activeVersionStr}
                          </span>
                        </button>
                      )}

                      {item.audioUrl && (
                        <button
                          onClick={() =>
                            playAudioTrack({
                              id: item.id,
                              title: item.title,
                              subtitle: item.author || item.category,
                              arabicTitle: item.arabicTitle,
                              audioUrl: item.audioUrl!,
                              category: item.category,
                            })
                          }
                          className={`flex items-center gap-1 font-medium px-2 py-1 rounded transition ${
                            isItemPlaying
                              ? 'bg-amber-400 text-slate-950 font-bold'
                              : 'text-slate-600 dark:text-emerald-300 hover:text-emerald-800 bg-slate-100 dark:bg-emerald-900/40'
                          }`}
                        >
                          <Music className="w-3.5 h-3.5" />
                          <span>{isItemPlaying ? 'Playing' : 'Audio'}</span>
                        </button>
                      )}
                    </div>

                    <button
                      onClick={() => setActiveReadingItem(item)}
                      className="font-bold text-emerald-800 dark:text-amber-300 hover:underline flex items-center gap-1"
                    >
                      <span>Read Full Text</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                );
              })()}
            </div>
          );
        })}
      </div>

      {/* Full Devotional Reader Modal */}
      {activeReadingItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in">
          <div className="w-full max-w-3xl max-h-[90vh] bg-white dark:bg-emerald-950 rounded-2xl shadow-2xl border border-slate-200 dark:border-emerald-800 flex flex-col overflow-hidden">
            {/* Modal Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-emerald-800 bg-emerald-900 text-white">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-amber-400 text-slate-950 font-cinzel">
                    {activeReadingItem.category}
                  </span>
                  <h3 className="text-base font-bold font-serif">{activeReadingItem.title}</h3>
                </div>
                <p className="text-xs text-emerald-200 mt-0.5">{activeReadingItem.author}</p>
              </div>

              <div className="flex items-center gap-2">
                {activeReadingItem.audioUrl && (
                  <button
                    onClick={() =>
                      playAudioTrack({
                        id: activeReadingItem.id,
                        title: activeReadingItem.title,
                        subtitle: activeReadingItem.author || 'Devotional Heritage',
                        arabicTitle: activeReadingItem.arabicTitle,
                        audioUrl: activeReadingItem.audioUrl!,
                        category: activeReadingItem.category,
                      })
                    }
                    className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-amber-400 text-slate-950 text-xs font-bold hover:bg-amber-300 transition"
                  >
                    <Music className="w-3.5 h-3.5" />
                    <span>Play Audio</span>
                  </button>
                )}

                <button
                  onClick={() => handleCopyText(activeReadingItem)}
                  className="p-1.5 rounded-lg bg-emerald-800 text-emerald-200 hover:text-white"
                  title="Copy Text"
                >
                  <Copy className="w-4 h-4" />
                </button>

                <button
                  onClick={() => setActiveReadingItem(null)}
                  className="p-1.5 rounded-lg bg-emerald-800 text-emerald-200 hover:text-white"
                >
                  ✕
                </button>
              </div>
            </div>

            {/* View toggles */}
            <div className="px-6 py-2 bg-emerald-950/40 border-b border-slate-100 dark:border-emerald-900/60 flex items-center justify-between text-xs text-slate-600 dark:text-slate-300">
              <span className="font-arabic text-lg font-bold text-amber-400">
                {activeReadingItem.arabicTitle}
              </span>

              <div className="flex items-center gap-4">
                <label className="flex items-center gap-1.5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={showTranslation}
                    onChange={(e) => setShowTranslation(e.target.checked)}
                    className="accent-emerald-600"
                  />
                  <span>Translation</span>
                </label>
                <label className="flex items-center gap-1.5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={showTransliteration}
                    onChange={(e) => setShowTransliteration(e.target.checked)}
                    className="accent-emerald-600"
                  />
                  <span>Transliteration</span>
                </label>
              </div>
            </div>

            {/* Devotional Verses Body */}
            <div className="p-6 sm:p-8 overflow-y-auto space-y-6">
              {activeReadingItem.arabicText.split('\n\n').map((stanza, idx) => (
                <div
                  key={idx}
                  className="p-4 rounded-xl bg-slate-50 dark:bg-emerald-900/20 border border-slate-100 dark:border-emerald-800/40 space-y-3"
                >
                  <p
                    className="font-arabic text-xl sm:text-2xl leading-[2.3] text-emerald-950 dark:text-emerald-100 text-right select-text"
                    dir="rtl"
                  >
                    {stanza}
                  </p>

                  {showTransliteration && activeReadingItem.transliteration && (
                    <p className="text-xs text-emerald-800 dark:text-amber-400 font-mono italic pt-2 border-t border-slate-200/60 dark:border-emerald-800/40">
                      {activeReadingItem.transliteration.split('\n\n')[idx] || activeReadingItem.transliteration}
                    </p>
                  )}

                  {showTranslation && (
                    <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed font-light">
                      {activeReadingItem.translation?.split('\n\n')[idx] || activeReadingItem.translation || activeReadingItem.description}
                    </p>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
