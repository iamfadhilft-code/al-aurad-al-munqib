import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { INITIAL_HADITHS } from '../../data/initialData';
import { Hadith } from '../../types';
import {
  BookMarked,
  Search,
  Bookmark,
  Copy,
  Share2,
  ShieldCheck,
  Filter,
  Sparkles,
} from 'lucide-react';

export const HadithView: React.FC = () => {
  const { toggleBookmark, isBookmarked, showToast } = useApp();
  const [selectedCollection, setSelectedCollection] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const collections = [
    { id: 'all', label: 'All Collections' },
    { id: 'Bukhari', label: 'Sahih al-Bukhari' },
    { id: 'Muslim', label: 'Sahih Muslim' },
    { id: 'Nawawi 40', label: 'An-Nawawi 40' },
    { id: 'Riyad as-Salihin', label: 'Riyad as-Salihin' },
  ];

  const filteredHadiths = INITIAL_HADITHS.filter((h) => {
    const matchesColl = selectedCollection === 'all' || h.collection === selectedCollection;
    const matchesSearch =
      h.translation.toLowerCase().includes(searchQuery.toLowerCase()) ||
      h.chapter.toLowerCase().includes(searchQuery.toLowerCase()) ||
      h.narrator.toLowerCase().includes(searchQuery.toLowerCase()) ||
      h.arabic.includes(searchQuery);
    return matchesColl && matchesSearch;
  });

  const handleCopy = (h: Hadith) => {
    navigator.clipboard.writeText(
      `${h.arabic}\n\n"${h.translation}"\n— ${h.narrator} [${h.reference}]`
    );
    showToast(`Hadith copied to clipboard`, 'success');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-emerald-900 to-teal-950 text-white rounded-2xl p-6 sm:p-8 border border-emerald-800 shadow-xl relative overflow-hidden">
        <div className="max-w-2xl space-y-2 relative z-10">
          <div className="flex items-center gap-2 text-amber-400 text-xs font-bold font-cinzel uppercase tracking-wider">
            <BookMarked className="w-4 h-4" />
            <span>Prophetic Traditions & Sayings</span>
          </div>
          <h1 className="text-2xl sm:text-4xl font-serif font-bold tracking-tight">
            Authentic Hadith Collections
          </h1>
          <p className="text-xs sm:text-sm text-emerald-200/90 leading-relaxed font-light">
            Explore verified traditions from the foremost canonical works with full Arabic texts, chain narrators, translations, and scholarly grading.
          </p>
        </div>
      </div>

      {/* Search & Filter Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
        {/* Collection Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 text-xs">
          {collections.map((c) => (
            <button
              key={c.id}
              onClick={() => setSelectedCollection(c.id)}
              className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition font-medium ${
                selectedCollection === c.id
                  ? 'bg-emerald-800 text-white shadow-sm'
                  : 'bg-white dark:bg-emerald-950 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-emerald-800 hover:bg-slate-50'
              }`}
            >
              {c.label}
            </button>
          ))}
        </div>

        {/* Search input */}
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search topic, narrator, or words..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-white dark:bg-emerald-950 rounded-xl border border-slate-200 dark:border-emerald-800 text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none"
          />
        </div>
      </div>

      {/* Hadiths Stream */}
      <div className="space-y-4">
        {filteredHadiths.map((h) => {
          const bookmarked = isBookmarked(h.id);
          return (
            <div
              key={h.id}
              className="bg-white dark:bg-emerald-950/40 rounded-2xl p-6 sm:p-8 border border-slate-200/80 dark:border-emerald-800/40 shadow-sm hover:shadow-md transition space-y-4"
            >
              {/* Top metadata */}
              <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-100 dark:border-emerald-900/40 text-xs">
                <div className="flex items-center gap-2">
                  <span className="font-bold px-2.5 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-900 text-emerald-900 dark:text-emerald-200 font-cinzel">
                    {h.collection}
                  </span>
                  <span className="text-slate-500 dark:text-slate-400 font-medium">
                    Chapter: {h.chapter}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <span className="flex items-center gap-1 text-[11px] font-semibold text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-900/40 px-2 py-0.5 rounded-md border border-emerald-200 dark:border-emerald-800">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Grade: {h.grade}</span>
                  </span>

                  <button
                    onClick={() =>
                      toggleBookmark({
                        id: h.id,
                        type: 'hadith',
                        title: `${h.collection} Hadith #${h.hadithNumber}`,
                        subtitle: h.translation.substring(0, 50) + '...',
                        pathOrRef: h.reference,
                      })
                    }
                    className={`p-1.5 rounded-lg border transition ${
                      bookmarked
                        ? 'bg-amber-400 text-slate-950 border-amber-300'
                        : 'text-slate-400 hover:text-slate-600 border-transparent hover:border-slate-200'
                    }`}
                    title="Bookmark Hadith"
                  >
                    <Bookmark className={`w-3.5 h-3.5 ${bookmarked ? 'fill-current' : ''}`} />
                  </button>

                  <button
                    onClick={() => handleCopy(h)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition"
                    title="Copy Hadith"
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Arabic Hadith Text */}
              <div className="text-right my-3">
                <p className="font-arabic text-xl sm:text-2xl leading-[2.2] text-emerald-950 dark:text-emerald-100 select-text" dir="rtl">
                  {h.arabic}
                </p>
              </div>

              {/* Translation & Narrator */}
              <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-emerald-900/30">
                <div className="text-xs font-semibold text-emerald-800 dark:text-amber-400 font-serif">
                  Narrated by: {h.narrator}
                </div>
                <p className="text-sm sm:text-base text-slate-700 dark:text-slate-200 leading-relaxed font-light">
                  "{h.translation}"
                </p>
              </div>

              {/* Reference footer */}
              <div className="text-[11px] text-slate-400 dark:text-emerald-400/60 font-mono pt-2">
                Reference: {h.reference}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
