import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { ManagedCategory, ManagedFileItem, FileType } from '../../types/storage';
import {
  Search,
  BookOpen,
  FileText,
  Music,
  Video,
  Image as ImageIcon,
  Download,
  Eye,
  Bookmark,
  Sparkles,
  Layers,
  ChevronRight,
  Filter,
} from 'lucide-react';
import { MANAGED_CATEGORIES, SupportedLanguage, getTranslation } from '../../i18n/translations';

export const PublicLibraryView: React.FC = () => {
  const {
    managedFiles,
    downloadManagedFile,
    previewManagedFile,
    toggleBookmark,
    isBookmarked,
    language,
  } = useApp();

  const currentLang: SupportedLanguage = language === 'ml' || language === 'ar' ? language : 'en';
  const t = getTranslation(currentLang);

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<ManagedCategory | 'all'>('all');
  const [selectedFileType, setSelectedFileType] = useState<FileType | 'all'>('all');
  const [selectedLang, setSelectedLang] = useState<'all' | 'ar' | 'ml' | 'en'>('all');

  // Filter only published files for the public website
  const publicFiles = useMemo(() => {
    return managedFiles.filter((file) => {
      // Must be published and visible
      if (file.status !== 'published') return false;

      // Category filter
      if (selectedCategory !== 'all' && file.category !== selectedCategory) return false;

      // File type filter
      if (selectedFileType !== 'all' && file.fileType !== selectedFileType) return false;

      // Language filter
      if (selectedLang !== 'all' && file.language !== selectedLang && file.language !== 'all') {
        return false;
      }

      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchTitle = file.title.toLowerCase().includes(q);
        const matchMl = file.titleMalayalam?.toLowerCase().includes(q) || false;
        const matchAr = file.titleArabic?.toLowerCase().includes(q) || false;
        const matchAuthor = file.author.toLowerCase().includes(q);
        const matchDesc = file.description.toLowerCase().includes(q);
        const matchFileName = file.fileName.toLowerCase().includes(q);

        if (!matchTitle && !matchMl && !matchAr && !matchAuthor && !matchDesc && !matchFileName) {
          return false;
        }
      }

      return true;
    });
  }, [managedFiles, selectedCategory, selectedFileType, selectedLang, searchQuery]);

  // Selected Category Info
  const currentCategoryInfo = useMemo(() => {
    if (selectedCategory === 'all') return null;
    return MANAGED_CATEGORIES.find((c) => c.id === selectedCategory);
  }, [selectedCategory]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-in fade-in duration-300">
      {/* Hero Header */}
      <div className="bg-gradient-to-r from-emerald-950 via-teal-950 to-slate-900 text-white rounded-3xl p-6 sm:p-10 border border-emerald-800/40 shadow-2xl relative overflow-hidden">
        <div className="relative z-10 max-w-3xl space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-semibold uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5" />
            <span>16 Authentic Categories · Verified Manuscripts</span>
          </div>

          <h1 className="text-2xl sm:text-4xl font-serif font-bold tracking-tight text-white">
            {t.libraryTitle}
          </h1>

          <p className="text-xs sm:text-sm text-emerald-200/80 leading-relaxed max-w-2xl font-light">
            {t.librarySub}
          </p>

          <div className="pt-2 flex flex-wrap items-center gap-4 text-xs text-slate-300">
            <span className="flex items-center gap-1.5 font-medium">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              Directly synced with Curated Admin Repository
            </span>
            <span>•</span>
            <span className="font-mono">{publicFiles.length} Live Publications</span>
          </div>
        </div>
      </div>

      {/* 16 Categories Grid / Pills */}
      <div>
        <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 font-semibold mb-3">
          <span className="uppercase tracking-wider">Browse by Category (16 വിഭാഗങ്ങൾ)</span>
          <button
            onClick={() => setSelectedCategory('all')}
            className={`text-xs hover:underline ${selectedCategory === 'all' ? 'text-emerald-700 font-bold' : ''}`}
          >
            {t.allCategories} ({managedFiles.filter((f) => f.status === 'published').length})
          </button>
        </div>

        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-thin">
          <button
            onClick={() => setSelectedCategory('all')}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 shrink-0 transition ${
              selectedCategory === 'all'
                ? 'bg-emerald-800 text-white shadow-sm'
                : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-800 hover:bg-slate-50'
            }`}
          >
            <span>✨</span>
            <span>{t.allCategories}</span>
          </button>

          {MANAGED_CATEGORIES.map((cat) => {
            const count = managedFiles.filter((f) => f.status === 'published' && f.category === cat.id).length;
            const isSelected = selectedCategory === cat.id;
            const label = currentLang === 'ml' ? cat.titleMl : currentLang === 'ar' ? cat.titleAr : cat.titleEn;

            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 shrink-0 transition ${
                  isSelected
                    ? 'bg-emerald-800 text-white shadow-sm'
                    : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800'
                }`}
              >
                <span>{cat.emoji}</span>
                <span>{label}</span>
                <span className="opacity-70 font-mono text-[10px]">({count})</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        {/* Search */}
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={t.searchPlaceholder}
            className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-white text-xs placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500"
          />
        </div>

        {/* Media Type & Language Filters */}
        <div className="flex items-center gap-2">
          {/* File Type Filter */}
          <select
            value={selectedFileType}
            onChange={(e) => setSelectedFileType(e.target.value as any)}
            className="px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200 text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500"
          >
            <option value="all">All Media</option>
            <option value="pdf">📄 PDF Books</option>
            <option value="audio">🎧 Audio</option>
            <option value="video">🎥 Video</option>
            <option value="image">🖼️ Images</option>
            <option value="doc">📝 Documents</option>
          </select>

          {/* Language Filter */}
          <select
            value={selectedLang}
            onChange={(e) => setSelectedLang(e.target.value as any)}
            className="px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200 text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500"
          >
            <option value="all">{t.allLanguages}</option>
            <option value="ar">Arabic (العربية)</option>
            <option value="ml">Malayalam (മലയാളം)</option>
            <option value="en">English</option>
          </select>
        </div>
      </div>

      {/* Selected Category Header Banner if any */}
      {currentCategoryInfo && (
        <div className="p-4 rounded-2xl bg-emerald-50/80 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="text-3xl">{currentCategoryInfo.emoji}</span>
            <div>
              <h2 className="font-bold text-slate-900 dark:text-white text-base">
                {currentLang === 'ml' ? currentCategoryInfo.titleMl : currentLang === 'ar' ? currentCategoryInfo.titleAr : currentCategoryInfo.titleEn}
              </h2>
              <p className="text-xs text-slate-600 dark:text-slate-300">
                {currentLang === 'ml' ? currentCategoryInfo.descMl : currentLang === 'ar' ? currentCategoryInfo.descAr : currentCategoryInfo.descEn}
              </p>
            </div>
          </div>
          <button
            onClick={() => setSelectedCategory('all')}
            className="text-xs font-semibold text-emerald-800 dark:text-emerald-400 hover:underline"
          >
            Clear Filter
          </button>
        </div>
      )}

      {/* Publications Cards Grid */}
      {publicFiles.length === 0 ? (
        <div className="p-16 text-center rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-500">
          <BookOpen className="w-10 h-10 mx-auto mb-3 opacity-40 text-slate-400" />
          <h3 className="font-bold text-base text-slate-800 dark:text-slate-200">No Publications Found</h3>
          <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
            No active documents match your search or filter. Switch categories or upload from the Admin Panel.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {publicFiles.map((file) => {
            const catDef = MANAGED_CATEGORIES.find((c) => c.id === file.category);
            const catName = currentLang === 'ml' ? catDef?.titleMl : currentLang === 'ar' ? catDef?.titleAr : catDef?.titleEn;
            const bookmarked = isBookmarked(file.id);

            return (
              <div
                key={file.id}
                className="group p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm hover:shadow-md transition flex flex-col justify-between"
              >
                <div>
                  {/* Category Pill & Version Pill */}
                  <div className="flex items-center justify-between gap-2 mb-2.5">
                    <span className="text-xs px-2.5 py-1 rounded-lg bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-300 font-semibold flex items-center gap-1.5">
                      <span>{catDef?.emoji}</span>
                      <span>{catName}</span>
                    </span>

                    <div className="flex items-center gap-1.5">
                      <span className="px-2 py-0.5 rounded font-mono font-bold text-[11px] bg-purple-100 text-purple-800 dark:bg-purple-950/60 dark:text-purple-300 border border-purple-200 dark:border-purple-800">
                        v{file.version}
                      </span>
                      <button
                        onClick={() =>
                          toggleBookmark({
                            id: file.id,
                            type: 'devotional',
                            title: file.title,
                            subtitle: file.author,
                            pathOrRef: file.category,
                          })
                        }
                        className={`p-1 rounded-md transition ${
                          bookmarked ? 'text-amber-500' : 'text-slate-400 hover:text-slate-600'
                        }`}
                        title="Bookmark"
                      >
                        <Bookmark className={`w-3.5 h-3.5 ${bookmarked ? 'fill-current' : ''}`} />
                      </button>
                    </div>
                  </div>

                  {/* Title & Multilingual Subtitles */}
                  <h3 className="font-bold text-slate-900 dark:text-white text-base leading-snug group-hover:text-emerald-800 dark:group-hover:text-emerald-400 transition">
                    {file.title}
                  </h3>
                  {file.titleArabic && (
                    <p className="text-xs font-arabic font-semibold text-emerald-700 dark:text-emerald-400 mt-1" dir="rtl">
                      {file.titleArabic}
                    </p>
                  )}
                  {file.titleMalayalam && (
                    <p className="text-xs font-medium text-slate-600 dark:text-slate-400 mt-0.5">
                      {file.titleMalayalam}
                    </p>
                  )}

                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-2.5 line-clamp-2 leading-relaxed">
                    {file.description}
                  </p>

                  {/* File Metadata Details */}
                  <div className="mt-3.5 p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 text-[11px] font-mono text-slate-600 dark:text-slate-400 flex items-center justify-between">
                    <span>{file.author}</span>
                    <span>{file.fileSize}</span>
                  </div>
                </div>

                {/* Card Action Controls */}
                <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    {/* Read / Preview */}
                    <button
                      onClick={() => previewManagedFile(file)}
                      className="px-3.5 py-1.5 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-bold flex items-center gap-1.5 shadow-sm transition"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>{t.preview}</span>
                    </button>

                    {/* Download */}
                    <button
                      onClick={() => downloadManagedFile(file)}
                      className="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold flex items-center gap-1.5 transition"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>{t.download}</span>
                    </button>
                  </div>

                  {/* Version details tooltip */}
                  <span className="text-[10px] text-slate-400 font-mono">
                    Updated {file.updatedDate}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
