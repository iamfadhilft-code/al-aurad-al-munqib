import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { useApp } from '../../context/AppContext';
import { DailyAuradItem, DailyDhikrProgress, DevotionalItem, Article } from '../../types';
import { ManagedFileItem, ManagedCategory } from '../../types/storage';
import { FirebaseDataService } from '../../services/firebase';
import {
  CheckCircle,
  CheckCircle2,
  Clock,
  RotateCcw,
  Sparkles,
  Cloud,
  Plus,
  RefreshCw,
  BookOpen,
  Flame,
  Award,
  Calendar as CalendarIcon,
  ChevronLeft,
  ChevronRight,
  PlusCircle,
  X,
  Info,
} from 'lucide-react';

export const INITIAL_AURAD: DailyAuradItem[] = [
  {
    id: 'aurad-haddad',
    title: 'Ratheeb al-Haddad',
    arabicTitle: 'راتب الحداد المبارك',
    malayalamTitle: 'റാത്തീബുൽ ഹദ്ദാദ്',
    category: 'ratheeb',
    recommendedTime: 'Evening',
    targetCount: 1,
    virtueDescription: 'Composed by Imam Abdullah ibn Alawi al-Haddad. A spiritual fortress for protection of self, family, and home with immense barakah.',
  },
  {
    id: 'aurad-wird-latif',
    title: 'Al-Wird al-Latif',
    arabicTitle: 'الورد اللطيف للحداد',
    malayalamTitle: 'വിർദുൽ ലത്തീഫ്',
    category: 'wird',
    recommendedTime: 'Morning',
    targetCount: 1,
    virtueDescription: 'Prophetic adhkar compilation recited after Fajr and Asr for morning peace, illumination, and angelic protection throughout the day.',
  },
  {
    id: 'aurad-attas',
    title: 'Ratheeb al-Attas',
    arabicTitle: 'راتب العطاس الشريف',
    malayalamTitle: 'റാത്തീബുൽ അത്താസ്',
    category: 'ratheeb',
    recommendedTime: 'Evening',
    targetCount: 1,
    virtueDescription: 'Composed by Habib Umar ibn Abd al-Rahman al-Attas. Known to alleviate difficulties and draw divine assistance.',
  },
  {
    id: 'aurad-sayyidul-istighfar',
    title: 'Sayyidul Istighfar & Daily Repentance',
    arabicTitle: 'سيد الاستغفار والاستغفار اليومي',
    malayalamTitle: 'സയ്യിദുൽ ഇസ്തിഗ്ഫാർ',
    category: 'istighfar',
    recommendedTime: 'Morning',
    targetCount: 100,
    virtueDescription: 'The master supplication for seeking forgiveness. Whoever says it in day or night with conviction enters Paradise.',
  },
  {
    id: 'aurad-salawat-prophet',
    title: 'Salawat on Beloved Prophet ﷺ',
    arabicTitle: 'الصلاة والسلام على النبي ﷺ',
    malayalamTitle: 'സ്വലാത്ത്',
    category: 'salawat',
    recommendedTime: 'Anytime',
    targetCount: 100,
    virtueDescription: 'Whoever blesses the Prophet ﷺ once, Allah blesses him ten times, wipes away ten sins, and raises him ten degrees.',
  },
  {
    id: 'aurad-tahlil',
    title: 'Tahlil & Kalimah at-Tawheed',
    arabicTitle: 'لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ',
    malayalamTitle: 'കലിമത്തു തൗഹീദ്',
    category: 'tahlil',
    recommendedTime: 'Anytime',
    targetCount: 100,
    virtueDescription: 'The best dhikr is La ilaha illallah. Equivalent to freeing slaves, earns 100 rewards, and guards against Shaytan.',
  },
  {
    id: 'aurad-subhanallah-wa-bihamdihi',
    title: 'Subhanallahi wa bihamdihi',
    arabicTitle: 'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ',
    malayalamTitle: 'സുബ്ഹാനല്ലാഹി വബിഹംദിഹി',
    category: 'tahlil',
    recommendedTime: 'Morning',
    targetCount: 100,
    virtueDescription: 'Recited 100 times daily, sins are forgiven even if they were like the foam of the sea.',
  },
  {
    id: 'aurad-ayatul-kursi',
    title: 'Ayat al-Kursi & Mu’awwidhat (Post-Salah)',
    arabicTitle: 'آية الكرسي والمعوذتان دبر كل صلاة',
    malayalamTitle: 'ആയത്തുൽ കുർസി',
    category: 'quran',
    recommendedTime: 'After Salah',
    targetCount: 5,
    virtueDescription: 'Whoever recites Ayat al-Kursi after each obligatory prayer, nothing stands between him and entering Paradise except death.',
  },
  {
    id: 'aurad-waqiah',
    title: 'Surah Al-Waqi’ah',
    arabicTitle: 'سورة الواقعة المباركة',
    malayalamTitle: 'സൂറത്തുൽ വാഖിഅ',
    category: 'quran',
    recommendedTime: 'Evening',
    targetCount: 1,
    virtueDescription: 'Traditional post-Maghrib recitation. Safeguards against poverty and invokes abundant spiritual and physical sustenance.',
  },
  {
    id: 'aurad-mulk',
    title: 'Surah Al-Mulk',
    arabicTitle: 'سورة الملك المنجية',
    malayalamTitle: 'സൂറത്തുൽ മുൽക്',
    category: 'quran',
    recommendedTime: 'Night',
    targetCount: 1,
    virtueDescription: 'The protector from the punishment of the grave. The Prophet ﷺ would not sleep until he had recited it.',
  },
  {
    id: 'aurad-hizb-nasr',
    title: 'Hizb an-Nasr (Litany of Victory)',
    arabicTitle: 'حزب النصر المبارك',
    malayalamTitle: 'ഹിസ്ബുന്നസ്ർ',
    category: 'wird',
    recommendedTime: 'Night',
    targetCount: 1,
    virtueDescription: 'Recited for spiritual fortitude, overcoming oppressive trials, and seeking divine aid and sanctuary.',
  },
  {
    id: 'aurad-tasbih-fatimi',
    title: 'Tasbih Fatimi (33 Subhanallah, 33 Alhamdulillah, 34 Allahu Akbar)',
    arabicTitle: 'تسبيح الزهراء فاطمة رضي الله عنها',
    malayalamTitle: 'തസ്ബീഹു ഫാതിമി',
    category: 'tahlil',
    recommendedTime: 'After Salah',
    targetCount: 100,
    virtueDescription: 'The blessed dhikr gifted by the Prophet ﷺ to Sayyidah Fatimah (RA) and recited after obligatory prayers and before sleeping.',
  },
];

export const DailyDhikrTracker: React.FC = () => {
  const { currentUser, isFirestoreConnected, showToast, setActivePage, openPdf } = useApp();

  // Selected date for tracking (defaults to today)
  const [selectedDate, setSelectedDate] = useState<string>(() => {
    return new Date().toISOString().split('T')[0];
  });

  // Category filter
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  // Custom aurad items created by the user
  const [customItems, setCustomItems] = useState<DailyAuradItem[]>(() => {
    try {
      const saved = localStorage.getItem('noor_custom_aurad');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Combined aurad items
  const allAuradItems = useMemo(() => {
    return [...INITIAL_AURAD, ...customItems];
  }, [customItems]);

  // Counts state: itemId -> number
  const [counts, setCounts] = useState<Record<string, number>>({});
  // Completed state: itemId -> boolean
  const [completed, setCompleted] = useState<Record<string, boolean>>({});

  // Cloud sync state
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [lastSyncedAt, setLastSyncedAt] = useState<string | null>(null);

  // New custom Aurad modal
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newArabicTitle, setNewArabicTitle] = useState('');
  const [newMalayalamTitle, setNewMalayalamTitle] = useState('');
  const [newCategory, setNewCategory] = useState<'ratheeb' | 'wird' | 'salawat' | 'istighfar' | 'quran' | 'tahlil'>('wird');
  const [newRecommendedTime, setNewRecommendedTime] = useState<'Morning' | 'Evening' | 'After Salah' | 'Night' | 'Anytime'>('Morning');
  const [newTargetCount, setNewTargetCount] = useState<number>(33);
  const [newVirtue, setNewVirtue] = useState('');

  // Storage key for local cache
  const storageKey = useMemo(() => {
    const userPrefix = currentUser?.uid ? `uid_${currentUser.uid}` : 'guest';
    return `noor_dhikr_${userPrefix}_${selectedDate}`;
  }, [currentUser?.uid, selectedDate]);

  // Firestore document ID
  const firestoreDocId = useMemo(() => {
    const userPrefix = currentUser?.uid ? currentUser.uid : 'device_local';
    return `dhikr-${userPrefix}-${selectedDate}`;
  }, [currentUser?.uid, selectedDate]);

  // Load progress on date or user change (offline cache first, then Firestore)
  useEffect(() => {
    let isMounted = true;

    // 1. Try local cache for immediate display
    try {
      const cached = localStorage.getItem(storageKey);
      if (cached) {
        const parsed = JSON.parse(cached);
        if (parsed.counts) setCounts(parsed.counts);
        if (parsed.completed) setCompleted(parsed.completed);
        if (parsed.updatedAt) setLastSyncedAt(new Date(parsed.updatedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
      } else {
        setCounts({});
        setCompleted({});
        setLastSyncedAt(null);
      }
    } catch (e) {
      console.warn('Local dhikr load error:', e);
    }

    // 2. Fetch from Firestore
    async function fetchFromFirestore() {
      try {
        setIsSyncing(true);
        const remoteData = await FirebaseDataService.getDailyDhikrProgress(firestoreDocId);
        if (isMounted && remoteData) {
          setCounts(remoteData.counts || {});
          setCompleted(remoteData.completed || {});
          setLastSyncedAt(new Date(remoteData.updatedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
          // Update cache
          localStorage.setItem(storageKey, JSON.stringify(remoteData));
        }
      } catch (err) {
        console.warn('Firestore dhikr load notice:', err);
      } finally {
        if (isMounted) setIsSyncing(false);
      }
    }

    fetchFromFirestore();

    return () => {
      isMounted = false;
    };
  }, [selectedDate, storageKey, firestoreDocId]);

  // Calculate totals
  const totalDhikrRecited = useMemo(() => {
    return Object.values(counts).reduce((acc, curr) => acc + (Number(curr) || 0), 0);
  }, [counts]);

  const completedAuradCount = useMemo(() => {
    return Object.values(completed).filter(Boolean).length;
  }, [completed]);

  const progressPercentage = useMemo(() => {
    if (allAuradItems.length === 0) return 0;
    return Math.min(100, Math.round((completedAuradCount / allAuradItems.length) * 100));
  }, [completedAuradCount, allAuradItems.length]);

  // Save to Firestore & Local Storage
  const persistProgress = useCallback(
    async (
      updatedCounts: Record<string, number>,
      updatedCompleted: Record<string, boolean>,
      showToastFeedback = false
    ) => {
      const totalRecited = Object.values(updatedCounts).reduce((acc, curr) => acc + (Number(curr) || 0), 0);
      const totalCompleted = Object.values(updatedCompleted).filter(Boolean).length;
      const nowIso = new Date().toISOString();

      const progressRecord: DailyDhikrProgress = {
        id: firestoreDocId,
        userId: currentUser?.uid,
        userEmail: currentUser?.email || undefined,
        date: selectedDate,
        counts: updatedCounts,
        completed: updatedCompleted,
        totalDhikrCount: totalRecited,
        completedAuradCount: totalCompleted,
        updatedAt: nowIso,
      };

      // 1. Save to localStorage immediately
      try {
        localStorage.setItem(storageKey, JSON.stringify(progressRecord));
      } catch (e) {
        console.warn('LocalStorage save error:', e);
      }

      // 2. Save to Firestore
      try {
        setIsSyncing(true);
        await FirebaseDataService.saveDailyDhikrProgress(progressRecord);
        setLastSyncedAt(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
        if (showToastFeedback) {
          showToast('Daily Dhikr progress saved securely to Firestore cloud!', 'success');
        }
      } catch (e: any) {
        console.warn('Firestore save notice:', e?.message || e);
        if (showToastFeedback) {
          showToast('Progress saved locally. Will sync to Firestore automatically.', 'info');
        }
      } finally {
        setIsSyncing(false);
      }
    },
    [firestoreDocId, currentUser, selectedDate, storageKey, showToast]
  );

  // Increment item count
  const handleIncrement = (itemId: string, incrementBy: number, target: number) => {
    const current = counts[itemId] || 0;
    const next = current + incrementBy;
    const isNowDone = next >= target;

    const updatedCounts = { ...counts, [itemId]: next };
    const updatedCompleted = { ...completed, [itemId]: isNowDone };

    setCounts(updatedCounts);
    setCompleted(updatedCompleted);
    persistProgress(updatedCounts, updatedCompleted, false);
  };

  // Set specific count
  const handleSetCount = (itemId: string, val: number, target: number) => {
    const cleanVal = Math.max(0, val || 0);
    const isNowDone = cleanVal >= target;

    const updatedCounts = { ...counts, [itemId]: cleanVal };
    const updatedCompleted = { ...completed, [itemId]: isNowDone };

    setCounts(updatedCounts);
    setCompleted(updatedCompleted);
    persistProgress(updatedCounts, updatedCompleted, false);
  };

  // Toggle completion status
  const handleToggleComplete = (itemId: string, target: number) => {
    const isCurrentlyDone = !!completed[itemId];
    const newDone = !isCurrentlyDone;

    const updatedCompleted = { ...completed, [itemId]: newDone };
    // If completing and current count was 0, auto-fill to target
    const currentVal = counts[itemId] || 0;
    const updatedCounts = {
      ...counts,
      [itemId]: newDone && currentVal < target ? target : currentVal,
    };

    setCounts(updatedCounts);
    setCompleted(updatedCompleted);
    persistProgress(updatedCounts, updatedCompleted, false);
  };

  // Reset single item
  const handleResetItem = (itemId: string) => {
    const updatedCounts = { ...counts, [itemId]: 0 };
    const updatedCompleted = { ...completed, [itemId]: false };

    setCounts(updatedCounts);
    setCompleted(updatedCompleted);
    persistProgress(updatedCounts, updatedCompleted, false);
    showToast('Item count reset.', 'info');
  };

  // Reset entire day
  const handleResetDay = () => {
    if (!window.confirm(`Are you sure you want to reset all Dhikr logged for ${selectedDate}?`)) {
      return;
    }
    const emptyCounts: Record<string, number> = {};
    const emptyCompleted: Record<string, boolean> = {};
    setCounts(emptyCounts);
    setCompleted(emptyCompleted);
    persistProgress(emptyCounts, emptyCompleted, true);
  };

  // Add custom Aurad
  const handleAddCustomAurad = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) {
      showToast('Please provide a title for the litany.', 'warning');
      return;
    }

    const newItem: DailyAuradItem = {
      id: 'custom-' + Date.now(),
      title: newTitle.trim(),
      arabicTitle: newArabicTitle.trim() || newTitle.trim(),
      malayalamTitle: newMalayalamTitle.trim() || undefined,
      category: newCategory,
      recommendedTime: newRecommendedTime,
      targetCount: Math.max(1, newTargetCount || 1),
      virtueDescription: newVirtue.trim() || 'Custom devotional remembrance.',
    };

    const updatedCustom = [newItem, ...customItems];
    setCustomItems(updatedCustom);
    localStorage.setItem('noor_custom_aurad', JSON.stringify(updatedCustom));

    setIsAddModalOpen(false);
    setNewTitle('');
    setNewArabicTitle('');
    setNewMalayalamTitle('');
    setNewVirtue('');
    showToast(`Added "${newItem.title}" to your Daily Aurad tracker.`, 'success');
  };

  // Date shifting
  const shiftDate = (days: number) => {
    const d = new Date(selectedDate);
    d.setDate(d.getDate() + days);
    setSelectedDate(d.toISOString().split('T')[0]);
  };

  const isToday = selectedDate === new Date().toISOString().split('T')[0];

  // Filter items
  const filteredItems = useMemo(() => {
    if (selectedCategory === 'all') return allAuradItems;
    return allAuradItems.filter((it) => it.category === selectedCategory);
  }, [allAuradItems, selectedCategory]);

  return (
    <div className="space-y-6 animate-in fade-in" id="daily-dhikr-tracker">
      {/* Top Banner & Date Controls */}
      <div className="bg-gradient-to-r from-emerald-900 via-teal-950 to-emerald-950 text-white rounded-2xl p-6 sm:p-8 border border-emerald-800 shadow-xl flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
        <div className="space-y-2 max-w-2xl">
          <div className="flex items-center gap-2 text-amber-400 text-xs font-bold uppercase tracking-wider font-cinzel">
            <Sparkles className="w-4 h-4" />
            <span>Spiritual Fortress & Remembrance Hub</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-serif font-bold text-white">
            Daily Dhikr & Aurad Tracker · سجل الأوراد اليومية
          </h2>
          <p className="text-xs sm:text-sm text-emerald-200/90 leading-relaxed">
            Record your recitation of Imam al-Haddad’s litanies, daily Ratheebs, Salawat, Quranic protections, and Wirds. All counts are saved directly to Cloud Firestore.
          </p>
        </div>

        {/* Date Selector & Cloud Status */}
        <div className="flex flex-col sm:flex-row lg:flex-col items-start sm:items-center lg:items-end gap-3 w-full lg:w-auto">
          {/* Date Picker Switcher */}
          <div className="flex items-center gap-2 bg-emerald-950/80 px-3 py-2 rounded-xl border border-emerald-700">
            <button
              onClick={() => shiftDate(-1)}
              title="Previous Day"
              className="p-1 hover:bg-emerald-800 rounded-lg text-emerald-300 hover:text-white transition"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-1.5 px-2">
              <CalendarIcon className="w-4 h-4 text-amber-400" />
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="bg-transparent text-white text-xs font-bold font-mono focus:outline-none cursor-pointer"
              />
            </div>

            <button
              onClick={() => shiftDate(1)}
              title="Next Day"
              className="p-1 hover:bg-emerald-800 rounded-lg text-emerald-300 hover:text-white transition"
            >
              <ChevronRight className="w-4 h-4" />
            </button>

            {!isToday && (
              <button
                onClick={() => setSelectedDate(new Date().toISOString().split('T')[0])}
                className="text-[10px] uppercase font-bold px-2 py-1 bg-amber-400 text-emerald-950 rounded-md hover:bg-amber-300 ml-1"
              >
                Today
              </button>
            )}
          </div>

          {/* Cloud Sync Status Indicator */}
          <div className="flex items-center gap-2 text-[11px] text-emerald-300 bg-emerald-950/60 px-3 py-1.5 rounded-lg border border-emerald-800/80">
            <Cloud className={`w-3.5 h-3.5 ${isSyncing ? 'animate-pulse text-amber-400' : 'text-emerald-400'}`} />
            <span>
              {isSyncing ? (
                'Syncing with Firestore...'
              ) : lastSyncedAt ? (
                `Synced to Cloud at ${lastSyncedAt}`
              ) : isFirestoreConnected ? (
                'Cloud Firestore Connected'
              ) : (
                'Local Storage (Cloud sync ready)'
              )}
            </span>
            <button
              onClick={() => persistProgress(counts, completed, true)}
              title="Force Sync with Firestore"
              disabled={isSyncing}
              className="ml-1 p-1 hover:bg-emerald-800 rounded text-amber-400 hover:text-amber-300 transition"
            >
              <RefreshCw className={`w-3 h-3 ${isSyncing ? 'animate-spin' : ''}`} />
            </button>
          </div>
        </div>
      </div>

      {/* Stats Summary Bento Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-emerald-950/40 p-5 rounded-2xl border border-slate-200/80 dark:border-emerald-800/40 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-emerald-100 dark:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300 flex items-center justify-center shrink-0">
            <Sparkles className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider block">
              Total Dhikr Recited
            </span>
            <span className="text-2xl font-bold font-mono text-emerald-950 dark:text-amber-300">
              {totalDhikrRecited.toLocaleString()}
            </span>
          </div>
        </div>

        <div className="bg-white dark:bg-emerald-950/40 p-5 rounded-2xl border border-slate-200/80 dark:border-emerald-800/40 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-amber-100 dark:bg-amber-900/40 text-amber-700 dark:text-amber-300 flex items-center justify-center shrink-0">
            <CheckCircle className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider block">
              Completed Litanies
            </span>
            <span className="text-2xl font-bold font-mono text-slate-900 dark:text-white">
              {completedAuradCount} <span className="text-sm text-slate-400 font-normal">/ {allAuradItems.length}</span>
            </span>
          </div>
        </div>

        <div className="bg-white dark:bg-emerald-950/40 p-5 rounded-2xl border border-slate-200/80 dark:border-emerald-800/40 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-teal-100 dark:bg-teal-900/40 text-teal-700 dark:text-teal-300 flex items-center justify-center shrink-0">
            <Award className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider block">
              Daily Goal Progress
            </span>
            <span className="text-2xl font-bold font-mono text-emerald-800 dark:text-emerald-400">
              {progressPercentage}%
            </span>
          </div>
        </div>

        <div className="bg-white dark:bg-emerald-950/40 p-5 rounded-2xl border border-slate-200/80 dark:border-emerald-800/40 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-purple-100 dark:bg-purple-900/40 text-purple-700 dark:text-purple-300 flex items-center justify-center shrink-0">
            <Flame className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider block">
              Active User
            </span>
            <span className="text-xs font-bold text-slate-900 dark:text-white truncate block max-w-[150px]">
              {currentUser?.displayName || currentUser?.email || 'Devotee (Offline Sync)'}
            </span>
            <span className="text-[10px] text-emerald-600 dark:text-emerald-400">
              {currentUser ? 'Authenticated Profile' : 'Local Guest Account'}
            </span>
          </div>
        </div>
      </div>

      {/* Progress Bar Header */}
      <div className="bg-white dark:bg-emerald-950/40 p-4 rounded-2xl border border-slate-200/80 dark:border-emerald-800/40 shadow-sm space-y-2">
        <div className="flex items-center justify-between text-xs font-semibold text-slate-600 dark:text-slate-300">
          <span>Daily Aurad Completion Bar</span>
          <span className="font-mono text-emerald-800 dark:text-amber-400 font-bold">{progressPercentage}% Completed</span>
        </div>
        <div className="w-full h-3 bg-slate-100 dark:bg-emerald-900/50 rounded-full overflow-hidden">
          <div
            style={{ width: `${progressPercentage}%` }}
            className="h-full bg-gradient-to-r from-emerald-600 to-amber-400 transition-all duration-300 rounded-full"
          />
        </div>
      </div>

      {/* Action Bar: Categories, Add Custom & Reset */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pt-2">
        {/* Category Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs w-full sm:w-auto">
          {[
            { id: 'all', label: 'All Aurad' },
            { id: 'ratheeb', label: 'Ratheeb' },
            { id: 'wird', label: 'Wird & Hizb' },
            { id: 'salawat', label: 'Salawat' },
            { id: 'istighfar', label: 'Istighfar' },
            { id: 'tahlil', label: 'Tahlil' },
            { id: 'quran', label: 'Quranic' },
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3 py-1.5 rounded-xl font-medium whitespace-nowrap transition ${
                selectedCategory === cat.id
                  ? 'bg-emerald-800 text-white shadow-sm'
                  : 'bg-white dark:bg-emerald-950/60 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-emerald-800 hover:bg-slate-50'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2 self-end sm:self-auto shrink-0">
          <button
            onClick={() => setIsAddModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold shadow-sm transition"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            <span>Add Custom Wird</span>
          </button>

          <button
            onClick={handleResetDay}
            title="Reset counts for this day"
            className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 text-xs font-semibold border border-rose-200 dark:border-rose-900 hover:bg-rose-100 transition"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Reset Day</span>
          </button>
        </div>
      </div>

      {/* Dhikr Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredItems.map((item) => {
          const count = counts[item.id] || 0;
          const isDone = !!completed[item.id] || count >= item.targetCount;
          const pct = Math.min(100, Math.round((count / item.targetCount) * 100));

          return (
            <div
              key={item.id}
              className={`p-5 rounded-2xl border transition duration-200 relative flex flex-col justify-between ${
                isDone
                  ? 'bg-emerald-50/70 dark:bg-emerald-950/60 border-emerald-400 dark:border-emerald-700/80 shadow-md ring-1 ring-emerald-500/30'
                  : 'bg-white dark:bg-emerald-950/30 border-slate-200/80 dark:border-emerald-800/40 shadow-sm hover:border-emerald-300 dark:hover:border-emerald-700'
              }`}
            >
              {/* Card Header: Titles & Timing */}
              <div>
                <div className="flex items-start justify-between gap-3">
                  <div className="space-y-0.5 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md bg-emerald-100 dark:bg-emerald-900 text-emerald-800 dark:text-emerald-300 font-mono">
                        {item.recommendedTime}
                      </span>
                      <span className="text-[10px] uppercase font-semibold text-slate-400 dark:text-slate-500">
                        {item.category}
                      </span>
                    </div>
                    <h3 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white font-serif mt-1">
                      {item.title}
                    </h3>
                    {item.malayalamTitle && (
                      <span className="text-xs text-emerald-700 dark:text-emerald-400 font-medium block">
                        {item.malayalamTitle}
                      </span>
                    )}
                  </div>

                  {/* Completion Toggle */}
                  <button
                    onClick={() => handleToggleComplete(item.id, item.targetCount)}
                    title={isDone ? 'Mark Incomplete' : 'Mark as Completed'}
                    className={`p-2 rounded-xl border transition ${
                      isDone
                        ? 'bg-emerald-700 text-white border-emerald-600 shadow-sm'
                        : 'bg-slate-50 dark:bg-emerald-900/40 text-slate-400 dark:text-slate-300 border-slate-200 dark:border-emerald-800 hover:border-emerald-500'
                    }`}
                  >
                    <CheckCircle2 className="w-5 h-5" />
                  </button>
                </div>

                {/* Arabic Calligraphy Style Title */}
                <div className="my-2 p-2.5 rounded-xl bg-emerald-50/50 dark:bg-emerald-900/30 border border-emerald-100 dark:border-emerald-800/60 text-right">
                  <span className="font-arabic text-xl font-bold text-emerald-950 dark:text-amber-300 leading-loose" dir="rtl">
                    {item.arabicTitle}
                  </span>
                </div>

                {/* Virtue Hint */}
                {item.virtueDescription && (
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-2 leading-relaxed">
                    {item.virtueDescription}
                  </p>
                )}
              </div>

              {/* Card Footer: Progress Bar, Counts & Controls */}
              <div className="mt-4 pt-3 border-t border-slate-100 dark:border-emerald-900/50 space-y-3">
                {/* Progress Indicators */}
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1.5">
                    <span className="text-slate-500 dark:text-slate-400 text-[11px]">Logged:</span>
                    <input
                      type="number"
                      min="0"
                      value={count}
                      onChange={(e) => handleSetCount(item.id, parseInt(e.target.value) || 0, item.targetCount)}
                      className="w-16 px-2 py-0.5 rounded-md border border-slate-200 dark:border-emerald-800 bg-white dark:bg-emerald-950 font-mono font-bold text-slate-900 dark:text-white text-xs focus:ring-1 focus:ring-emerald-500 focus:outline-none text-center"
                    />
                    <span className="text-slate-400 font-mono">/ {item.targetCount}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-xs text-emerald-700 dark:text-amber-400">
                      {pct}%
                    </span>
                    <button
                      onClick={() => handleResetItem(item.id)}
                      title="Reset item count"
                      className="p-1 text-slate-400 hover:text-rose-500 transition"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Linear progress bar */}
                <div className="w-full h-2 bg-slate-100 dark:bg-emerald-900/40 rounded-full overflow-hidden">
                  <div
                    style={{ width: `${pct}%` }}
                    className={`h-full transition-all duration-200 rounded-full ${
                      isDone ? 'bg-emerald-600 dark:bg-amber-400' : 'bg-emerald-500'
                    }`}
                  />
                </div>

                {/* Quick Count Increment Buttons */}
                <div className="flex items-center gap-1.5 pt-1">
                  <button
                    onClick={() => handleIncrement(item.id, 1, item.targetCount)}
                    className="flex-1 py-1.5 rounded-lg bg-emerald-800 hover:bg-emerald-700 text-white font-mono font-bold text-xs shadow-sm transition active:scale-95"
                  >
                    +1
                  </button>

                  {item.targetCount >= 10 && (
                    <button
                      onClick={() => handleIncrement(item.id, 10, item.targetCount)}
                      className="flex-1 py-1.5 rounded-lg bg-emerald-900/80 hover:bg-emerald-800 text-emerald-100 font-mono font-bold text-xs transition active:scale-95"
                    >
                      +10
                    </button>
                  )}

                  {item.targetCount >= 33 && (
                    <button
                      onClick={() => handleIncrement(item.id, 33, item.targetCount)}
                      className="flex-1 py-1.5 rounded-lg bg-emerald-900/80 hover:bg-emerald-800 text-emerald-100 font-mono font-bold text-xs transition active:scale-95"
                    >
                      +33
                    </button>
                  )}

                  {item.targetCount >= 100 && (
                    <button
                      onClick={() => handleIncrement(item.id, 100, item.targetCount)}
                      className="flex-1 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-600 text-emerald-950 font-mono font-bold text-xs transition active:scale-95"
                    >
                      +100
                    </button>
                  )}

                  {/* Shortcut to Devotional / Reader if applicable */}
                  <button
                    onClick={() => setActivePage('devotional')}
                    title="Open Devotional Text in Library"
                    className="p-1.5 rounded-lg bg-slate-100 dark:bg-emerald-900/50 hover:bg-slate-200 dark:hover:bg-emerald-800 text-slate-600 dark:text-slate-300 transition"
                  >
                    <BookOpen className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add Custom Aurad Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-emerald-950 border border-slate-200 dark:border-emerald-800 rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4 animate-in fade-in">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-emerald-900">
              <h3 className="font-bold text-lg text-slate-900 dark:text-white font-serif">
                Add Custom Wird or Litany
              </h3>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddCustomAurad} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">
                  Litany Title (English / Standard) *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Daily Surah Yasin"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-emerald-800 bg-slate-50 dark:bg-emerald-900/40 text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">
                  Arabic Name (Optional)
                </label>
                <input
                  type="text"
                  dir="rtl"
                  placeholder="e.g. سورة يس الشريفة"
                  value={newArabicTitle}
                  onChange={(e) => setNewArabicTitle(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-emerald-800 bg-slate-50 dark:bg-emerald-900/40 text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-emerald-500 font-arabic text-sm"
                />
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">
                  Malayalam Transliteration (Optional)
                </label>
                <input
                  type="text"
                  placeholder="e.g. സൂറത്തു യാസീൻ"
                  value={newMalayalamTitle}
                  onChange={(e) => setNewMalayalamTitle(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-emerald-800 bg-slate-50 dark:bg-emerald-900/40 text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">
                    Category
                  </label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value as any)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-emerald-800 bg-slate-50 dark:bg-emerald-900/40 text-slate-900 dark:text-white focus:outline-none"
                  >
                    <option value="wird">Wird / Hizb</option>
                    <option value="ratheeb">Ratheeb</option>
                    <option value="salawat">Salawat</option>
                    <option value="istighfar">Istighfar</option>
                    <option value="tahlil">Tahlil</option>
                    <option value="quran">Quranic</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">
                    Recommended Timing
                  </label>
                  <select
                    value={newRecommendedTime}
                    onChange={(e) => setNewRecommendedTime(e.target.value as any)}
                    className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-emerald-800 bg-slate-50 dark:bg-emerald-900/40 text-slate-900 dark:text-white focus:outline-none"
                  >
                    <option value="Morning">Morning</option>
                    <option value="Evening">Evening</option>
                    <option value="After Salah">After Salah</option>
                    <option value="Night">Night</option>
                    <option value="Anytime">Anytime</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">
                  Target Goal Count
                </label>
                <input
                  type="number"
                  min="1"
                  value={newTargetCount}
                  onChange={(e) => setNewTargetCount(parseInt(e.target.value) || 1)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-emerald-800 bg-slate-50 dark:bg-emerald-900/40 text-slate-900 dark:text-white focus:outline-none font-mono"
                />
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">
                  Virtue / Note (Optional)
                </label>
                <textarea
                  rows={2}
                  placeholder="Spiritual intention or benefit..."
                  value={newVirtue}
                  onChange={(e) => setNewVirtue(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-emerald-800 bg-slate-50 dark:bg-emerald-900/40 text-slate-900 dark:text-white focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-emerald-900"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-semibold shadow-sm"
                >
                  Add to Tracker
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
