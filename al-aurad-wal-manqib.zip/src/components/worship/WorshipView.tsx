import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { ManagedFileItem, ManagedCategory } from '../../types/storage';
import { DevotionalItem, Article } from '../../types';
import { DailyDhikrTracker } from './DailyDhikrTracker';
import {
  Compass,
  Clock,
  RotateCcw,
  Sparkles,
  Calendar as CalendarIcon,
  Sun,
  Moon,
  CheckCircle,
  CheckSquare,
  MapPin,
  Volume2,
  BookOpen,
} from 'lucide-react';

export const WorshipView: React.FC = () => {
  const {
    prayerTimesData,
    nextPrayer,
    selectedCity,
    setSelectedCity,
    tasbihCount,
    tasbihTarget,
    tasbihDhikr,
    tasbihTotal,
    incrementTasbih,
    resetTasbih,
    setTasbihTarget,
    setTasbihDhikr,
    showToast,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'prayer' | 'dhikr_tracker' | 'qibla' | 'tasbih' | 'ramadan' | 'calendar'>('prayer');

  // Qibla direction state
  const [qiblaDegrees, setQiblaDegrees] = useState<number>(115); // example for Mecca bearing

  // Ramadan fasting checklist
  const [fastingDays, setFastingDays] = useState<Record<number, boolean>>({
    1: true, 2: true, 3: true, 4: true, 5: true, 6: true, 7: true,
  });

  const prayers = [
    { name: 'Fajr', time: prayerTimesData.times.Fajr, arabic: 'الفجر', desc: 'Dawn prayer before sunrise' },
    { name: 'Sunrise', time: prayerTimesData.times.Sunrise, arabic: 'الشروق', desc: 'Solar sunrise time' },
    { name: 'Dhuhr', time: prayerTimesData.times.Dhuhr, arabic: 'الظهر', desc: 'Midday solar prayer' },
    { name: 'Asr', time: prayerTimesData.times.Asr, arabic: 'العصر', desc: 'Late afternoon prayer' },
    { name: 'Maghrib', time: prayerTimesData.times.Maghrib, arabic: 'المغرب', desc: 'Sunset prayer & Iftar' },
    { name: 'Isha', time: prayerTimesData.times.Isha, arabic: 'العشاء', desc: 'Night prayer' },
  ];

  const tasbihPresets = [
    { label: 'سُبْحَانَ اللَّهِ (Subhanallah)', meaning: 'Glory be to Allah', target: 33 },
    { label: 'الْحَمْدُ لِلَّهِ (Alhamdulillah)', meaning: 'All praise is for Allah', target: 33 },
    { label: 'اللَّهُ أَكْبَرُ (Allahu Akbar)', meaning: 'Allah is the Greatest', target: 34 },
    { label: 'أَسْتَغْفِرُ اللَّهَ (Astaghfirullah)', meaning: 'I seek forgiveness from Allah', target: 100 },
    { label: 'لا إِلَهَ إِلا اللَّهُ (La ilaha illallah)', meaning: 'None has the right to be worshipped but Allah', target: 100 },
    { label: 'اللَّهُمَّ صَلِّ عَلَى مُحَمَّدٍ (Salawat)', meaning: 'Blessings upon the Prophet ﷺ', target: 100 },
  ];

  const islamicEvents = [
    { name: '1 Muharram', event: 'Islamic Hijri New Year' },
    { name: '10 Muharram', event: 'Day of Ashura (Martyrdom of Imam Husayn & Deliverance of Musa AS)' },
    { name: '12 Rabi al-Awwal', event: 'Mawlid an-Nabi (Birth of the Beloved Prophet ﷺ)' },
    { name: '27 Rajab', event: 'Al-Isra wal-Mi’raj (The Night Journey and Ascension)' },
    { name: '15 Sha’ban', event: 'Laylat al-Bara’ah (Night of Deliverance)' },
    { name: '1 Ramadan', event: 'First Day of Holy Month of Ramadan Fasting' },
    { name: '27 Ramadan', event: 'Laylat al-Qadr (The Night of Divine Decree)' },
    { name: '1 Shawwal', event: 'Eid al-Fitr (Celebration of Breaking the Fast)' },
    { name: '9 Dhul-Hijjah', event: 'Day of Arafah (Hajj Pilgrimage Culmination)' },
    { name: '10 Dhul-Hijjah', event: 'Eid al-Adha (Feast of the Sacrifice)' },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-emerald-900 to-teal-950 text-white rounded-2xl p-6 sm:p-8 border border-emerald-800 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-1.5 text-amber-400 text-xs font-bold font-cinzel uppercase">
            <Compass className="w-4 h-4" />
            <span>Worship Companion</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-serif font-bold text-white">
            Prayer Times, Qibla & Devotional Hub
          </h1>
          <p className="text-xs sm:text-sm text-emerald-200/90 font-light">
            Stay punctual with prayer times, navigate directly towards the Holy Kaaba, count your Dhikr, and observe Ramadan.
          </p>
        </div>

        {/* City Selector Pill */}
        <div className="flex items-center gap-2 bg-emerald-950/80 px-3 py-2 rounded-xl border border-emerald-700 text-xs">
          <MapPin className="w-4 h-4 text-amber-400 shrink-0" />
          <div>
            <span className="block text-[10px] text-emerald-300 uppercase font-semibold">Selected Location</span>
            <select
              value={selectedCity}
              onChange={(e) => setSelectedCity(e.target.value)}
              className="bg-transparent text-white font-bold focus:outline-none cursor-pointer"
            >
              <option value="Mecca" className="bg-emerald-900 text-white">Mecca (Makkah al-Mukarramah)</option>
              <option value="Medina" className="bg-emerald-900 text-white">Medina (Al-Madinah)</option>
              <option value="Kozhikode" className="bg-emerald-900 text-white">Kozhikode (Kerala, India)</option>
              <option value="Dubai" className="bg-emerald-900 text-white">Dubai (UAE)</option>
              <option value="Cairo" className="bg-emerald-900 text-white">Cairo (Egypt)</option>
              <option value="Istanbul" className="bg-emerald-900 text-white">Istanbul (Turkey)</option>
              <option value="London" className="bg-emerald-900 text-white">London (UK)</option>
              <option value="New York" className="bg-emerald-900 text-white">New York (USA)</option>
              <option value="Kuala Lumpur" className="bg-emerald-900 text-white">Kuala Lumpur (Malaysia)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Worship Sub-Tabs Bar */}
      <div className="flex items-center gap-2 border-b border-slate-200 dark:border-emerald-800/60 pb-2 overflow-x-auto text-xs">
        {[
          { id: 'prayer', label: 'Prayer Times', icon: Clock },
          { id: 'dhikr_tracker', label: 'Daily Dhikr & Aurad Tracker', icon: CheckSquare },
          { id: 'tasbih', label: 'Digital Tasbih', icon: Sparkles },
          { id: 'qibla', label: 'Qiblah Compass', icon: Compass },
          { id: 'ramadan', label: 'Ramadan Hub', icon: Moon },
          { id: 'calendar', label: 'Islamic Calendar', icon: CalendarIcon },
        ].map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-semibold whitespace-nowrap transition ${
                activeTab === tab.id
                  ? 'bg-emerald-800 text-white shadow-sm'
                  : 'bg-white dark:bg-emerald-950 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-emerald-800 hover:bg-slate-50'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab: Daily Dhikr Tracker */}
      {activeTab === 'dhikr_tracker' && (
        <DailyDhikrTracker />
      )}

      {/* Tab 1: Prayer Times */}
      {activeTab === 'prayer' && (
        <div className="space-y-6 animate-in fade-in">
          {/* Next Prayer Highlight */}
          <div className="bg-gradient-to-r from-emerald-800 to-emerald-950 text-white p-6 sm:p-8 rounded-2xl shadow-xl flex flex-col sm:flex-row items-center justify-between gap-6">
            <div>
              <span className="text-xs uppercase font-bold tracking-wider text-emerald-300 font-cinzel">
                Current Time Target
              </span>
              <h2 className="text-3xl sm:text-4xl font-serif font-bold text-amber-300 mt-1">
                {nextPrayer.name}
              </h2>
              <p className="text-sm text-emerald-100 mt-1">
                Adhan approaching in {nextPrayer.remainingText} · Location: {selectedCity}, {prayerTimesData.country}
              </p>
            </div>
            <div className="text-center sm:text-right bg-emerald-900/60 px-6 py-4 rounded-xl border border-emerald-700">
              <span className="font-mono text-3xl sm:text-4xl font-bold tracking-wider text-white">
                {nextPrayer.time}
              </span>
              <span className="block text-xs text-emerald-300 mt-1">Astronomical Standard Time</span>
            </div>
          </div>

          {/* Today's Prayers Detailed Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {prayers.map((p) => {
              const isNext = p.name === nextPrayer.name;
              return (
                <div
                  key={p.name}
                  className={`p-5 rounded-2xl border transition ${
                    isNext
                      ? 'bg-emerald-50 dark:bg-emerald-900/50 border-emerald-500 shadow-md ring-1 ring-emerald-500/50'
                      : 'bg-white dark:bg-emerald-950/40 border-slate-200/80 dark:border-emerald-800/40 shadow-sm'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-xs font-bold text-slate-400 dark:text-emerald-400 font-mono">
                        #{p.name}
                      </span>
                      <h3 className={`text-lg font-bold ${isNext ? 'text-emerald-900 dark:text-amber-300' : 'text-slate-900 dark:text-white'}`}>
                        {p.name}
                      </h3>
                      <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{p.desc}</p>
                    </div>
                    <div className="text-right">
                      <span className="font-arabic text-xl font-bold text-emerald-800 dark:text-amber-400 block">
                        {p.arabic}
                      </span>
                      <span className="font-mono text-base font-bold text-slate-800 dark:text-slate-100 mt-1 block">
                        {p.time}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="p-4 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/40 text-xs text-amber-900 dark:text-amber-200 flex items-center justify-between">
            <span>Calculation Method: Muslim World League (MWL) · Shafi'i / Standard Juristic Time</span>
            <span className="font-semibold">{prayerTimesData.hijriDateStr}</span>
          </div>
        </div>
      )}

      {/* Tab 2: Qiblah Compass */}
      {activeTab === 'qibla' && (
        <div className="bg-white dark:bg-emerald-950/40 rounded-2xl p-6 sm:p-10 border border-slate-200 dark:border-emerald-800/40 shadow-xl max-w-2xl mx-auto text-center space-y-6 animate-in fade-in">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400 font-cinzel">
              Kaaba Direction Finder
            </span>
            <h2 className="text-2xl font-bold font-serif text-slate-900 dark:text-white mt-1">
              Qiblah Compass · اتجاه القبلة
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 max-w-md mx-auto mt-1">
              Aligned towards the Holy Kaaba (21.4225° N, 39.8262° E) from {selectedCity}.
            </p>
          </div>

          {/* Compass Dial Stage */}
          <div className="relative w-64 h-64 mx-auto my-6 flex items-center justify-center">
            {/* Outer Ring */}
            <div className="w-full h-full rounded-full border-4 border-slate-200 dark:border-emerald-800 bg-emerald-50/40 dark:bg-emerald-900/20 flex items-center justify-center relative shadow-inner">
              {/* Compass Cardinal markers */}
              <span className="absolute top-2 font-bold font-mono text-xs text-rose-500">N (0°)</span>
              <span className="absolute right-3 font-bold font-mono text-xs text-slate-400">E (90°)</span>
              <span className="absolute bottom-2 font-bold font-mono text-xs text-slate-400">S (180°)</span>
              <span className="absolute left-3 font-bold font-mono text-xs text-slate-400">W (270°)</span>

              {/* Kaaba indicator needle */}
              <div
                style={{ transform: `rotate(${qiblaDegrees}deg)` }}
                className="w-1 h-36 bg-gradient-to-t from-transparent via-amber-500 to-amber-600 absolute origin-center transition-transform duration-700 rounded flex flex-col justify-start items-center"
              >
                {/* Kaaba Symbol on Tip */}
                <div className="-mt-4 w-7 h-7 rounded bg-slate-950 border-2 border-amber-400 text-amber-300 flex items-center justify-center text-[10px] font-bold shadow-lg">
                  🕋
                </div>
              </div>

              {/* Center Hub */}
              <div className="w-6 h-6 rounded-full bg-emerald-900 border-2 border-amber-400 text-white z-10 flex items-center justify-center">
                <span className="w-2 h-2 rounded-full bg-amber-400"></span>
              </div>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 dark:bg-emerald-900/30 border border-slate-200 dark:border-emerald-800 flex items-center justify-around text-xs">
            <div>
              <span className="text-slate-400 block">Calculated Bearing</span>
              <span className="font-mono font-bold text-lg text-emerald-800 dark:text-amber-400">
                {qiblaDegrees}° E of N
              </span>
            </div>
            <div>
              <span className="text-slate-400 block">Distance to Mecca</span>
              <span className="font-mono font-bold text-lg text-slate-800 dark:text-slate-200">
                4,120 km
              </span>
            </div>
          </div>

          <p className="text-[11px] text-slate-400 dark:text-emerald-400/80 italic">
            Tip: Hold your device flat away from magnetic metallic objects for maximum directional precision.
          </p>
        </div>
      )}

      {/* Tab 3: Digital Tasbih */}
      {activeTab === 'tasbih' && (
        <div className="bg-white dark:bg-emerald-950/40 rounded-2xl p-6 sm:p-10 border border-slate-200 dark:border-emerald-800/40 shadow-xl max-w-2xl mx-auto text-center space-y-6 animate-in fade-in">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400 font-cinzel">
              Electronic Dhikr Counter
            </span>
            <h2 className="text-2xl font-bold font-serif text-slate-900 dark:text-white mt-1">
              Digital Tasbih Counter · المسبحة الرقمية
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Count your daily Adhkar with tactile responsiveness and custom goals.
            </p>
          </div>

          {/* Active Dhikr Preset Selection */}
          <div className="text-center space-y-2">
            <span className="text-xs text-slate-400 uppercase tracking-wider font-semibold">Active Dhikr Formula</span>
            <div className="p-3 bg-emerald-50 dark:bg-emerald-900/40 rounded-xl border border-emerald-200 dark:border-emerald-800">
              <h3 className="text-lg font-bold text-emerald-950 dark:text-amber-300 font-arabic">
                {tasbihDhikr}
              </h3>
            </div>
          </div>

          {/* Large Circular Counter Button */}
          <div className="my-6">
            <button
              onClick={incrementTasbih}
              className="w-48 h-48 sm:w-56 sm:h-56 mx-auto rounded-full bg-gradient-to-br from-emerald-700 via-emerald-800 to-emerald-950 hover:from-emerald-600 hover:to-emerald-900 text-white shadow-2xl border-4 border-amber-400 flex flex-col items-center justify-center active:scale-95 transition duration-150 group cursor-pointer"
            >
              <span className="font-mono text-5xl sm:text-6xl font-extrabold text-amber-300 tracking-tight group-hover:scale-105 transition">
                {tasbihCount}
              </span>
              <span className="text-xs text-emerald-200 mt-2 tracking-wider font-semibold">
                Target: {tasbihTarget}
              </span>
              <span className="text-[10px] text-amber-400/80 mt-1 uppercase font-bold">Tap to Count</span>
            </button>
          </div>

          {/* Progress bar towards target */}
          <div className="space-y-1 max-w-xs mx-auto">
            <div className="flex justify-between text-xs text-slate-500 dark:text-slate-400 font-mono">
              <span>Goal: {tasbihTarget}</span>
              <span>{Math.min(100, Math.round((tasbihCount / tasbihTarget) * 100))}%</span>
            </div>
            <div className="w-full h-2 bg-slate-100 dark:bg-emerald-900 rounded-full overflow-hidden">
              <div
                style={{ width: `${Math.min(100, (tasbihCount / tasbihTarget) * 100)}%` }}
                className="h-full bg-amber-400 transition-all duration-200 rounded-full"
              ></div>
            </div>
          </div>

          {/* Quick presets buttons */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs pt-4 border-t border-slate-100 dark:border-emerald-900/50">
            {tasbihPresets.map((p) => (
              <button
                key={p.label}
                onClick={() => {
                  setTasbihDhikr(p.label);
                  setTasbihTarget(p.target);
                  resetTasbih();
                }}
                className={`p-2 rounded-xl text-left border transition ${
                  tasbihDhikr === p.label
                    ? 'bg-emerald-800 text-white font-bold'
                    : 'bg-slate-50 dark:bg-emerald-950 text-slate-700 dark:text-slate-200 hover:bg-slate-100'
                }`}
              >
                <span className="block truncate font-arabic">{p.label}</span>
                <span className="text-[10px] opacity-70 block">{p.target} counts</span>
              </button>
            ))}
          </div>

          {/* Controls: Reset & Total */}
          <div className="flex items-center justify-between pt-4 border-t border-slate-100 dark:border-emerald-900/50 text-xs">
            <button
              onClick={resetTasbih}
              className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 font-semibold hover:bg-rose-100"
            >
              <RotateCcw className="w-3.5 h-3.5" /> Reset Count
            </button>

            <span className="text-slate-500 dark:text-slate-400 font-mono">
              Total Recorded Dhikr: <strong className="text-emerald-700 dark:text-amber-300">{tasbihTotal}</strong>
            </span>
          </div>
        </div>
      )}

      {/* Tab 4: Ramadan Hub */}
      {activeTab === 'ramadan' && (
        <div className="space-y-6 animate-in fade-in">
          <div className="bg-gradient-to-r from-amber-900 via-amber-950 to-emerald-950 text-white p-6 sm:p-8 rounded-2xl shadow-xl flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
              <span className="text-xs uppercase font-bold tracking-wider text-amber-300 font-cinzel">
                Holy Month Sanctuary
              </span>
              <h2 className="text-3xl font-serif font-bold mt-1 text-white">Ramadan Mubarak · رمضان مبارك</h2>
              <p className="text-xs sm:text-sm text-amber-200/90 mt-1 max-w-xl">
                Track your daily fasting, observe Suhoor and Iftar countdowns, recite the blessed supplications, and multiply your good deeds.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3 text-center">
              <div className="bg-white/10 backdrop-blur-sm p-3 rounded-xl border border-white/20">
                <span className="text-[10px] uppercase text-amber-300 font-semibold block">Suhoor Ends</span>
                <span className="text-xl font-bold font-mono">{prayerTimesData.times.Fajr}</span>
              </div>
              <div className="bg-white/10 backdrop-blur-sm p-3 rounded-xl border border-white/20">
                <span className="text-[10px] uppercase text-amber-300 font-semibold block">Iftar Time</span>
                <span className="text-xl font-bold font-mono">{prayerTimesData.times.Maghrib}</span>
              </div>
            </div>
          </div>

          {/* Ramadan Daily Duas */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-white dark:bg-emerald-950/40 p-6 rounded-2xl border border-slate-200 dark:border-emerald-800 space-y-3">
              <span className="text-xs font-bold uppercase text-amber-600 dark:text-amber-400 font-cinzel">
                Supplication at Iftar (Breaking Fast)
              </span>
              <p className="font-arabic text-xl leading-relaxed text-right text-emerald-950 dark:text-emerald-100" dir="rtl">
                ذَهَبَ الظَّمَأُ وَابْتَلَّتِ الْعُرُوقُ، وَثَبَتَ الأَجْرُ إِنْ شَاءَ اللَّهُ
              </p>
              <p className="text-xs text-slate-600 dark:text-slate-300 italic">
                "Dhahabadh-dhama’u wabtallatil-‘urooq, wa thabatal-ajru in sha’Allah."
              </p>
              <p className="text-xs text-slate-700 dark:text-slate-200">
                Translation: "The thirst has gone, the veins are moistened, and the reward is confirmed, if Allah wills." (Abu Dawud 2357)
              </p>
            </div>

            <div className="bg-white dark:bg-emerald-950/40 p-6 rounded-2xl border border-slate-200 dark:border-emerald-800 space-y-3">
              <span className="text-xs font-bold uppercase text-amber-600 dark:text-amber-400 font-cinzel">
                Dua for Laylat al-Qadr (The Night of Decree)
              </span>
              <p className="font-arabic text-xl leading-relaxed text-right text-emerald-950 dark:text-emerald-100" dir="rtl">
                اللَّهُمَّ إِنَّكَ عَفُوٌّ تُحِبُّ الْعَفْوَ فَاعْفُ عَنِّي
              </p>
              <p className="text-xs text-slate-600 dark:text-slate-300 italic">
                "Allahumma innaka ‘Afuwwun tuhibbul-‘afwa fa’fu ‘annee."
              </p>
              <p className="text-xs text-slate-700 dark:text-slate-200">
                Translation: "O Allah, You are Most Forgiving and You love to forgive, so forgive me." (At-Tirmidhi 3513)
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Tab 5: Islamic Calendar */}
      {activeTab === 'calendar' && (
        <div className="bg-white dark:bg-emerald-950/40 rounded-2xl p-6 sm:p-8 border border-slate-200 dark:border-emerald-800/40 shadow-xl space-y-6 animate-in fade-in">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400 font-cinzel">
              Hijri & Gregorian Calendar
            </span>
            <h2 className="text-2xl font-bold font-serif text-slate-900 dark:text-white mt-1">
              Sacred Islamic Dates & Historical Events
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Significant anniversaries, fasting days (Ayyam al-Beed), and holy nights across the lunar year 1447–1448 AH.
            </p>
          </div>

          <div className="divide-y divide-slate-100 dark:divide-emerald-900/50">
            {islamicEvents.map((evt) => (
              <div key={evt.name} className="py-3 flex items-center justify-between text-xs sm:text-sm">
                <span className="font-bold text-emerald-900 dark:text-amber-300 font-serif w-36">
                  {evt.name}
                </span>
                <span className="text-slate-700 dark:text-slate-200 flex-1 pl-4">
                  {evt.event}
                </span>
                <span className="text-[11px] px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-900 text-emerald-800 dark:text-emerald-300">
                  Annual Milestone
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
