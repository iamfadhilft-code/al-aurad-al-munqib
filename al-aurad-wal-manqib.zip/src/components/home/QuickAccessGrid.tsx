import React from 'react';
import { useApp } from '../../context/AppContext';
import { NavPage } from '../../types';
import {
  BookOpen,
  BookMarked,
  Heart,
  Compass,
  GraduationCap,
  Baby,
  Scroll,
  Sparkles,
  ArrowUpRight,
} from 'lucide-react';

export const QuickAccessGrid: React.FC = () => {
  const { setActivePage } = useApp();

  const cards = [
    {
      page: 'quran' as NavPage,
      title: "Holy Qur'an",
      arabicTitle: 'القرآن الكريم',
      desc: '114 Surahs, recitation audio, word-by-word Tafsir and Hifz mode',
      icon: BookOpen,
      badge: 'Scripture',
      accentColor: 'from-emerald-800 to-emerald-950',
    },
    {
      page: 'hadith' as NavPage,
      title: 'Authentic Hadith',
      arabicTitle: 'الحديث الشريف',
      desc: 'Sahih Bukhari, Muslim, Riyad as-Salihin & 40 Hadith Nawawi with grades',
      icon: BookMarked,
      badge: 'Sunnah',
      accentColor: 'from-teal-800 to-slate-900',
    },
    {
      page: 'devotional' as NavPage,
      title: 'Maulid & Devotion',
      arabicTitle: 'الموالد والصلوات',
      desc: 'Manqoos, Subhana, Burda, Ratheeb Haddad with text, PDF and audio',
      icon: Heart,
      badge: 'Heritage',
      accentColor: 'from-amber-800 to-emerald-950',
    },
    {
      page: 'worship' as NavPage,
      title: 'Worship Hub & Qiblah',
      arabicTitle: 'أوقات الصلاة والقبلة',
      desc: 'Live prayer times, Qibla compass, Digital Tasbih counter, Ramadan hub',
      icon: Compass,
      badge: 'Worship',
      accentColor: 'from-emerald-900 to-slate-950',
    },
    {
      page: 'learning' as NavPage,
      title: 'Noor Academy',
      arabicTitle: 'الأكاديمية الإسلامية',
      desc: 'Foundations of Tajweed, Seerah, Islamic Fiqh with verified certificates',
      icon: GraduationCap,
      badge: 'Courses',
      accentColor: 'from-indigo-900 to-slate-950',
    },
    {
      page: 'kids' as NavPage,
      title: 'Kids Sanctuary',
      arabicTitle: 'عالم الأطفال',
      desc: 'Stories of the Prophets, good manners, interactive quizzes and Arabic alphabet',
      icon: Baby,
      badge: 'Young Believers',
      accentColor: 'from-amber-700 to-teal-950',
    },
  ];

  return (
    <div className="py-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold font-serif text-slate-900 dark:text-white">
            Core Modules & Sanctuaries
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
            Immerse yourself into classical disciplines, worship tools, and devotional treasures.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
        {cards.map((card) => {
          const Icon = card.icon;
          return (
            <div
              key={card.title}
              onClick={() => {
                setActivePage(card.page);
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="group relative bg-white dark:bg-emerald-950/40 rounded-2xl p-6 border border-slate-200/80 dark:border-emerald-800/40 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300 cursor-pointer overflow-hidden flex flex-col justify-between"
            >
              {/* Subtle gradient corner accent */}
              <div
                className={`absolute top-0 right-0 w-24 h-24 bg-gradient-to-br ${card.accentColor} opacity-5 group-hover:opacity-15 rounded-bl-full transition`}
              ></div>

              <div>
                <div className="flex items-center justify-between mb-4">
                  <div className="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-emerald-900/60 text-emerald-800 dark:text-amber-300 flex items-center justify-center group-hover:scale-110 transition shadow-sm">
                    <Icon className="w-5 h-5" />
                  </div>
                  <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-slate-100 dark:bg-emerald-900/50 text-slate-600 dark:text-emerald-300">
                    {card.badge}
                  </span>
                </div>

                <div className="flex items-baseline justify-between gap-2">
                  <h3 className="text-base font-bold text-slate-900 dark:text-slate-100 group-hover:text-emerald-800 dark:group-hover:text-amber-300 transition">
                    {card.title}
                  </h3>
                  <span className="font-arabic text-sm text-emerald-700/80 dark:text-amber-400/80">
                    {card.arabicTitle}
                  </span>
                </div>

                <p className="text-xs text-slate-500 dark:text-slate-300 mt-2 leading-relaxed">
                  {card.desc}
                </p>
              </div>

              <div className="pt-4 mt-4 border-t border-slate-100 dark:border-emerald-900/40 flex items-center justify-between text-xs text-emerald-700 dark:text-emerald-300 font-semibold">
                <span>Enter sanctuary</span>
                <ArrowUpRight className="w-4 h-4 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition" />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
