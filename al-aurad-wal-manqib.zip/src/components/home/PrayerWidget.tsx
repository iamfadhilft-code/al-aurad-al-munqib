import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { MapPin, Clock, ChevronRight, Compass } from 'lucide-react';

export const PrayerWidget: React.FC = () => {
  const { prayerTimesData, nextPrayer, selectedCity, setSelectedCity, setActivePage } = useApp();
  const [citySelectorOpen, setCitySelectorOpen] = useState(false);

  const cities = ['Mecca', 'Medina', 'Kozhikode', 'Dubai', 'Cairo', 'Istanbul', 'London', 'New York', 'Kuala Lumpur'];

  const prayers = [
    { name: 'Fajr', time: prayerTimesData.times.Fajr, arabic: 'الفجر' },
    { name: 'Sunrise', time: prayerTimesData.times.Sunrise, arabic: 'الشروق' },
    { name: 'Dhuhr', time: prayerTimesData.times.Dhuhr, arabic: 'الظهر' },
    { name: 'Asr', time: prayerTimesData.times.Asr, arabic: 'العصر' },
    { name: 'Maghrib', time: prayerTimesData.times.Maghrib, arabic: 'المغرب' },
    { name: 'Isha', time: prayerTimesData.times.Isha, arabic: 'العشاء' },
  ];

  return (
    <div className="bg-white dark:bg-emerald-950/70 rounded-2xl p-6 border border-slate-200 dark:border-emerald-800/40 shadow-xl flex flex-col justify-between">
      {/* Header: Location and Hijri Date */}
      <div>
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-emerald-900/60">
          <div className="relative">
            <button
              onClick={() => setCitySelectorOpen(!citySelectorOpen)}
              className="flex items-center gap-1.5 text-xs font-bold text-emerald-900 dark:text-emerald-200 hover:text-amber-500 transition"
            >
              <MapPin className="w-3.5 h-3.5 text-emerald-600 dark:text-amber-400" />
              <span>{selectedCity}</span>
              <span className="text-[10px] text-slate-400 font-normal">({prayerTimesData.country}) ▾</span>
            </button>

            {citySelectorOpen && (
              <div className="absolute left-0 mt-2 w-44 bg-white dark:bg-emerald-900 border border-slate-200 dark:border-emerald-700 rounded-xl shadow-xl py-1 z-50">
                {cities.map((c) => (
                  <button
                    key={c}
                    onClick={() => {
                      setSelectedCity(c);
                      setCitySelectorOpen(false);
                    }}
                    className={`w-full text-left px-3 py-1.5 text-xs ${
                      selectedCity === c
                        ? 'bg-emerald-50 dark:bg-emerald-800 text-emerald-900 dark:text-amber-300 font-bold'
                        : 'text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-emerald-800/50'
                    }`}
                  >
                    {c}
                  </button>
                ))}
              </div>
            )}
          </div>

          <span className="text-[11px] font-semibold text-amber-700 dark:text-amber-300 px-2 py-0.5 rounded bg-amber-50 dark:bg-amber-950/50 border border-amber-200/50 dark:border-amber-800/40">
            {prayerTimesData.hijriDateStr}
          </span>
        </div>

        {/* Current / Next Prayer Highlight Card */}
        <div className="my-5 p-4 rounded-xl bg-gradient-to-r from-emerald-800 to-emerald-950 text-white shadow-md relative overflow-hidden">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-[10px] uppercase tracking-wider text-emerald-300 font-bold flex items-center gap-1">
                <Clock className="w-3 h-3" /> Next Prayer
              </span>
              <h3 className="text-2xl font-bold font-serif text-amber-300 mt-0.5">{nextPrayer.name}</h3>
              <p className="text-xs text-emerald-200 mt-0.5">Adhan in {nextPrayer.remainingText}</p>
            </div>
            <div className="text-right">
              <span className="text-2xl sm:text-3xl font-bold font-mono tracking-tight text-white">
                {nextPrayer.time}
              </span>
              <span className="block text-[11px] text-emerald-300/80">Standard Adhan</span>
            </div>
          </div>
        </div>

        {/* Timeline of Prayers */}
        <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
          {prayers.map((p) => {
            const isNext = p.name === nextPrayer.name;
            return (
              <div
                key={p.name}
                className={`p-2.5 rounded-xl text-center border transition ${
                  isNext
                    ? 'bg-emerald-50 dark:bg-emerald-900/60 border-emerald-500 shadow-sm'
                    : 'bg-slate-50 dark:bg-emerald-950/40 border-slate-100 dark:border-emerald-900/30'
                }`}
              >
                <span className="block text-[10px] text-slate-400 dark:text-emerald-400/80 font-arabic">
                  {p.arabic}
                </span>
                <span className={`block text-xs font-bold ${isNext ? 'text-emerald-800 dark:text-amber-300' : 'text-slate-800 dark:text-slate-200'}`}>
                  {p.name}
                </span>
                <span className="block text-xs font-mono text-slate-600 dark:text-slate-300 mt-0.5">
                  {p.time}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Bottom CTA to Qibla & Schedule */}
      <div className="pt-4 mt-4 border-t border-slate-100 dark:border-emerald-900/50 flex items-center justify-between text-xs">
        <button
          onClick={() => setActivePage('worship')}
          className="text-emerald-700 dark:text-emerald-300 font-semibold hover:underline flex items-center gap-1"
        >
          <Compass className="w-3.5 h-3.5 text-emerald-600 dark:text-amber-400" />
          <span>Open Qiblah & Full Timetable</span>
        </button>
        <ChevronRight className="w-4 h-4 text-slate-400" />
      </div>
    </div>
  );
};
