import React from 'react';
import { HeroSection } from './HeroSection';
import { DailyAyahCard } from './DailyAyahCard';
import { PrayerWidget } from './PrayerWidget';
import { QuickAccessGrid } from './QuickAccessGrid';
import { FrequentlyRecitedSection } from './FrequentlyRecitedSection';
import { DevotionalHighlights } from './DevotionalHighlights';
import { ArticlesHighlights } from './ArticlesHighlights';
import { useApp } from '../../context/AppContext';
import { GraduationCap, Baby, Award, ArrowRight } from 'lucide-react';

export const HomeView: React.FC = () => {
  const { setActivePage } = useApp();

  return (
    <div className="space-y-4">
      {/* 1. Hero Banner */}
      <HeroSection />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12 py-8">
        {/* 2. Today's Spiritual Focus: Daily Ayah + Prayer Times Widget */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
          <div className="lg:col-span-7">
            <DailyAyahCard />
          </div>
          <div className="lg:col-span-5">
            <PrayerWidget />
          </div>
        </div>

        {/* 3. Quick Access Grid of Modules */}
        <QuickAccessGrid />

        {/* 4. Frequently Recited Surahs */}
        <FrequentlyRecitedSection />

        {/* 5. Devotional Highlights (Maulids, Swalath, Burda, Ratheeb) */}
        <DevotionalHighlights />

        {/* 6. Academy & Kids Learning Banner */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Academy Card */}
          <div
            onClick={() => {
              setActivePage('learning');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="p-8 rounded-2xl bg-gradient-to-br from-emerald-900 to-teal-950 text-white shadow-xl border border-emerald-700/60 cursor-pointer group flex flex-col justify-between"
          >
            <div>
              <div className="w-12 h-12 rounded-xl bg-white/10 backdrop-blur-md flex items-center justify-center text-amber-300 mb-4 group-hover:scale-110 transition">
                <GraduationCap className="w-6 h-6" />
              </div>
              <span className="text-xs uppercase font-bold tracking-wider text-amber-300 font-cinzel">
                Structured Learning
              </span>
              <h3 className="text-xl font-bold font-serif mt-1 text-white">
                Noor Islamic Academy & Certifications
              </h3>
              <p className="text-xs text-emerald-200/80 mt-2 leading-relaxed">
                Take self-paced courses in Tajweed recitation, 40 Hadith of Imam Nawawi, and Islamic jurisprudence. Complete quizzes and generate verified certificates.
              </p>
            </div>
            <div className="pt-6 mt-6 border-t border-emerald-800 flex items-center justify-between text-xs text-amber-300 font-semibold">
              <span>Explore Academy Courses</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition" />
            </div>
          </div>

          {/* Kids Sanctuary Card */}
          <div
            onClick={() => {
              setActivePage('kids');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="p-8 rounded-2xl bg-gradient-to-br from-amber-800/90 to-amber-950 text-white shadow-xl border border-amber-600/50 cursor-pointer group flex flex-col justify-between"
          >
            <div>
              <div className="w-12 h-12 rounded-xl bg-white/10 backdrop-blur-md flex items-center justify-center text-amber-300 mb-4 group-hover:scale-110 transition">
                <Baby className="w-6 h-6" />
              </div>
              <span className="text-xs uppercase font-bold tracking-wider text-amber-300 font-cinzel">
                Young Believers
              </span>
              <h3 className="text-xl font-bold font-serif mt-1 text-white">
                Kids Islamic Stories & Interactive Fun
              </h3>
              <p className="text-xs text-amber-100/80 mt-2 leading-relaxed">
                Tastefully designed prophet stories (Noah's Ark, Abraham, King Solomon's ant), gentle morals on animal kindness, interactive quizzes, and Arabic alphabet.
              </p>
            </div>
            <div className="pt-6 mt-6 border-t border-amber-800 flex items-center justify-between text-xs text-amber-300 font-semibold">
              <span>Open Kids Sanctuary</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition" />
            </div>
          </div>
        </div>

        {/* 7. Articles & Insights */}
        <ArticlesHighlights />
      </div>
    </div>
  );
};
