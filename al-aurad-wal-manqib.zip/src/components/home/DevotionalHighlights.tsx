import React from 'react';
import { useApp } from '../../context/AppContext';
import { Heart, FileText, Music, ArrowRight, Sparkles, Bookmark } from 'lucide-react';
import { DevotionalItem } from '../../types';

export const DevotionalHighlights: React.FC = () => {
  const { devotionals, setActivePage, openPdf, playAudioTrack, toggleBookmark, isBookmarked } = useApp();

  const featured = devotionals.filter((d) => d.status === 'published' && d.featured).slice(0, 4);

  const handleOpenItem = (item: DevotionalItem) => {
    setActivePage('devotional');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="py-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-800 dark:text-emerald-400 uppercase font-cinzel">
            <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500/20" />
            <span>Devotional Archive</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold font-serif text-slate-900 dark:text-white mt-1">
            Maulid, Swalath & Ratheeb Library
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
            Timeless poetic odes, litanies of blessing, and daily spiritual fortresses preserved with classical accuracy.
          </p>
        </div>

        <button
          onClick={() => {
            setActivePage('devotional');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className="flex items-center gap-1 text-xs font-semibold text-emerald-800 dark:text-amber-300 hover:underline"
        >
          <span>Explore All ({devotionals.length})</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
        {featured.map((item) => {
          const bookmarked = isBookmarked(item.id);
          return (
            <div
              key={item.id}
              className="bg-white dark:bg-emerald-950/40 rounded-2xl p-6 border border-slate-200/80 dark:border-emerald-800/40 shadow-sm hover:shadow-lg transition-all duration-300 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950/70 text-amber-900 dark:text-amber-300 border border-amber-200/60 dark:border-amber-700/40">
                    {item.category}
                  </span>

                  <button
                    onClick={() =>
                      toggleBookmark({
                        id: item.id,
                        type: 'devotional',
                        title: item.title,
                        subtitle: item.author || item.category,
                        pathOrRef: 'Devotional Archive',
                      })
                    }
                    className="text-slate-400 hover:text-amber-500 transition"
                  >
                    <Bookmark className={`w-4 h-4 ${bookmarked ? 'fill-amber-400 text-amber-400' : ''}`} />
                  </button>
                </div>

                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
                      {item.title}
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                      {item.author || 'Traditional Islamic Diwan'}
                    </p>
                  </div>
                  <span className="font-arabic text-lg font-bold text-emerald-800 dark:text-amber-400 text-right shrink-0">
                    {item.arabicTitle}
                  </span>
                </div>

                <p className="text-xs text-slate-600 dark:text-slate-300 mt-3 line-clamp-2 leading-relaxed">
                  {item.description}
                </p>

                {/* Excerpt of Arabic text */}
                <div className="mt-3 p-2.5 rounded-lg bg-emerald-50/70 dark:bg-emerald-900/30 border border-emerald-100 dark:border-emerald-800/40 text-right">
                  <p className="font-arabic text-sm text-emerald-950 dark:text-emerald-200 line-clamp-1" dir="rtl">
                    {item.arabicText.split('\n')[0]}
                  </p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-between pt-4 mt-4 border-t border-slate-100 dark:border-emerald-900/40 text-xs">
                <div className="flex items-center gap-2">
                  {item.pdfUrl && (
                    <button
                      onClick={() => openPdf(item.title, item.pdfUrl!, item.author)}
                      className="flex items-center gap-1 text-slate-600 dark:text-emerald-300 hover:text-emerald-800 font-medium"
                    >
                      <FileText className="w-3.5 h-3.5 text-amber-500" />
                      <span>PDF Diwan</span>
                    </button>
                  )}

                  {item.audioUrl && (
                    <button
                      onClick={() =>
                        playAudioTrack({
                          id: item.id,
                          title: item.title,
                          subtitle: item.author || item.category,
                          arabicTitle: item.arabicTitle,
                          audioUrl: item.audioUrl!,
                          category: item.category,
                        })
                      }
                      className="flex items-center gap-1 text-slate-600 dark:text-emerald-300 hover:text-emerald-800 font-medium ml-2"
                    >
                      <Music className="w-3.5 h-3.5 text-emerald-500" />
                      <span>Recitation</span>
                    </button>
                  )}
                </div>

                <button
                  onClick={() => handleOpenItem(item)}
                  className="font-semibold text-emerald-800 dark:text-amber-300 hover:underline flex items-center gap-1"
                >
                  <span>Open Text</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
