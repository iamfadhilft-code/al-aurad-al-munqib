import React from 'react';
import { useApp } from '../../context/AppContext';
import { Play, BookOpen, Sparkles } from 'lucide-react';

export const FrequentlyRecitedSection: React.FC = () => {
  const { setSelectedSurahNumber, setActivePage, playAudioTrack } = useApp();

  const surahsList = [
    { number: 18, arabic: 'الكهف', english: 'Al-Kahf', meaning: 'The Cave', ayahs: 110, audioUrl: 'https://everyayah.com/data/Alafasy_128kbps/018001.mp3' },
    { number: 36, arabic: 'يس', english: 'Yaseen', meaning: 'The Heart of the Quran', ayahs: 83, audioUrl: 'https://everyayah.com/data/Alafasy_128kbps/036001.mp3' },
    { number: 55, arabic: 'الرحمن', english: 'Ar-Rahman', meaning: 'The Most Merciful', ayahs: 78, audioUrl: 'https://everyayah.com/data/Alafasy_128kbps/055001.mp3' },
    { number: 56, arabic: 'الواقعة', english: 'Al-Waqi’ah', meaning: 'The Inevitable Event', ayahs: 96, audioUrl: 'https://everyayah.com/data/Alafasy_128kbps/056001.mp3' },
    { number: 67, arabic: 'الملك', english: 'Al-Mulk', meaning: 'The Dominion', ayahs: 30, audioUrl: 'https://everyayah.com/data/Alafasy_128kbps/067001.mp3' },
    { number: 32, arabic: 'السجدة', english: 'As-Sajdah', meaning: 'The Prostration', ayahs: 30, audioUrl: 'https://everyayah.com/data/Alafasy_128kbps/032001.mp3' },
    { number: 44, arabic: 'الدخان', english: 'Ad-Dukhan', meaning: 'The Smoke', ayahs: 59, audioUrl: 'https://everyayah.com/data/Alafasy_128kbps/044001.mp3' },
    { number: 59, arabic: 'الحشر', english: 'Al-Hashr', meaning: 'The Gathering', ayahs: 24, audioUrl: 'https://everyayah.com/data/Alafasy_128kbps/059001.mp3' },
  ];

  const handleRead = (num: number) => {
    setSelectedSurahNumber(num === 36 || num === 67 ? num : 1);
    setActivePage('quran');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handlePlay = (s: typeof surahsList[0]) => {
    playAudioTrack({
      id: `surah-${s.number}`,
      title: `Surah ${s.english} (${s.arabic})`,
      subtitle: `${s.meaning} · Recitation`,
      audioUrl: s.audioUrl,
      category: "Qur'an",
    });
  };

  return (
    <div className="py-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <div className="flex items-center gap-1.5 text-xs font-bold text-amber-600 dark:text-amber-400 uppercase font-cinzel">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Spiritual Habits</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold font-serif text-slate-900 dark:text-white mt-1">
            Frequently Recited Surahs
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
            Surahs blessed with special virtues for Friday, evenings, protection, and peaceful sleep.
          </p>
        </div>

        <button
          onClick={() => {
            setActivePage('quran');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className="hidden sm:flex items-center gap-1 text-xs font-semibold text-emerald-800 dark:text-emerald-300 hover:underline"
        >
          <span>View All 114 Surahs</span>
        </button>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
        {surahsList.map((s) => (
          <div
            key={s.number}
            className="bg-white dark:bg-emerald-950/40 rounded-xl p-4 border border-slate-200/80 dark:border-emerald-800/40 shadow-sm hover:shadow-md transition flex flex-col justify-between group"
          >
            <div>
              <div className="flex items-center justify-between text-xs text-slate-400 dark:text-emerald-400/70 mb-2">
                <span className="font-mono">#{s.number}</span>
                <span>{s.ayahs} Ayahs</span>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-bold text-slate-900 dark:text-white group-hover:text-emerald-800 dark:group-hover:text-amber-300 transition">
                    {s.english}
                  </h4>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate max-w-[120px]">
                    {s.meaning}
                  </p>
                </div>
                <span className="font-arabic text-xl font-bold text-emerald-800 dark:text-amber-400">
                  {s.arabic}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2 pt-3 mt-3 border-t border-slate-100 dark:border-emerald-900/40">
              <button
                onClick={() => handlePlay(s)}
                className="flex-1 flex items-center justify-center gap-1 py-1.5 rounded-lg bg-emerald-50 dark:bg-emerald-900/60 hover:bg-emerald-100 text-emerald-900 dark:text-amber-300 text-[11px] font-semibold transition"
                title="Play recitation"
              >
                <Play className="w-3 h-3 fill-current" />
                <span>Play</span>
              </button>

              <button
                onClick={() => handleRead(s.number)}
                className="flex-1 flex items-center justify-center gap-1 py-1.5 rounded-lg bg-slate-100 dark:bg-emerald-950 hover:bg-slate-200 text-slate-700 dark:text-slate-200 text-[11px] font-semibold transition"
                title="Open and read Surah"
              >
                <BookOpen className="w-3 h-3" />
                <span>Read</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
