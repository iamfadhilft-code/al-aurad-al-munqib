import React from 'react';
import { useApp } from '../../context/AppContext';
import { Search, BookOpen, Heart, Compass, Sparkles, ArrowRight } from 'lucide-react';

export const HeroSection: React.FC = () => {
  const { setActivePage, openSearch } = useApp();

  return (
    <div className="relative overflow-hidden bg-gradient-to-b from-emerald-900 via-emerald-950 to-slate-900 text-white pt-12 pb-20 px-4 sm:px-6 lg:px-8 border-b border-emerald-800/50">
      {/* Decorative Islamic Geometric subtle background grid & radial glow */}
      <div className="absolute inset-0 opacity-10 pointer-events-none bg-[radial-gradient(#fbbf24_1px,transparent_1px)] [background-size:20px_20px]"></div>
      <div className="absolute -top-24 left-1/2 -translate-x-1/2 w-96 h-96 bg-emerald-600/20 rounded-full blur-3xl pointer-events-none"></div>

      <div className="max-w-5xl mx-auto text-center relative z-10 space-y-6">
        {/* Subtle Pill Tag */}
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-800/80 border border-amber-400/30 text-amber-300 text-xs font-semibold tracking-wide shadow-sm">
          <Sparkles className="w-3.5 h-3.5 text-amber-300" />
          <span>Premium Islamic Digital Sanctuary & Knowledge Platform</span>
        </div>

        {/* Heading */}
        <h1 className="text-3xl sm:text-5xl lg:text-6xl font-serif font-bold tracking-tight text-white leading-tight">
          Your Digital Companion for <br className="hidden sm:inline" />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-amber-400 to-amber-200">
            Qur’an, Hadith & Devotional Heritage
          </span>
        </h1>

        {/* Subtitle */}
        <p className="max-w-2xl mx-auto text-sm sm:text-base text-emerald-100/80 leading-relaxed font-light">
          An all-in-one verified sanctuary combining immersive Qur'anic reading and memorization, authentic Hadith collections, traditional Maulid, Swalath, Baith & Ratheeb libraries, precise prayer tools, structured courses, and children's education.
        </p>

        {/* Quick Search Bar trigger */}
        <div className="max-w-xl mx-auto pt-2">
          <div
            onClick={openSearch}
            className="flex items-center justify-between px-4 py-3 rounded-2xl bg-white/10 hover:bg-white/15 backdrop-blur-md border border-white/20 shadow-xl cursor-pointer group transition text-left"
          >
            <div className="flex items-center gap-3">
              <Search className="w-5 h-5 text-amber-300 group-hover:scale-110 transition" />
              <span className="text-xs sm:text-sm text-emerald-200/90">
                Search Surahs, Hadith, Manqoos Maulid, Burda, Ratheeb, Courses...
              </span>
            </div>
            <kbd className="hidden sm:inline-block px-2 py-0.5 text-[11px] font-mono bg-emerald-900/60 rounded border border-emerald-700 text-amber-300">
              ⌘K
            </kbd>
          </div>
        </div>

        {/* Primary CTA Buttons */}
        <div className="flex flex-wrap items-center justify-center gap-3 pt-3">
          <button
            onClick={() => setActivePage('quran')}
            className="flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 text-sm font-bold shadow-lg shadow-amber-400/20 transition group"
          >
            <BookOpen className="w-4 h-4 text-slate-950" />
            <span>Read Holy Qur'an</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition" />
          </button>

          <button
            onClick={() => setActivePage('devotional')}
            className="flex items-center gap-2 px-6 py-3 rounded-xl bg-emerald-800/80 hover:bg-emerald-700/80 text-white text-sm font-semibold border border-emerald-600/40 shadow-md backdrop-blur-sm transition"
          >
            <Heart className="w-4 h-4 text-amber-300" />
            <span>Explore Devotional Library</span>
          </button>

          <button
            onClick={() => setActivePage('worship')}
            className="flex items-center gap-2 px-5 py-3 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 text-emerald-200 text-sm font-semibold border border-slate-700 transition"
          >
            <Compass className="w-4 h-4 text-emerald-400" />
            <span>Prayer & Qiblah</span>
          </button>
        </div>

        {/* Highlights Bar */}
        <div className="pt-8 grid grid-cols-2 sm:grid-cols-4 gap-4 max-w-3xl mx-auto border-t border-emerald-800/50 text-center">
          <div>
            <div className="text-xl sm:text-2xl font-bold font-serif text-amber-300">114</div>
            <div className="text-[11px] text-emerald-300/80 font-medium">Holy Surahs & Audio</div>
          </div>
          <div>
            <div className="text-xl sm:text-2xl font-bold font-serif text-amber-300">100%</div>
            <div className="text-[11px] text-emerald-300/80 font-medium">Verified Hadith Sources</div>
          </div>
          <div>
            <div className="text-xl sm:text-2xl font-bold font-serif text-amber-300">Maulid & Ratheeb</div>
            <div className="text-[11px] text-emerald-300/80 font-medium">Authentic Devotional Diwan</div>
          </div>
          <div>
            <div className="text-xl sm:text-2xl font-bold font-serif text-amber-300">Live CMS</div>
            <div className="text-[11px] text-emerald-300/80 font-medium">Instant Admin Publishing</div>
          </div>
        </div>
      </div>
    </div>
  );
};
