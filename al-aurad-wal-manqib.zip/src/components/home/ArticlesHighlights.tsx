import React from 'react';
import { useApp } from '../../context/AppContext';
import { BookOpen, Clock, ArrowRight } from 'lucide-react';

export const ArticlesHighlights: React.FC = () => {
  const { articles, setActivePage } = useApp();

  return (
    <div className="py-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <div className="flex items-center gap-1.5 text-xs font-bold text-amber-600 dark:text-amber-400 uppercase font-cinzel">
            <BookOpen className="w-3.5 h-3.5" />
            <span>Islamic Knowledge & Reflections</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold font-serif text-slate-900 dark:text-white mt-1">
            Scholarly Essays & Spiritual Insights
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
            Carefully curated explorations of theology, inner states, prophetic character, and history.
          </p>
        </div>

        <button
          onClick={() => {
            setActivePage('knowledge');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className="flex items-center gap-1 text-xs font-semibold text-emerald-800 dark:text-amber-300 hover:underline"
        >
          <span>All Articles</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {articles.slice(0, 3).map((art) => (
          <div
            key={art.id}
            onClick={() => {
              setActivePage('knowledge');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="group bg-white dark:bg-emerald-950/40 rounded-2xl border border-slate-200/80 dark:border-emerald-800/40 shadow-sm hover:shadow-lg transition cursor-pointer overflow-hidden flex flex-col justify-between"
          >
            {art.coverImage && (
              <div className="h-44 w-full overflow-hidden relative">
                <img
                  src={art.coverImage}
                  alt={art.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                />
                <span className="absolute top-3 left-3 text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-slate-950/80 text-amber-300 backdrop-blur-sm">
                  {art.category}
                </span>
              </div>
            )}

            <div className="p-5 flex-1 flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-2 text-[11px] text-slate-400 dark:text-emerald-400/70 mb-2">
                  <span>{art.author}</span>
                  <span>·</span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3" /> {art.readingTimeMinutes} min read
                  </span>
                </div>

                <h3 className="text-base font-bold text-slate-900 dark:text-white group-hover:text-emerald-800 dark:group-hover:text-amber-300 transition line-clamp-2">
                  {art.title}
                </h3>

                <p className="text-xs text-slate-500 dark:text-slate-300 mt-2 line-clamp-3 leading-relaxed">
                  {art.summary}
                </p>
              </div>

              <div className="pt-4 mt-4 border-t border-slate-100 dark:border-emerald-900/40 flex items-center justify-between text-xs text-emerald-800 dark:text-amber-300 font-semibold">
                <span>Read Full Essay</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition" />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
