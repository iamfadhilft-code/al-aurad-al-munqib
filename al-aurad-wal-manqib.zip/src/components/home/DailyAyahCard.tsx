import React from 'react';
import { useApp } from '../../context/AppContext';
import { Play, Pause, Bookmark, Share2, Copy, BookOpen } from 'lucide-react';

export const DailyAyahCard: React.FC = () => {
  const {
    surahs,
    setActivePage,
    setSelectedSurahNumber,
    playAudioTrack,
    isPlaying,
    activeAudioTrack,
    toggleBookmark,
    isBookmarked,
    showToast,
  } = useApp();

  // Daily Ayah: Ayatul Kursi (Surah 2 Ayah 255) or Surah Al-Fatihah
  const ayahData = {
    surahName: 'Al-Baqarah',
    surahNumber: 2,
    ayahNumber: 255,
    arabic: 'اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ ۚ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ ۚ لَّهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ ۗ مَن ذَا الَّذِي يَشْفَعُ عِندَهُ إِلَّا بِإِذْنِهِ ۚ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ ۖ وَلَا يُحِيطُونَ بِشَيْءٍ مِّنْ عِلْمِهِ إِلَّا بِمَا شَاءَ ۚ وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالْأَرْضَ ۖ وَلَا يَئُودُهُ حِفْظُهُمَا ۚ وَهُوَ الْعَلِيُّ الْعَظِيمُ',
    transliteration: 'Allāhu lā ilāha illā huwal-ḥayyul-qayyūm, lā ta’khudhuhū sinatuw-wa lā nawm, lahū mā fis-samāwāti wa mā fīl-arḍ...',
    translation: 'Allah - there is no deity except Him, the Ever-Living, the Sustainer of [all] existence. Neither drowsiness overtakes Him nor sleep. To Him belongs whatever is in the heavens and whatever is on the earth. Who is it that can intercede with Him except by His permission? He knows what is [presently] before them and what will be after them, and they encompass not a thing of His knowledge except for what He wills. His Kursi extends over the heavens and the earth, and their preservation tires Him not. And He is the Most High, the Most Great.',
    audioUrl: 'https://everyayah.com/data/Alafasy_128kbps/002255.mp3',
  };

  const isCurrentAudio = activeAudioTrack?.id === 'daily-ayah-255' && isPlaying;
  const bookmarked = isBookmarked('daily-ayah-255');

  const handlePlay = () => {
    playAudioTrack({
      id: 'daily-ayah-255',
      title: 'Ayat al-Kursi (The Throne Verse)',
      subtitle: 'Surah Al-Baqarah: 255 · Mishary Alafasy',
      arabicTitle: 'آية الكرسي',
      audioUrl: ayahData.audioUrl,
      category: "Qur'an",
    });
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(`${ayahData.arabic}\n\n${ayahData.translation}\n(Surah Al-Baqarah 2:255)`);
    showToast('Ayah copied to clipboard', 'success');
  };

  return (
    <div className="bg-gradient-to-br from-emerald-900/10 via-emerald-800/5 to-amber-900/10 dark:from-emerald-950/60 dark:to-slate-900/80 rounded-2xl p-6 sm:p-8 border border-emerald-900/15 dark:border-emerald-800/40 shadow-xl relative overflow-hidden">
      {/* Decorative top accent */}
      <div className="flex items-center justify-between pb-4 border-b border-emerald-900/10 dark:border-emerald-800/40 mb-6">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping"></span>
          <span className="text-xs uppercase font-bold tracking-wider text-emerald-800 dark:text-amber-400 font-cinzel">
            Daily Ayah of the Day · آية اليوم
          </span>
        </div>
        <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-emerald-100 dark:bg-emerald-900/60 text-emerald-900 dark:text-emerald-200">
          Surah {ayahData.surahName} · Verse {ayahData.ayahNumber}
        </span>
      </div>

      {/* Arabic Verse Display */}
      <div className="text-right my-6">
        <p className="font-arabic text-2xl sm:text-3xl leading-[2.2] sm:leading-[2.3] text-emerald-950 dark:text-emerald-100 font-normal select-text" dir="rtl">
          {ayahData.arabic}
        </p>
      </div>

      {/* English Translation */}
      <div className="space-y-2 mt-4 pt-4 border-t border-emerald-900/10 dark:border-emerald-800/30">
        <p className="text-xs text-emerald-700 dark:text-amber-300 font-mono tracking-wide">
          {ayahData.transliteration}
        </p>
        <p className="text-sm sm:text-base text-slate-700 dark:text-slate-300 leading-relaxed font-light">
          "{ayahData.translation}"
        </p>
      </div>

      {/* Action Buttons */}
      <div className="flex flex-wrap items-center justify-between gap-3 pt-6 mt-4 border-t border-emerald-900/10 dark:border-emerald-800/30">
        <div className="flex items-center gap-2">
          <button
            onClick={handlePlay}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-800 hover:bg-emerald-700 text-white text-xs font-semibold shadow-md transition"
          >
            {isCurrentAudio ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 fill-current" />}
            <span>{isCurrentAudio ? 'Pause Recitation' : 'Listen to Verse'}</span>
          </button>

          <button
            onClick={() => {
              setSelectedSurahNumber(1);
              setActivePage('quran');
            }}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-100 dark:bg-emerald-900/40 hover:bg-slate-200 text-slate-700 dark:text-slate-200 text-xs font-medium transition"
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>Open in Qur'an</span>
          </button>
        </div>

        <div className="flex items-center gap-1">
          <button
            onClick={() =>
              toggleBookmark({
                id: 'daily-ayah-255',
                type: 'quran',
                title: 'Ayat al-Kursi (Surah 2:255)',
                subtitle: 'The Throne Verse',
                pathOrRef: 'Al-Baqarah 255',
              })
            }
            className={`p-2 rounded-lg border transition ${
              bookmarked
                ? 'bg-amber-400 text-slate-950 border-amber-300'
                : 'bg-white dark:bg-emerald-950 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-emerald-800 hover:bg-slate-50'
            }`}
            title="Save to Bookmarks"
          >
            <Bookmark className={`w-4 h-4 ${bookmarked ? 'fill-current' : ''}`} />
          </button>

          <button
            onClick={handleCopy}
            className="p-2 rounded-lg bg-white dark:bg-emerald-950 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-emerald-800 hover:bg-slate-50 transition"
            title="Copy Ayah text"
          >
            <Copy className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
