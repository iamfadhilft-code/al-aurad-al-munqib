import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { Search, X, BookOpen, Heart, BookMarked, FileText, GraduationCap, ArrowRight } from 'lucide-react';
import { NavPage } from '../../types';

export const GlobalSearchModal: React.FC = () => {
  const {
    isSearchOpen,
    closeSearch,
    surahs,
    setSelectedSurahNumber,
    setActivePage,
    devotionals,
    articles,
    courses,
    mediaDocs,
  } = useApp();

  const [query, setQuery] = useState('');
  const [filterType, setFilterType] = useState<string>('all');

  const results = useMemo(() => {
    if (!query.trim()) return [];
    const q = query.toLowerCase();

    const items: Array<{
      id: string;
      title: string;
      subtitle: string;
      arabicSnippet?: string;
      category: string;
      icon: React.ComponentType<{ className?: string }>;
      action: () => void;
    }> = [];

    // Search Quran
    if (filterType === 'all' || filterType === 'quran') {
      surahs.forEach((s) => {
        if (
          s.nameEnglish.toLowerCase().includes(q) ||
          s.nameTranslation.toLowerCase().includes(q) ||
          s.nameArabic.includes(query)
        ) {
          items.push({
            id: `quran-surah-${s.number}`,
            title: `Surah ${s.nameEnglish} (${s.nameArabic})`,
            subtitle: `${s.nameTranslation} · ${s.ayahCount} Ayahs · ${s.revelationType}`,
            category: "Qur'an",
            icon: BookOpen,
            action: () => {
              setSelectedSurahNumber(s.number);
              setActivePage('quran');
              closeSearch();
            },
          });
        }
        s.ayahs.forEach((a) => {
          if (
            a.translation.toLowerCase().includes(q) ||
            a.transliteration.toLowerCase().includes(q) ||
            a.arabic.includes(query)
          ) {
            items.push({
              id: `quran-ayah-${s.number}-${a.number}`,
              title: `Surah ${s.nameEnglish} · Ayah ${a.number}`,
              subtitle: a.translation,
              arabicSnippet: a.arabic,
              category: "Qur'an Ayah",
              icon: BookOpen,
              action: () => {
                setSelectedSurahNumber(s.number);
                setActivePage('quran');
                closeSearch();
              },
            });
          }
        });
      });
    }

    // Search Devotionals
    if (filterType === 'all' || filterType === 'devotional') {
      devotionals.forEach((d) => {
        if (
          d.title.toLowerCase().includes(q) ||
          d.description.toLowerCase().includes(q) ||
          d.arabicTitle.includes(query) ||
          d.category.toLowerCase().includes(q)
        ) {
          items.push({
            id: d.id,
            title: d.title,
            subtitle: `${d.author || d.category} · ${d.language}`,
            arabicSnippet: d.arabicTitle,
            category: d.category,
            icon: Heart,
            action: () => {
              setActivePage('devotional');
              closeSearch();
            },
          });
        }
      });
    }

    // Search Articles
    if (filterType === 'all' || filterType === 'articles') {
      articles.forEach((art) => {
        if (
          art.title.toLowerCase().includes(q) ||
          art.summary.toLowerCase().includes(q) ||
          art.author.toLowerCase().includes(q)
        ) {
          items.push({
            id: art.id,
            title: art.title,
            subtitle: `By ${art.author} · ${art.readingTimeMinutes} min read`,
            category: 'Article',
            icon: FileText,
            action: () => {
              setActivePage('knowledge');
              closeSearch();
            },
          });
        }
      });
    }

    // Search Courses
    if (filterType === 'all' || filterType === 'academy') {
      courses.forEach((c) => {
        if (
          c.title.toLowerCase().includes(q) ||
          c.description.toLowerCase().includes(q) ||
          c.instructor.toLowerCase().includes(q)
        ) {
          items.push({
            id: c.id,
            title: c.title,
            subtitle: `${c.level} · ${c.instructor}`,
            category: 'Course',
            icon: GraduationCap,
            action: () => {
              setActivePage('learning');
              closeSearch();
            },
          });
        }
      });
    }

    // Search Media
    if (filterType === 'all' || filterType === 'media') {
      mediaDocs.forEach((m) => {
        if (m.title.toLowerCase().includes(q) || (m.author && m.author.toLowerCase().includes(q))) {
          items.push({
            id: m.id,
            title: m.title,
            subtitle: `${m.type.toUpperCase()} · ${m.fileSize} · ${m.author || ''}`,
            category: 'PDF & Media',
            icon: FileText,
            action: () => {
              setActivePage('devotional');
              closeSearch();
            },
          });
        }
      });
    }

    return items.slice(0, 12);
  }, [query, filterType, surahs, devotionals, articles, courses, mediaDocs]);

  if (!isSearchOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-16 px-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in">
      <div
        className="w-full max-w-2xl bg-white dark:bg-emerald-950 rounded-2xl shadow-2xl border border-slate-200 dark:border-emerald-800 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Input Bar */}
        <div className="flex items-center px-4 py-3.5 border-b border-slate-100 dark:border-emerald-800/60 gap-3">
          <Search className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0" />
          <input
            type="text"
            placeholder="Search Qur'an, Hadith, Maulid, Swalath, Ratheeb, Courses..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            autoFocus
            className="w-full bg-transparent text-sm sm:text-base text-slate-800 dark:text-slate-100 placeholder-slate-400 dark:placeholder-emerald-400/60 focus:outline-none"
          />
          <button
            onClick={closeSearch}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-1.5 px-4 py-2 border-b border-slate-100 dark:border-emerald-900/50 overflow-x-auto text-xs">
          {[
            { id: 'all', label: 'All Resources' },
            { id: 'quran', label: "Qur'an" },
            { id: 'devotional', label: 'Devotional & Maulid' },
            { id: 'articles', label: 'Articles' },
            { id: 'academy', label: 'Academy' },
            { id: 'media', label: 'PDFs & Audio' },
          ].map((f) => (
            <button
              key={f.id}
              onClick={() => setFilterType(f.id)}
              className={`px-2.5 py-1 rounded-full whitespace-nowrap transition ${
                filterType === f.id
                  ? 'bg-emerald-800 text-white font-medium'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-emerald-900/50'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>

        {/* Results List */}
        <div className="max-h-[60vh] overflow-y-auto p-2">
          {query.trim() === '' ? (
            <div className="py-10 text-center text-slate-400 dark:text-emerald-400/60 text-xs">
              <p className="font-medium text-sm text-slate-500 dark:text-slate-300 mb-1">
                Explore the Complete Islamic Digital Library
              </p>
              <p>Type keywords such as "Fatihah", "Manqoos", "Tajweed", "Salah", "Burda", or Arabic text.</p>
            </div>
          ) : results.length === 0 ? (
            <div className="py-10 text-center text-slate-400 dark:text-emerald-400/60 text-xs">
              <p className="text-sm font-semibold text-slate-700 dark:text-slate-200 mb-1">No matching results found</p>
              <p>Try refining your query or search in a different category.</p>
            </div>
          ) : (
            <div className="space-y-1">
              {results.map((res) => {
                const Icon = res.icon;
                return (
                  <div
                    key={res.id}
                    onClick={res.action}
                    className="flex items-center justify-between p-3 rounded-xl hover:bg-emerald-50 dark:hover:bg-emerald-900/40 cursor-pointer group transition border border-transparent hover:border-emerald-200/50 dark:hover:border-emerald-800/60"
                  >
                    <div className="flex items-start gap-3 min-w-0">
                      <div className="w-8 h-8 rounded-lg bg-emerald-100 dark:bg-emerald-900/60 text-emerald-800 dark:text-emerald-300 flex items-center justify-center shrink-0 mt-0.5">
                        <Icon className="w-4 h-4" />
                      </div>
                      <div className="truncate">
                        <div className="flex items-center gap-2">
                          <h4 className="text-sm font-semibold text-slate-800 dark:text-slate-100 truncate group-hover:text-emerald-800 dark:group-hover:text-amber-300">
                            {res.title}
                          </h4>
                          <span className="text-[10px] uppercase font-bold px-1.5 py-0.5 rounded bg-slate-100 dark:bg-emerald-900 text-slate-600 dark:text-emerald-300">
                            {res.category}
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 dark:text-slate-300 truncate mt-0.5">{res.subtitle}</p>
                        {res.arabicSnippet && (
                          <p className="font-serif text-sm text-emerald-700 dark:text-amber-400 truncate mt-1">
                            {res.arabicSnippet}
                          </p>
                        )}
                      </div>
                    </div>
                    <ArrowRight className="w-4 h-4 text-slate-400 opacity-0 group-hover:opacity-100 group-hover:translate-x-1 transition shrink-0 ml-2" />
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer info */}
        <div className="px-4 py-2 bg-slate-50 dark:bg-emerald-900/20 border-t border-slate-100 dark:border-emerald-800/40 flex items-center justify-between text-[11px] text-slate-400 dark:text-emerald-400/70">
          <span>Press ESC to close</span>
          <span>{results.length} result(s)</span>
        </div>
      </div>
    </div>
  );
};
