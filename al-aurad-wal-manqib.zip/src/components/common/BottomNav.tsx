import React from 'react';
import { useApp } from '../../context/AppContext';
import { NavPage } from '../../types';
import { Home, BookOpen, Compass, Heart, Search, ShieldCheck } from 'lucide-react';

export const BottomNav: React.FC = () => {
  const { activePage, setActivePage, openSearch } = useApp();

  const handleNav = (page: NavPage) => {
    setActivePage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const navs = [
    { id: 'home' as NavPage, label: 'Home', icon: Home },
    { id: 'quran' as NavPage, label: "Qur'an", icon: BookOpen },
    { id: 'worship' as NavPage, label: 'Worship', icon: Compass },
    { id: 'devotional' as NavPage, label: 'Devotion', icon: Heart },
    { id: 'search' as const, label: 'Search', icon: Search, isAction: true },
    { id: 'admin' as NavPage, label: 'Admin', icon: ShieldCheck },
  ];

  return (
    <div className="xl:hidden fixed bottom-0 left-0 right-0 z-30 bg-white/95 dark:bg-emerald-950/95 backdrop-blur-md border-t border-slate-200 dark:border-emerald-800/40 shadow-lg px-2 py-1.5 safe-area-pb">
      <div className="flex items-center justify-around">
        {navs.map((item) => {
          const Icon = item.icon;
          const isActive = !item.isAction && activePage === item.id;
          return (
            <button
              key={item.label}
              onClick={() => {
                if (item.isAction) {
                  openSearch();
                } else {
                  handleNav(item.id as NavPage);
                }
              }}
              className={`flex flex-col items-center justify-center py-1 px-2 rounded-lg transition ${
                isActive
                  ? 'text-emerald-800 dark:text-amber-400 font-semibold scale-105'
                  : 'text-slate-500 dark:text-slate-400 hover:text-emerald-700 dark:hover:text-emerald-200'
              }`}
            >
              <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.5]' : 'stroke-2'}`} />
              <span className="text-[10px] tracking-tight mt-0.5">{item.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
