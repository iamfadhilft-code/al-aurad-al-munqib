import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { X, Download, Bookmark, ZoomIn, ZoomOut, ChevronLeft, ChevronRight, FileText, Check } from 'lucide-react';

export const PdfViewerModal: React.FC = () => {
  const { activePdfModal, closePdf, toggleBookmark, isBookmarked, showToast } = useApp();
  const [currentPage, setCurrentPage] = useState(1);
  const [zoomLevel, setZoomLevel] = useState(100);
  const [downloaded, setDownloaded] = useState(false);

  if (!activePdfModal) return null;

  const totalPages = 18;
  const bookmarked = isBookmarked(activePdfModal.title);

  const handleDownload = () => {
    setDownloaded(true);
    showToast(`Downloading "${activePdfModal.title}"...`, 'success');
    setTimeout(() => setDownloaded(false), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in">
      <div className="w-full max-w-4xl h-[90vh] bg-slate-900 text-white rounded-2xl shadow-2xl border border-emerald-800 flex flex-col overflow-hidden">
        {/* Top Control Bar */}
        <div className="flex items-center justify-between px-4 py-3 bg-emerald-950 border-b border-emerald-800/80">
          <div className="flex items-center gap-2.5 truncate">
            <div className="w-8 h-8 rounded-lg bg-emerald-800 flex items-center justify-center text-amber-300 shrink-0">
              <FileText className="w-4 h-4" />
            </div>
            <div className="truncate">
              <h3 className="text-sm font-semibold truncate text-white">{activePdfModal.title}</h3>
              <p className="text-[11px] text-emerald-300/80 truncate">{activePdfModal.author || 'Islamic Heritage Archive'}</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Zoom Controls */}
            <div className="hidden sm:flex items-center gap-1 bg-emerald-900/60 rounded-lg px-2 py-1 text-xs border border-emerald-800">
              <button
                onClick={() => setZoomLevel((z) => Math.max(75, z - 15))}
                className="p-1 hover:text-amber-300"
                title="Zoom Out"
              >
                <ZoomOut className="w-3.5 h-3.5" />
              </button>
              <span className="font-mono text-[11px] px-1">{zoomLevel}%</span>
              <button
                onClick={() => setZoomLevel((z) => Math.min(150, z + 15))}
                className="p-1 hover:text-amber-300"
                title="Zoom In"
              >
                <ZoomIn className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Bookmark button */}
            <button
              onClick={() =>
                toggleBookmark({
                  id: activePdfModal.title,
                  type: 'devotional',
                  title: activePdfModal.title,
                  subtitle: activePdfModal.author || 'PDF Document',
                  pathOrRef: 'PDF Reader',
                })
              }
              className={`p-2 rounded-lg border transition ${
                bookmarked
                  ? 'bg-amber-400 text-slate-950 border-amber-300 font-bold'
                  : 'bg-emerald-900/60 text-emerald-200 border-emerald-800 hover:bg-emerald-800'
              }`}
              title="Bookmark Document"
            >
              <Bookmark className={`w-4 h-4 ${bookmarked ? 'fill-current' : ''}`} />
            </button>

            {/* Download */}
            <button
              onClick={handleDownload}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-semibold transition"
            >
              {downloaded ? <Check className="w-3.5 h-3.5" /> : <Download className="w-3.5 h-3.5" />}
              <span className="hidden sm:inline">{downloaded ? 'Downloaded' : 'Download PDF'}</span>
            </button>

            {/* Close */}
            <button
              onClick={closePdf}
              className="p-1.5 rounded-lg text-emerald-400 hover:text-white hover:bg-emerald-900 transition ml-1"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Reader Stage */}
        <div className="flex-1 overflow-auto bg-slate-950 p-4 sm:p-8 flex items-center justify-center">
          <div
            style={{ transform: `scale(${zoomLevel / 100})`, transformOrigin: 'top center' }}
            className="w-full max-w-2xl bg-amber-50 text-slate-900 rounded-lg shadow-2xl p-8 sm:p-12 border border-amber-200/80 transition-all font-serif min-h-[550px] flex flex-col justify-between"
          >
            {/* Subtle Islamic Border Frame */}
            <div className="border border-emerald-800/40 p-6 rounded-md relative flex flex-col justify-between h-full min-h-[480px]">
              <div className="text-center space-y-3">
                <div className="text-emerald-900 text-2xl font-bold font-arabic tracking-wide">
                  بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ
                </div>
                <div className="w-24 h-0.5 bg-amber-500 mx-auto opacity-70"></div>
                <h2 className="text-xl font-bold text-emerald-950 font-serif tracking-tight">
                  {activePdfModal.title}
                </h2>
                <p className="text-xs text-emerald-800 font-sans tracking-wide uppercase">
                  {activePdfModal.author || 'Scholarly Archive Edition'}
                </p>
              </div>

              {/* Sample Rendered Arabic text & Commentary page */}
              <div className="my-6 space-y-4 text-center">
                <p className="text-lg leading-relaxed text-emerald-950 font-arabic px-4">
                  {currentPage === 1 && (
                    <>
                      يَا رَبَّنَا صَلِّ وَسَلِّمْ دَائِمًا * عَلَىٰ حَبِيبِكَ خَيْرِ الْخَلْقِ كُلِّهِمِ
                      <br />
                      هُوَ الْحَبِيبُ الَّذِي تُرْجَىٰ شَفَاعَتُهُ * لِكُلِّ هَوْلٍ مِنَ الأَهْوَالِ مُقْتَحَمِ
                      <br />
                      ثُمَّ الرِّضَا عَنْ أَبِي بَكْرٍ وَعَنْ عُمَرَ * وَعَنْ عَلِيٍّ وَعَنْ عُثْمَانَ ذِي الْكَرَمِ
                    </>
                  )}
                  {currentPage === 2 && (
                    <>
                      بَدَا الصَّبَاحُ مِن غُرَّتِهِ * وَاللَّيْلُ الدَّاجِي مِن وَفْرَتِهِ
                      <br />
                      فَاقَ الرُّسُلَ فَضْلًا وَعُلَا * أَهْدَى السُّبُلَ لِدَلَالَتِهِ
                      <br />
                      كَنْزُ الْكَرَمِ مَوْلَى النِّعَمِ * هَادِي الأُمَمِ لِشَرِيعَتِهِ
                    </>
                  )}
                  {currentPage > 2 && (
                    <>
                      أَزْكَى صَلاَةٍ مَعَ سَلاَمٍ سَرْمَدِي * عَلَى النَّبِيِّ الْمُصْطَفَى الْمُحَمَّدِي
                      <br />
                      وَآلِهِ وَصَحْبِهِ الأَطْهَارِ * مَا غَرَّدَتْ قُمْرِيَّةُ الأَسْحَارِ
                    </>
                  )}
                </p>

                <div className="text-xs text-slate-600 font-sans italic max-w-md mx-auto pt-4 border-t border-amber-200">
                  "Authentic verified manuscript preserving classical vocalization and devotional meter for collective and personal recitation."
                </div>
              </div>

              {/* Page Number footer */}
              <div className="flex items-center justify-between text-[11px] text-slate-500 font-sans border-t border-amber-200/60 pt-3">
                <span>Noor Digital Islamic Library</span>
                <span>Page {currentPage} of {totalPages}</span>
                <span>Al-Bayan Collection</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Pagination Bar */}
        <div className="flex items-center justify-between px-6 py-2.5 bg-emerald-950 border-t border-emerald-800 text-xs">
          <button
            onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
            disabled={currentPage === 1}
            className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-emerald-900 text-emerald-200 hover:bg-emerald-800 disabled:opacity-40 disabled:pointer-events-none transition"
          >
            <ChevronLeft className="w-4 h-4" /> Previous
          </button>

          <span className="font-mono text-emerald-300">
            Page {currentPage} / {totalPages}
          </span>

          <button
            onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
            disabled={currentPage === totalPages}
            className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-emerald-900 text-emerald-200 hover:bg-emerald-800 disabled:opacity-40 disabled:pointer-events-none transition"
          >
            Next <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
