import React, { useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { X, Award, Printer, CheckCircle, Sparkles } from 'lucide-react';

export const CertificateModal: React.FC = () => {
  const { certificateModal, closeCertificate, showToast } = useApp();
  const printRef = useRef<HTMLDivElement>(null);

  if (!certificateModal) return null;

  const handlePrint = () => {
    window.print();
    showToast('Certificate prepared for print/save as PDF', 'success');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in">
      <div className="w-full max-w-3xl bg-white dark:bg-emerald-950 rounded-2xl shadow-2xl border border-amber-300 dark:border-amber-500/40 overflow-hidden">
        {/* Modal Top Bar */}
        <div className="flex items-center justify-between px-6 py-3 bg-emerald-900 text-white">
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-amber-300" />
            <h3 className="text-sm font-bold tracking-wide">Certificate of Islamic Studies Completion</h3>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="flex items-center gap-1 px-3 py-1 text-xs font-semibold rounded bg-amber-400 hover:bg-amber-300 text-slate-950 transition"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / Download</span>
            </button>
            <button onClick={closeCertificate} className="p-1 hover:text-amber-300 transition">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Certificate Surface (Printable) */}
        <div ref={printRef} className="p-8 sm:p-12 bg-amber-50/50 text-slate-900 select-none">
          <div className="border-4 border-double border-amber-600/80 p-6 sm:p-10 rounded-xl relative bg-white shadow-inner">
            {/* Corner Decorative stars */}
            <div className="absolute top-2 left-2 text-amber-500 text-xl font-serif">✦</div>
            <div className="absolute top-2 right-2 text-amber-500 text-xl font-serif">✦</div>
            <div className="absolute bottom-2 left-2 text-amber-500 text-xl font-serif">✦</div>
            <div className="absolute bottom-2 right-2 text-amber-500 text-xl font-serif">✦</div>

            <div className="text-center space-y-4">
              <div className="text-emerald-900 text-xl sm:text-2xl font-bold font-arabic">
                بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ
              </div>

              <div className="flex items-center justify-center gap-2 text-amber-600 font-cinzel tracking-widest text-xs uppercase font-bold">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Noor Islamic Digital Academy</span>
                <Sparkles className="w-3.5 h-3.5" />
              </div>

              <h1 className="text-2xl sm:text-4xl font-serif font-bold text-emerald-950 tracking-tight">
                Certificate of Completion
              </h1>

              <p className="text-xs sm:text-sm text-slate-500 italic max-w-md mx-auto">
                "Whoever treads a path seeking knowledge, Allah will pave for him thereby a path to Paradise."
              </p>

              <div className="py-2">
                <p className="text-xs uppercase text-slate-400 tracking-wider">This is proudly awarded to</p>
                <div className="text-2xl sm:text-3xl font-serif font-bold text-emerald-900 border-b-2 border-amber-400 inline-block px-8 py-1 mt-1">
                  {certificateModal.studentName}
                </div>
              </div>

              <p className="text-sm text-slate-700 max-w-lg mx-auto leading-relaxed">
                For successfully demonstrating proficiency, completing curriculum modules, and passing comprehensive assessments for:
              </p>

              <div className="text-lg sm:text-xl font-bold text-emerald-950 font-serif bg-emerald-50/70 border border-emerald-200/80 py-2.5 px-4 rounded-lg inline-block">
                {certificateModal.courseTitle}
              </div>

              {/* Signatures & Seal */}
              <div className="pt-8 grid grid-cols-3 items-end text-center gap-4 text-xs text-slate-600">
                <div>
                  <div className="font-serif italic text-emerald-900 text-sm font-semibold">
                    Qari Shaykh Bilal
                  </div>
                  <div className="w-32 h-0.5 bg-slate-300 mx-auto my-1"></div>
                  <span className="text-[11px] text-slate-400">Head of Curriculum</span>
                </div>

                <div className="flex flex-col items-center">
                  <div className="w-16 h-16 rounded-full border-2 border-amber-500 flex items-center justify-center text-amber-600 bg-amber-50 shadow-md">
                    <Award className="w-8 h-8" />
                  </div>
                  <span className="text-[10px] text-amber-700 font-bold uppercase mt-1">Verified Authenticity</span>
                </div>

                <div>
                  <div className="font-mono text-slate-700 text-xs">{certificateModal.dateStr}</div>
                  <div className="w-32 h-0.5 bg-slate-300 mx-auto my-1"></div>
                  <span className="text-[11px] text-slate-400">Date of Award</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
