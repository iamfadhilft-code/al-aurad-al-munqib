import React from 'react';
import { useApp } from '../../context/AppContext';
import { NavPage } from '../../types';
import { Sparkles, ShieldCheck, Heart, Globe, BookOpen, Compass, GraduationCap, Baby } from 'lucide-react';

export const Footer: React.FC = () => {
  const { setActivePage, setLanguage, language, theme, setTheme } = useApp();

  const handleNav = (page: NavPage) => {
    setActivePage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="w-full bg-emerald-950 text-slate-300 border-t border-emerald-800/80 pt-16 pb-24 xl:pb-16 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 pb-12 border-b border-emerald-900">
          {/* Col 1: Brand & Spiritual mission */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-3 cursor-pointer" onClick={() => handleNav('home')}>
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-600 to-emerald-800 text-amber-300 flex items-center justify-center border border-amber-400/30">
                <span className="font-serif text-xl font-bold">ن</span>
              </div>
              <span className="font-cinzel text-xl font-bold tracking-wider text-white">NOOR</span>
            </div>

            <p className="text-xs text-emerald-200/80 leading-relaxed max-w-sm">
              An authentic, modern, and spiritually elevated digital sanctuary dedicated to the Holy Qur’an, prophetic Sunnah, classic devotional poetry (Maulid, Swalath, Baith, Ratheeb), and structured Islamic education.
            </p>

            <div className="flex items-center gap-3 pt-2 text-xs text-amber-400 font-serif">
              <span className="font-arabic text-lg">وَمَا تَوْفِيقِي إِلَّا بِاللَّهِ</span>
              <span className="text-[11px] text-emerald-400 font-sans italic">— "My success is only by Allah"</span>
            </div>
          </div>

          {/* Col 2: Core Scriptures & Worship */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400 mb-3 font-cinzel">
              Scripture & Worship
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => handleNav('quran')} className="hover:text-white transition">
                  Noble Qur'an Reader
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('quran')} className="hover:text-white transition">
                  Hifz Memorization Tool
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('hadith')} className="hover:text-white transition">
                  Authentic Hadith Collections
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('worship')} className="hover:text-white transition">
                  Accurate Prayer Times
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('worship')} className="hover:text-white transition">
                  Interactive Qibla Compass
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('worship')} className="hover:text-white transition">
                  Digital Tasbih Counter
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Devotional Heritage */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400 mb-3 font-cinzel">
              Devotional Heritage
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => handleNav('devotional')} className="hover:text-white transition">
                  Manqoos & Subhana Maulid
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('devotional')} className="hover:text-white transition">
                  Swalathul Fatih & Nariyath
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('devotional')} className="hover:text-white transition">
                  Qasida Burda & Muhyidheen Mala
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('devotional')} className="hover:text-white transition">
                  Ratheeb al-Haddad Diwan
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('devotional')} className="hover:text-white transition">
                  Morning & Evening Adhkar
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('devotional')} className="hover:text-white transition">
                  PDF & Audio Library
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Academy & Kids */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400 mb-3 font-cinzel">
              Academy & Kids
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => handleNav('learning')} className="hover:text-white transition">
                  Foundations of Tajweed
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('learning')} className="hover:text-white transition">
                  40 Hadith Studies
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('learning')} className="hover:text-white transition">
                  Certification Exams
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('kids')} className="hover:text-white transition">
                  Stories of the Prophets
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('kids')} className="hover:text-white transition">
                  Children’s Interactive Quiz
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('admin')} className="text-amber-300 font-semibold hover:text-white transition flex items-center gap-1 mt-3">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Admin CMS Control</span>
                </button>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom bar: Attributions & Copyright */}
        <div className="pt-8 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-emerald-400/70">
          <div>
            © {new Date().getFullYear()} Noor Digital Islamic Platform. Crafted with reverence, precision, and adherence to verified classical sources.
          </div>

          <div className="flex items-center gap-4 text-xs">
            <span className="text-emerald-300">Verified Manuscripts</span>
            <span>·</span>
            <span className="text-emerald-300">Open Digital Archive</span>
            <span>·</span>
            <button onClick={() => handleNav('dashboard')} className="hover:text-white underline">
              Personal Dashboard
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
