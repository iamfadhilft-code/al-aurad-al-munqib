import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { NavPage, Language } from '../../types';
import {
  BookOpen,
  Compass,
  Heart,
  Search,
  Moon,
  Sun,
  ShieldCheck,
  Menu,
  X,
  Sparkles,
  BookMarked,
  GraduationCap,
  Baby,
  LayoutDashboard,
  Globe,
  Clock,
  FolderOpen,
  User,
  LogIn,
  LogOut,
} from 'lucide-react';

export const Navbar: React.FC = () => {
  const {
    activePage,
    setActivePage,
    language,
    setLanguage,
    theme,
    setTheme,
    openSearch,
    openChat,
    nextPrayer,
    selectedCity,
    devotionals,
    currentUser,
    signInGoogle,
    signOutUser,
  } = useApp();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [langDropdownOpen, setLangDropdownOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);

  const navItems: Array<{ id: NavPage; label: string; arabicLabel: string; icon: React.ComponentType<{ className?: string }> }> = [
    { id: 'home', label: 'Home', arabicLabel: 'الرئيسية', icon: Sparkles },
    { id: 'quran', label: "Qur'an", arabicLabel: 'القرآن', icon: BookOpen },
    { id: 'hadith', label: 'Hadith', arabicLabel: 'الحديث', icon: BookMarked },
    { id: 'worship', label: 'Worship', arabicLabel: 'العبادات', icon: Compass },
    { id: 'devotional', label: 'Devotional', arabicLabel: 'الأذكار والموالد', icon: Heart },
    { id: 'library', label: 'Library (16)', arabicLabel: 'المكتبة الرقمية', icon: FolderOpen },
    { id: 'knowledge', label: 'Knowledge', arabicLabel: 'المعرفة', icon: BookOpen },
    { id: 'learning', label: 'Academy', arabicLabel: 'التعليم', icon: GraduationCap },
    { id: 'kids', label: 'Kids', arabicLabel: 'الأطفال', icon: Baby },
  ];

  const handleNav = (page: NavPage) => {
    setActivePage(page);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const languages: Array<{ code: Language; label: string; nativeName: string }> = [
    { code: 'en', label: 'English', nativeName: 'English' },
    { code: 'ar', label: 'Arabic', nativeName: 'العربية' },
    { code: 'ml', label: 'Malayalam', nativeName: 'മലയാളം' },
  ];

  return (
    <header className="sticky top-0 z-40 w-full backdrop-blur-md bg-white/90 dark:bg-emerald-950/90 border-b border-emerald-900/10 dark:border-emerald-800/30 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-18">
          {/* Logo & Brand */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => handleNav('home')}>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-700 to-emerald-900 text-amber-300 flex items-center justify-center shadow-md shadow-emerald-900/10 border border-amber-400/20">
              <span className="font-serif text-2xl font-bold tracking-tighter">ن</span>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-cinzel text-lg font-bold tracking-wider text-emerald-950 dark:text-emerald-50">
                  NOOR
                </span>
                <span className="text-[10px] uppercase font-semibold px-1.5 py-0.5 rounded bg-emerald-100 dark:bg-emerald-900/60 text-emerald-800 dark:text-emerald-300 tracking-wider">
                  Digital
                </span>
              </div>
              <p className="text-[11px] text-slate-500 dark:text-emerald-400/80 font-medium tracking-tight">
                Qur'an · Hadith · Devotional · Academy
              </p>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden xl:flex items-center gap-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activePage === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNav(item.id)}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                    isActive
                      ? 'bg-emerald-900/10 dark:bg-emerald-500/15 text-emerald-900 dark:text-emerald-300 font-semibold'
                      : 'text-slate-600 dark:text-slate-300 hover:text-emerald-800 dark:hover:text-emerald-200 hover:bg-emerald-50 dark:hover:bg-emerald-900/30'
                  }`}
                >
                  <Icon className="w-4 h-4 opacity-80" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Right Action Icons & Controls */}
          <div className="flex items-center gap-2">
            {/* Quick Next Prayer Pill */}
            <div
              onClick={() => handleNav('worship')}
              className="hidden md:flex items-center gap-2 px-2.5 py-1.5 rounded-lg bg-emerald-50 dark:bg-emerald-900/40 border border-emerald-200/60 dark:border-emerald-700/40 text-xs text-emerald-900 dark:text-emerald-200 cursor-pointer hover:bg-emerald-100/70 transition"
              title={`Prayer times for ${selectedCity}`}
            >
              <Clock className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 animate-pulse" />
              <span className="font-semibold">{nextPrayer.name}:</span>
              <span className="text-emerald-700 dark:text-emerald-300">{nextPrayer.time} ({nextPrayer.remainingText})</span>
            </div>

            {/* Global Search Trigger */}
            <button
              onClick={openSearch}
              className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-emerald-900/30 text-slate-600 dark:text-slate-300 hover:bg-slate-200/70 dark:hover:bg-emerald-800/40 text-xs font-medium border border-slate-200 dark:border-emerald-800/50 transition"
              title="Search everything (Ctrl+K)"
            >
              <Search className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400" />
              <span className="hidden sm:inline">Search</span>
              <kbd className="hidden sm:inline-block px-1.5 py-0.5 text-[10px] font-mono bg-white dark:bg-emerald-950 rounded border border-slate-300 dark:border-emerald-800 text-slate-500">
                ⌘K
              </kbd>
            </button>

            {/* Language Switcher Dropdown */}
            <div className="relative">
              <button
                onClick={() => setLangDropdownOpen(!langDropdownOpen)}
                className="p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-emerald-900/40 transition"
                title="Change language"
              >
                <Globe className="w-4 h-4" />
              </button>
              {langDropdownOpen && (
                <div className="absolute right-0 mt-2 w-36 py-1 bg-white dark:bg-emerald-900 rounded-xl shadow-xl border border-slate-200 dark:border-emerald-800 z-50">
                  {languages.map((l) => (
                    <button
                      key={l.code}
                      onClick={() => {
                        setLanguage(l.code);
                        setLangDropdownOpen(false);
                      }}
                      className={`w-full text-left px-3 py-1.5 text-xs flex items-center justify-between ${
                        language === l.code
                          ? 'bg-emerald-50 dark:bg-emerald-800 text-emerald-800 dark:text-amber-300 font-bold'
                          : 'text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-emerald-800/50'
                      }`}
                    >
                      <span>{l.label}</span>
                      <span className="text-[11px] opacity-70">{l.nativeName}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Theme Toggle */}
            <button
              onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
              className="p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-emerald-900/40 transition"
              title="Toggle Day/Night Mode"
            >
              {theme === 'dark' ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
            </button>

            {/* User Dashboard / Bookmarks shortcut */}
            <button
              onClick={() => handleNav('dashboard')}
              className={`p-2 rounded-lg transition ${
                activePage === 'dashboard'
                  ? 'bg-emerald-100 dark:bg-emerald-800 text-emerald-900 dark:text-white'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-emerald-900/40'
              }`}
              title="Personal Worship Dashboard"
            >
              <LayoutDashboard className="w-4 h-4" />
            </button>

            {/* Noor AI Scholar Trigger */}
            <button
              onClick={openChat}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-amber-500/15 border border-amber-500/35 text-amber-950 dark:text-amber-300 hover:bg-amber-500/25 transition shadow-2xs"
              title="Ask Noor AI (Quran, Hadith & Maps Grounding)"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
              <span className="hidden sm:inline">Noor AI</span>
            </button>

            {/* Admin CMS Portal Trigger */}
            <button
              onClick={() => handleNav('admin')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition shadow-sm ${
                activePage === 'admin'
                  ? 'bg-emerald-800 text-white dark:bg-amber-500 dark:text-slate-950 shadow-emerald-900/20'
                  : 'bg-emerald-900/10 dark:bg-emerald-500/20 text-emerald-900 dark:text-emerald-200 hover:bg-emerald-900/20 dark:hover:bg-emerald-500/30 border border-emerald-800/20'
              }`}
              title="Open Admin CMS Control Center"
            >
              <ShieldCheck className="w-4 h-4 text-emerald-700 dark:text-amber-400" />
              <span className="hidden sm:inline">Admin CMS</span>
            </button>

            {/* Google Sign-in / User Account Button */}
            <div className="relative">
              {currentUser ? (
                <div>
                  <button
                    onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                    className="flex items-center gap-1.5 p-1 rounded-full border border-emerald-600/30 hover:ring-2 hover:ring-emerald-500 transition"
                    title={`Signed in as ${currentUser.displayName || currentUser.email}`}
                  >
                    {currentUser.photoURL ? (
                      <img
                        src={currentUser.photoURL}
                        alt="Profile"
                        className="w-7 h-7 rounded-full object-cover border border-emerald-700/50"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="w-7 h-7 rounded-full bg-emerald-800 text-white flex items-center justify-center text-xs font-bold">
                        {(currentUser.displayName || currentUser.email || 'U')[0].toUpperCase()}
                      </div>
                    )}
                  </button>

                  {userDropdownOpen && (
                    <div className="absolute right-0 mt-2 w-64 bg-white dark:bg-slate-900 rounded-xl shadow-2xl border border-slate-200 dark:border-slate-800 p-3 z-50 animate-in fade-in zoom-in-95">
                      <div className="flex items-center gap-2.5 pb-2.5 mb-2 border-b border-slate-100 dark:border-slate-800">
                        {currentUser.photoURL ? (
                          <img
                            src={currentUser.photoURL}
                            alt="Profile"
                            className="w-9 h-9 rounded-full object-cover border border-emerald-500"
                            referrerPolicy="no-referrer"
                          />
                        ) : (
                          <div className="w-9 h-9 rounded-full bg-emerald-800 text-white flex items-center justify-center text-sm font-bold">
                            {(currentUser.displayName || currentUser.email || 'U')[0].toUpperCase()}
                          </div>
                        )}
                        <div className="overflow-hidden">
                          <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                            {currentUser.displayName || 'Account User'}
                          </p>
                          <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                            {currentUser.email}
                          </p>
                        </div>
                      </div>

                      <div className="text-[10px] uppercase font-bold tracking-wider text-emerald-600 dark:text-emerald-400 px-2 py-1 rounded bg-emerald-50 dark:bg-emerald-950/60 mb-2">
                        Firestore Connected (Live Sync)
                      </div>

                      <button
                        onClick={() => {
                          signOutUser();
                          setUserDropdownOpen(false);
                        }}
                        className="w-full flex items-center gap-2 px-3 py-2 text-xs font-semibold text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition"
                      >
                        <LogOut className="w-4 h-4" />
                        <span>Sign Out</span>
                      </button>
                    </div>
                  )}
                </div>
              ) : (
                <button
                  onClick={signInGoogle}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-emerald-800 text-white hover:bg-emerald-900 dark:bg-amber-500 dark:text-slate-950 dark:hover:bg-amber-400 transition shadow-sm"
                  title="Sign In with Google"
                >
                  <LogIn className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Sign In</span>
                </button>
              )}
            </div>

            {/* Mobile Hamburger Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="xl:hidden p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-emerald-900/40"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Drawer */}
      {mobileMenuOpen && (
        <div className="xl:hidden border-t border-emerald-900/10 dark:border-emerald-800/30 bg-white/95 dark:bg-emerald-950/95 backdrop-blur-lg px-4 pt-3 pb-6 space-y-1 shadow-2xl animate-in slide-in-from-top-2">
          <div className="grid grid-cols-2 gap-2 pb-3 mb-2 border-b border-slate-100 dark:border-emerald-900/50">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activePage === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNav(item.id)}
                  className={`flex items-center gap-2 px-3 py-2.5 rounded-lg text-sm font-medium ${
                    isActive
                      ? 'bg-emerald-800 text-white dark:bg-emerald-700'
                      : 'text-slate-700 dark:text-slate-200 bg-slate-50 dark:bg-emerald-900/30'
                  }`}
                >
                  <Icon className="w-4 h-4 opacity-80" />
                  <div className="text-left">
                    <span className="block leading-tight">{item.label}</span>
                    <span className="block text-[10px] opacity-70 font-serif">{item.arabicLabel}</span>
                  </div>
                </button>
              );
            })}
          </div>

          <div className="flex items-center justify-between pt-1 gap-2">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                openChat();
              }}
              className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold bg-amber-100 dark:bg-amber-950/60 text-amber-950 dark:text-amber-200 border border-amber-300/60"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-600" />
              <span>Noor AI</span>
            </button>
            <button
              onClick={() => handleNav('dashboard')}
              className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold bg-emerald-50 dark:bg-emerald-900/30 text-emerald-900 dark:text-emerald-200"
            >
              <LayoutDashboard className="w-4 h-4" />
              <span>Dashboard</span>
            </button>
            <button
              onClick={() => handleNav('admin')}
              className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200"
            >
              <ShieldCheck className="w-4 h-4" />
              <span>Admin</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
