import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Play, Pause, X, Volume2, VolumeX, FastForward, RotateCcw } from 'lucide-react';

export const AudioPlayerBar: React.FC = () => {
  const {
    activeAudioTrack,
    isPlaying,
    togglePlayPause,
    pauseAudio,
    audioProgress,
    audioDuration,
    seekAudio,
    playbackSpeed,
    setPlaybackSpeed,
  } = useApp();

  const [muted, setMuted] = useState(false);
  const [speedMenuOpen, setSpeedMenuOpen] = useState(false);

  if (!activeAudioTrack) return null;

  const formatTime = (secs: number) => {
    if (isNaN(secs) || secs === 0) return '0:00';
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    seekAudio(Number(e.target.value));
  };

  const speeds = [0.75, 1, 1.25, 1.5];

  return (
    <div className="fixed bottom-12 xl:bottom-0 left-0 right-0 z-35 bg-emerald-950 text-white border-t border-emerald-800 shadow-2xl backdrop-blur-xl px-4 py-2.5 transition-all">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-3">
        {/* Track info */}
        <div className="flex items-center gap-3 w-full md:w-1/3 min-w-0">
          <div className="w-9 h-9 rounded-lg bg-emerald-800 flex items-center justify-center shrink-0 border border-emerald-700 text-amber-300 font-serif">
            {isPlaying ? (
              <span className="flex items-end gap-0.5 h-4">
                <span className="w-1 bg-amber-400 animate-[bounce_1s_infinite_100ms] h-full rounded"></span>
                <span className="w-1 bg-amber-400 animate-[bounce_1s_infinite_300ms] h-3/4 rounded"></span>
                <span className="w-1 bg-amber-400 animate-[bounce_1s_infinite_200ms] h-1/2 rounded"></span>
              </span>
            ) : (
              '♪'
            )}
          </div>
          <div className="truncate">
            <div className="flex items-center gap-2">
              <h4 className="text-xs font-semibold text-white truncate">{activeAudioTrack.title}</h4>
              <span className="text-[10px] uppercase font-bold px-1 py-0.2 rounded bg-emerald-800 text-emerald-300">
                {activeAudioTrack.category}
              </span>
            </div>
            <p className="text-[11px] text-emerald-400/90 truncate">{activeAudioTrack.subtitle}</p>
          </div>
        </div>

        {/* Center Controls & Progress */}
        <div className="flex flex-col items-center gap-1 w-full md:w-1/2">
          <div className="flex items-center gap-4">
            <button
              onClick={() => seekAudio(Math.max(0, audioProgress - 5))}
              className="text-slate-400 hover:text-white transition"
              title="Rewind 5 seconds"
            >
              <RotateCcw className="w-4 h-4" />
            </button>

            <button
              onClick={togglePlayPause}
              className="w-8 h-8 rounded-full bg-amber-400 text-slate-950 flex items-center justify-center hover:bg-amber-300 transition shadow-md shadow-amber-400/20"
            >
              {isPlaying ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current ml-0.5" />}
            </button>

            <button
              onClick={() => seekAudio(Math.min(audioDuration || 60, audioProgress + 5))}
              className="text-slate-400 hover:text-white transition"
              title="Forward 5 seconds"
            >
              <FastForward className="w-4 h-4" />
            </button>
          </div>

          <div className="w-full flex items-center gap-2">
            <span className="text-[10px] font-mono text-emerald-400/80 w-8 text-right">
              {formatTime(audioProgress)}
            </span>
            <input
              type="range"
              min={0}
              max={audioDuration || 100}
              value={audioProgress}
              onChange={handleSeek}
              className="w-full h-1.5 bg-emerald-900 rounded-lg appearance-none cursor-pointer accent-amber-400"
            />
            <span className="text-[10px] font-mono text-emerald-400/80 w-8">
              {formatTime(audioDuration)}
            </span>
          </div>
        </div>

        {/* Right side options: Speed, Mute, Close */}
        <div className="hidden md:flex items-center gap-2 justify-end w-1/4">
          <div className="relative">
            <button
              onClick={() => setSpeedMenuOpen(!speedMenuOpen)}
              className="px-2 py-1 text-[11px] font-semibold rounded bg-emerald-900/80 hover:bg-emerald-800 text-emerald-200 border border-emerald-700/50"
            >
              {playbackSpeed}x
            </button>
            {speedMenuOpen && (
              <div className="absolute bottom-8 right-0 bg-emerald-900 border border-emerald-700 rounded-lg shadow-xl py-1 z-50">
                {speeds.map((s) => (
                  <button
                    key={s}
                    onClick={() => {
                      setPlaybackSpeed(s);
                      setSpeedMenuOpen(false);
                    }}
                    className={`block w-full text-left px-3 py-1 text-xs ${
                      playbackSpeed === s ? 'bg-amber-400 text-slate-950 font-bold' : 'text-emerald-100 hover:bg-emerald-800'
                    }`}
                  >
                    {s}x
                  </button>
                ))}
              </div>
            )}
          </div>

          <button
            onClick={() => setMuted(!muted)}
            className="p-1.5 text-emerald-300 hover:text-white transition"
            title={muted ? 'Unmute' : 'Mute'}
          >
            {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>

          <button
            onClick={pauseAudio}
            className="p-1.5 text-emerald-400 hover:text-rose-400 transition"
            title="Stop & Close Audio"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
