import React from 'react';
import { Database, HardDrive, Globe, RefreshCw, Layers, ShieldCheck } from 'lucide-react';
import { SupportedLanguage, getTranslation } from '../../i18n/translations';

interface Props {
  currentLang: SupportedLanguage;
  totalFiles: number;
  publishedCount: number;
  draftCount: number;
}

export const AdminArchitectureBanner: React.FC<Props> = ({
  currentLang,
  totalFiles,
  publishedCount,
  draftCount,
}) => {
  const t = getTranslation(currentLang);

  return (
    <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-emerald-900 text-white rounded-2xl p-5 sm:p-6 shadow-xl border border-emerald-800/40 relative overflow-hidden">
      {/* Decorative Islamic geometric background watermark */}
      <div className="absolute right-0 top-0 bottom-0 opacity-10 pointer-events-none flex items-center pr-6">
        <span className="text-9xl font-serif">م</span>
      </div>

      <div className="relative z-10">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 border-b border-emerald-800/40 pb-5">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="p-1 rounded-md bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-semibold uppercase tracking-wider flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" />
                Decoupled CMS Architecture
              </span>
              <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-medium">
                16 Categories Live
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
              {t.adminPanelTitle}
            </h1>
            <p className="text-xs sm:text-sm text-emerald-200/80 mt-1 max-w-3xl leading-relaxed">
              {t.adminPanelSub}
            </p>
          </div>

          {/* Quick Counter Pills */}
          <div className="flex flex-wrap items-center gap-2">
            <div className="px-3 py-1.5 rounded-xl bg-slate-800/80 border border-emerald-700/40 text-left">
              <div className="text-[10px] text-emerald-300 uppercase tracking-wider font-semibold">Total Records</div>
              <div className="text-lg font-bold text-white">{totalFiles}</div>
            </div>
            <div className="px-3 py-1.5 rounded-xl bg-emerald-900/60 border border-emerald-500/40 text-left">
              <div className="text-[10px] text-emerald-300 uppercase tracking-wider font-semibold">Published</div>
              <div className="text-lg font-bold text-emerald-300">{publishedCount}</div>
            </div>
            <div className="px-3 py-1.5 rounded-xl bg-amber-950/60 border border-amber-600/40 text-left">
              <div className="text-[10px] text-amber-300 uppercase tracking-wider font-semibold">Drafts</div>
              <div className="text-lg font-bold text-amber-300">{draftCount}</div>
            </div>
          </div>
        </div>

        {/* 3 Pillars: Storage + Database + Public Website Sync */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5 mt-5">
          {/* Pillar 1: Storage Layer */}
          <div className="p-3.5 rounded-xl bg-slate-900/60 border border-emerald-800/30 flex items-start gap-3">
            <div className="p-2 rounded-lg bg-emerald-800/40 text-emerald-400 shrink-0">
              <HardDrive className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                <span>Storage Layer</span>
                <span className="text-[10px] text-emerald-400 font-mono">(Files & Blobs)</span>
              </h4>
              <p className="text-[11px] text-slate-300 mt-1 leading-snug">
                {t.storageLayerDesc}
              </p>
            </div>
          </div>

          {/* Pillar 2: Database Layer */}
          <div className="p-3.5 rounded-xl bg-slate-900/60 border border-emerald-800/30 flex items-start gap-3">
            <div className="p-2 rounded-lg bg-amber-600/30 text-amber-300 shrink-0">
              <Database className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                <span>Database Layer</span>
                <span className="text-[10px] text-amber-400 font-mono">(Metadata & History)</span>
              </h4>
              <p className="text-[11px] text-slate-300 mt-1 leading-snug">
                {t.databaseLayerDesc}
              </p>
            </div>
          </div>

          {/* Pillar 3: Public Website Sync */}
          <div className="p-3.5 rounded-xl bg-slate-900/60 border border-emerald-800/30 flex items-start gap-3">
            <div className="p-2 rounded-lg bg-blue-600/30 text-blue-300 shrink-0">
              <Globe className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                <span>Public Website Sync</span>
                <span className="inline-flex items-center px-1.5 py-0.2 rounded text-[9px] bg-emerald-500/20 text-emerald-300 font-medium animate-pulse">
                  Live
                </span>
              </h4>
              <p className="text-[11px] text-slate-300 mt-1 leading-snug">
                {t.publicSyncDesc}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
