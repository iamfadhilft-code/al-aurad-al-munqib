import React, { useState, useRef } from 'react';
import { X, RefreshCw, Upload, AlertTriangle, CheckCircle2, History, FileText } from 'lucide-react';
import { ManagedFileItem } from '../../types/storage';
import { SupportedLanguage, getTranslation } from '../../i18n/translations';
import { StorageService } from '../../services/storageService';

interface Props {
  isOpen: boolean;
  fileItem: ManagedFileItem | null;
  onClose: () => void;
  onReplace: (
    fileId: string,
    newFileData: {
      storagePath: string;
      fileName: string;
      fileSize: string;
      mimeType?: string;
      changeNote?: string;
    },
    publishImmediately: boolean
  ) => void;
  currentLang: SupportedLanguage;
}

export const FileReplaceModal: React.FC<Props> = ({
  isOpen,
  fileItem,
  onClose,
  onReplace,
  currentLang,
}) => {
  const t = getTranslation(currentLang);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const [selectedFileName, setSelectedFileName] = useState('');
  const [fileSizeStr, setFileSizeStr] = useState('');
  const [storagePath, setStoragePath] = useState('');
  const [mimeType, setMimeType] = useState('');
  const [changeNote, setChangeNote] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  if (!isOpen || !fileItem) return null;

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsProcessing(true);
    try {
      setSelectedFileName(file.name);
      setFileSizeStr(StorageService.formatFileSize(file.size));
      setMimeType(file.type || 'application/octet-stream');

      const dataUrl = await StorageService.readFileAsDataUrl(file);
      setStoragePath(dataUrl);
    } catch (err) {
      console.error('Error reading replacement file', err);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleSubmit = (publishImmediately: boolean) => {
    const finalPath = storagePath || `https://archive.org/download/maktabah/${selectedFileName || 'file-updated.pdf'}`;
    const finalFileName = selectedFileName || `updated-${fileItem.fileName}`;
    const finalSize = fileSizeStr || fileItem.fileSize;

    onReplace(
      fileItem.id,
      {
        storagePath: finalPath,
        fileName: finalFileName,
        fileSize: finalSize,
        mimeType: mimeType || fileItem.mimeType,
        changeNote: changeNote.trim() || `Replaced file with ${finalFileName}`,
      },
      publishImmediately
    );

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm">
      <div className="bg-white dark:bg-slate-900 rounded-2xl w-full max-w-xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-amber-500/10">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-amber-500/20 text-amber-700 dark:text-amber-400">
              <RefreshCw className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                {t.replaceFile}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Safe Version Backup & Automatic Rollback Support
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-4 text-sm">
          {/* Active Version Snapshot Card */}
          <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60">
            <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 mb-1">
              <span className="font-semibold uppercase tracking-wider">{t.currentFile}</span>
              <span className="px-2 py-0.5 rounded font-mono font-bold bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200">
                v{fileItem.version}
              </span>
            </div>
            <h3 className="font-bold text-slate-900 dark:text-white text-base">
              {fileItem.title}
            </h3>
            <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-600 dark:text-slate-300 mt-2 font-mono">
              <span>File: {fileItem.fileName}</span>
              <span>•</span>
              <span>Size: {fileItem.fileSize}</span>
              <span>•</span>
              <span>Date: {fileItem.updatedDate}</span>
            </div>

            {/* Version backup notice */}
            <div className="mt-3 pt-3 border-t border-slate-200 dark:border-slate-700 flex items-center gap-2 text-xs text-rose-700 dark:text-rose-300 bg-rose-50 dark:bg-rose-950/40 p-2.5 rounded-lg border border-rose-200 dark:border-rose-900/60">
              <RefreshCw className="w-4 h-4 shrink-0 text-rose-600 animate-spin" style={{ animationDuration: '4s' }} />
              <span className="font-medium">
                {currentLang === 'ml'
                  ? 'ഡാറ്റാബേസ് അപ്‌ഡേറ്റ്: അഡ്മിൻ ഈ ഫയൽ റീപ്ലേസ് ചെയ്യുമ്പോൾ, മാറ്റം നേരിട്ട് ഡാറ്റാബേസിൽ രേഖപ്പെടുത്തുകയും പഴയ ഫയൽ സ്ഥിരമായി ഡിലീറ്റ് ചെയ്യപ്പെടുകയും ചെയ്യും.'
                  : currentLang === 'ar'
                  ? 'تحديث قاعدة البيانات: عند استبدال الملف بواسطة المشرف، سيتم تطبيق التغييرات فوراً في قاعدة البيانات وحذف النسخة القديمة نهائياً.'
                  : 'Database Live Rule: When you replace this file, changes are saved to the database and the old version will be permanently deleted.'}
              </span>
            </div>
          </div>

          {/* New Replacement File Upload Box */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1.5">
              {t.uploadNewFileLabel} *
            </label>
            <div
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-amber-300 dark:border-amber-800/80 hover:border-amber-500 rounded-xl p-5 text-center cursor-pointer bg-amber-50/30 dark:bg-amber-950/20 transition group"
            >
              <input
                ref={fileInputRef}
                type="file"
                className="hidden"
                onChange={handleFileChange}
              />
              <div className="mx-auto w-10 h-10 rounded-full bg-amber-100 dark:bg-amber-900/60 text-amber-700 dark:text-amber-300 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
                <Upload className="w-5 h-5" />
              </div>
              {selectedFileName ? (
                <div>
                  <p className="font-semibold text-emerald-900 dark:text-emerald-300">{selectedFileName}</p>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    {fileSizeStr} · Ready to Replace
                  </p>
                </div>
              ) : (
                <div>
                  <p className="font-medium text-slate-800 dark:text-slate-200">
                    {t.chooseFile}
                  </p>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                    {t.dragAndDrop}
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Change Note */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1">
              {t.versionNotes}
            </label>
            <input
              type="text"
              placeholder={t.versionNotesPlaceholder}
              value={changeNote}
              onChange={(e) => setChangeNote(e.target.value)}
              className="w-full px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-amber-500 focus:outline-none"
            />
          </div>
        </div>

        {/* Footer with Save as Draft & Publish Immediately */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 px-6 py-4 bg-slate-50 dark:bg-slate-900/80 border-t border-slate-200 dark:border-slate-800">
          <button
            type="button"
            onClick={onClose}
            className="w-full sm:w-auto px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 font-medium text-xs transition"
          >
            {t.cancel}
          </button>

          <div className="flex items-center gap-2.5 w-full sm:w-auto">
            {/* Save as Draft */}
            <button
              type="button"
              disabled={isProcessing}
              onClick={() => handleSubmit(false)}
              className="flex-1 sm:flex-none px-4 py-2.5 rounded-xl border border-amber-500/50 bg-amber-50 dark:bg-amber-950/40 text-amber-900 dark:text-amber-200 hover:bg-amber-100 dark:hover:bg-amber-900/50 font-semibold text-xs transition flex items-center justify-center gap-1.5"
            >
              <AlertTriangle className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
              <span>{t.saveDraft}</span>
            </button>

            {/* Publish Immediately */}
            <button
              type="button"
              disabled={isProcessing}
              onClick={() => handleSubmit(true)}
              className="flex-1 sm:flex-none px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-800 text-white hover:from-emerald-700 hover:to-emerald-900 font-bold text-xs transition flex items-center justify-center gap-1.5 shadow-md shadow-emerald-900/20"
            >
              <CheckCircle2 className="w-3.5 h-3.5 text-amber-300" />
              <span>{t.publish}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
