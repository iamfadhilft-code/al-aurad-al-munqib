import React, { useState, useEffect } from 'react';
import { X, Edit3, Save, CheckCircle2 } from 'lucide-react';
import { ManagedFileItem, ManagedCategory } from '../../types/storage';
import { MANAGED_CATEGORIES, SupportedLanguage, getTranslation } from '../../i18n/translations';

interface Props {
  isOpen: boolean;
  fileItem: ManagedFileItem | null;
  onClose: () => void;
  onSave: (fileId: string, updates: Partial<ManagedFileItem>) => void;
  currentLang: SupportedLanguage;
}

export const MetadataEditModal: React.FC<Props> = ({
  isOpen,
  fileItem,
  onClose,
  onSave,
  currentLang,
}) => {
  const t = getTranslation(currentLang);

  const [title, setTitle] = useState('');
  const [titleMalayalam, setTitleMalayalam] = useState('');
  const [titleArabic, setTitleArabic] = useState('');
  const [author, setAuthor] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<ManagedCategory>('maulid-pdf');
  const [fileLanguage, setFileLanguage] = useState<'ml' | 'ar' | 'en' | 'all'>('ar');
  const [status, setStatus] = useState<'draft' | 'published'>('published');

  useEffect(() => {
    if (fileItem) {
      setTitle(fileItem.title);
      setTitleMalayalam(fileItem.titleMalayalam || '');
      setTitleArabic(fileItem.titleArabic || '');
      setAuthor(fileItem.author);
      setDescription(fileItem.description);
      setCategory(fileItem.category);
      setFileLanguage(fileItem.language);
      setStatus(fileItem.status);
    }
  }, [fileItem]);

  if (!isOpen || !fileItem) return null;

  const handleSave = () => {
    onSave(fileItem.id, {
      title: title.trim(),
      titleMalayalam: titleMalayalam.trim() || undefined,
      titleArabic: titleArabic.trim() || undefined,
      author: author.trim(),
      description: description.trim(),
      category,
      language: fileLanguage,
      status,
      publicVisibility: status === 'published',
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 rounded-2xl w-full max-w-xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/90">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-blue-100 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300">
              <Edit3 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                {t.editMetadata}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-mono">
                ID: {fileItem.id} · v{fileItem.version}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto text-sm">
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1">
              {t.title} (English / Standard) *
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1">
                Title in Malayalam (മലയാളം)
              </label>
              <input
                type="text"
                value={titleMalayalam}
                onChange={(e) => setTitleMalayalam(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1">
                Title in Arabic (العربية)
              </label>
              <input
                type="text"
                dir="rtl"
                value={titleArabic}
                onChange={(e) => setTitleArabic(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-arabic focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1">
                {t.category} *
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as ManagedCategory)}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-medium focus:ring-2 focus:ring-blue-500 focus:outline-none"
              >
                {MANAGED_CATEGORIES.map((cat) => (
                  <option key={cat.id} value={cat.id}>
                    {cat.emoji} {currentLang === 'ml' ? cat.titleMl : currentLang === 'ar' ? cat.titleAr : cat.titleEn}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1">
                {t.language} *
              </label>
              <select
                value={fileLanguage}
                onChange={(e) => setFileLanguage(e.target.value as any)}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
              >
                <option value="ar">Arabic (العربية)</option>
                <option value="ml">Malayalam (മലയാളം)</option>
                <option value="en">English</option>
                <option value="all">Multilingual</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1">
                {t.author}
              </label>
              <input
                type="text"
                value={author}
                onChange={(e) => setAuthor(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1">
                {t.status}
              </label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as 'draft' | 'published')}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
              >
                <option value="published">Published (Visible to Public)</option>
                <option value="draft">Draft (Internal Only)</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1">
              {t.description}
            </label>
            <textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:outline-none resize-none"
            />
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end gap-2.5 px-6 py-4 bg-slate-50 dark:bg-slate-900/80 border-t border-slate-200 dark:border-slate-800">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold transition"
          >
            {t.cancel}
          </button>
          <button
            onClick={handleSave}
            className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-md shadow-blue-900/20 transition"
          >
            <Save className="w-3.5 h-3.5" />
            <span>{t.saveChanges}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
