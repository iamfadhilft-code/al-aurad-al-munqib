import React, { useState, useRef } from 'react';
import { X, Upload, FileText, CheckCircle2, AlertCircle, Sparkles } from 'lucide-react';
import { ManagedCategory, ManagedFileItem, FileType } from '../../types/storage';
import { MANAGED_CATEGORIES, SupportedLanguage, getTranslation } from '../../i18n/translations';
import { StorageService } from '../../services/storageService';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onUpload: (
    data: Omit<ManagedFileItem, 'id' | 'version' | 'previousVersions' | 'uploadDate' | 'updatedDate'>
  ) => void;
  currentLang: SupportedLanguage;
}

export const FileUploadModal: React.FC<Props> = ({ isOpen, onClose, onUpload, currentLang }) => {
  const t = getTranslation(currentLang);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const [category, setCategory] = useState<ManagedCategory>('maulid-pdf');
  const [title, setTitle] = useState('');
  const [titleMalayalam, setTitleMalayalam] = useState('');
  const [titleArabic, setTitleArabic] = useState('');
  const [author, setAuthor] = useState('');
  const [description, setDescription] = useState('');
  const [fileLanguage, setFileLanguage] = useState<'ml' | 'ar' | 'en' | 'all'>('ar');

  // File storage state
  const [selectedFileName, setSelectedFileName] = useState('');
  const [fileSizeStr, setFileSizeStr] = useState('');
  const [fileType, setFileType] = useState<FileType>('pdf');
  const [storagePath, setStoragePath] = useState('');
  const [mimeType, setMimeType] = useState('application/pdf');
  const [isProcessingFile, setIsProcessingFile] = useState(false);

  if (!isOpen) return null;

  const currentCategoryDef = MANAGED_CATEGORIES.find((c) => c.id === category) || MANAGED_CATEGORIES[0];

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsProcessingFile(true);
    try {
      setSelectedFileName(file.name);
      setFileSizeStr(StorageService.formatFileSize(file.size));
      setMimeType(file.type || 'application/octet-stream');

      // Detect type
      if (file.type.includes('pdf')) setFileType('pdf');
      else if (file.type.includes('audio')) setFileType('audio');
      else if (file.type.includes('image')) setFileType('image');
      else if (file.type.includes('video')) setFileType('video');
      else setFileType('doc');

      // Auto-populate title if empty
      const baseName = file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ');
      if (!title) {
        setTitle(baseName.charAt(0).toUpperCase() + baseName.slice(1));
      }

      // Convert to Data URL
      const dataUrl = await StorageService.readFileAsDataUrl(file);
      setStoragePath(dataUrl);
    } catch (err) {
      console.error('Failed to read file', err);
    } finally {
      setIsProcessingFile(false);
    }
  };

  const handleSubmit = (status: 'draft' | 'published') => {
    if (!title.trim()) {
      alert('Please enter a title for the file.');
      return;
    }

    const finalPath = storagePath || `https://archive.org/download/maktabah/${selectedFileName || 'file.pdf'}`;
    const finalFileName = selectedFileName || `${title.toLowerCase().replace(/\s+/g, '-')}.${currentCategoryDef.defaultFileType}`;

    onUpload({
      title: title.trim(),
      titleArabic: titleArabic.trim() || undefined,
      titleMalayalam: titleMalayalam.trim() || undefined,
      description: description.trim() || `Authentic document in ${currentCategoryDef.titleEn}.`,
      category,
      language: fileLanguage,
      author: author.trim() || 'Traditional Scholar / Editorial Archive',
      storagePath: finalPath,
      fileName: finalFileName,
      fileType: fileType || currentCategoryDef.defaultFileType,
      mimeType: mimeType || 'application/pdf',
      fileSize: fileSizeStr || '3.5 MB',
      uploadedBy: 'Admin / Chief Editor',
      status,
      publicVisibility: status === 'published',
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 rounded-2xl w-full max-w-2xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden my-8">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/80">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-emerald-100 dark:bg-emerald-900/60 text-emerald-800 dark:text-emerald-300">
              <Upload className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                {t.uploadNewFile}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                16 Categories · Storage & Database Registry
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-4 max-h-[75vh] overflow-y-auto text-sm">
          {/* File Picker Box */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1.5">
              1. {t.chooseFile} *
            </label>
            <div
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-emerald-300 dark:border-emerald-800 hover:border-emerald-500 rounded-xl p-5 text-center cursor-pointer bg-emerald-50/40 dark:bg-emerald-950/20 transition group"
            >
              <input
                ref={fileInputRef}
                type="file"
                className="hidden"
                onChange={handleFileChange}
                accept={currentCategoryDef.allowedExtensions.join(',')}
              />
              <div className="mx-auto w-10 h-10 rounded-full bg-emerald-100 dark:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
                <Upload className="w-5 h-5" />
              </div>
              {selectedFileName ? (
                <div>
                  <p className="font-semibold text-emerald-900 dark:text-emerald-300">{selectedFileName}</p>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    {fileSizeStr} · {fileType.toUpperCase()}
                  </p>
                </div>
              ) : (
                <div>
                  <p className="font-medium text-slate-800 dark:text-slate-200">
                    {t.chooseFile}
                  </p>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                    {t.dragAndDrop} ({currentCategoryDef.allowedExtensions.join(', ')})
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Category Selector (16 categories) */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1.5">
              2. {t.category} (16 Categories) *
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value as ManagedCategory)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-medium focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            >
              {MANAGED_CATEGORIES.map((cat) => (
                <option key={cat.id} value={cat.id}>
                  {cat.emoji} {currentLang === 'ml' ? cat.titleMl : currentLang === 'ar' ? cat.titleAr : cat.titleEn} ({cat.defaultFileType.toUpperCase()})
                </option>
              ))}
            </select>
            <p className="text-[11px] text-emerald-700 dark:text-emerald-400 mt-1">
              {currentLang === 'ml' ? currentCategoryDef.descMl : currentLang === 'ar' ? currentCategoryDef.descAr : currentCategoryDef.descEn}
            </p>
          </div>

          {/* Title Inputs (Trilingual) */}
          <div className="space-y-3 pt-1">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1">
                {t.title} (English / Standard) *
              </label>
              <input
                type="text"
                placeholder="e.g. Maulid Manqoos Verified Edition"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1">
                  Title in Malayalam (മലയാളം)
                </label>
                <input
                  type="text"
                  placeholder="ഉദാ: മൻഖൂസ് മൗലിദ്"
                  value={titleMalayalam}
                  onChange={(e) => setTitleMalayalam(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1">
                  Title in Arabic (العربية)
                </label>
                <input
                  type="text"
                  dir="rtl"
                  placeholder="مثال: المولود المنقوص المبارك"
                  value={titleArabic}
                  onChange={(e) => setTitleArabic(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-arabic focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Author & Language */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1">
                {t.author}
              </label>
              <input
                type="text"
                placeholder="e.g. Shaykh Zayn al-Din Makhdoom I"
                value={author}
                onChange={(e) => setAuthor(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1">
                {t.language}
              </label>
              <select
                value={fileLanguage}
                onChange={(e) => setFileLanguage(e.target.value as any)}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              >
                <option value="ar">Arabic (العربية)</option>
                <option value="ml">Malayalam (മലയാളം)</option>
                <option value="en">English</option>
                <option value="all">Multilingual / General</option>
              </select>
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1">
              {t.description}
            </label>
            <textarea
              rows={2}
              placeholder="Brief summary of content, verified chain, or edition details..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none resize-none"
            />
          </div>
        </div>

        {/* Modal Footer with Save as Draft & Publish */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 px-6 py-4 bg-slate-50 dark:bg-slate-900/80 border-t border-slate-200 dark:border-slate-800">
          <button
            type="button"
            onClick={onClose}
            className="w-full sm:w-auto px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 font-medium text-xs transition"
          >
            {t.cancel}
          </button>

          <div className="flex items-center gap-2.5 w-full sm:w-auto">
            {/* Save as Draft */}
            <button
              type="button"
              disabled={isProcessingFile}
              onClick={() => handleSubmit('draft')}
              className="flex-1 sm:flex-none px-4 py-2.5 rounded-xl border border-amber-500/40 bg-amber-50 dark:bg-amber-950/40 text-amber-800 dark:text-amber-300 hover:bg-amber-100 dark:hover:bg-amber-900/50 font-semibold text-xs transition flex items-center justify-center gap-1.5 shadow-sm"
            >
              <AlertCircle className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
              <span>{t.saveDraft}</span>
            </button>

            {/* Publish Immediately */}
            <button
              type="button"
              disabled={isProcessingFile}
              onClick={() => handleSubmit('published')}
              className="flex-1 sm:flex-none px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-800 text-white hover:from-emerald-700 hover:to-emerald-900 font-bold text-xs transition flex items-center justify-center gap-1.5 shadow-md shadow-emerald-900/20"
            >
              <CheckCircle2 className="w-3.5 h-3.5 text-amber-300" />
              <span>{t.publish}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
