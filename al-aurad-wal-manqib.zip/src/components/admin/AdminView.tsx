import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { ManagedFileItem, ManagedCategory } from '../../types/storage';
import { DevotionalItem, Article } from '../../types';
import {
  ShieldCheck,
  Plus,
  Trash2,
  Edit2,
  FileText,
  Music,
  Heart,
  BookOpen,
  Search,
  Filter,
  RefreshCw,
  History,
  Download,
  Eye,
  CheckCircle2,
  AlertCircle,
  HardDrive,
  Database,
  Globe,
  Layers,
  ArrowUpDown,
  ExternalLink,
  ChevronRight,
  FolderOpen,
  Sparkles,
} from 'lucide-react';
import { MANAGED_CATEGORIES, SupportedLanguage, getTranslation } from '../../i18n/translations';
import { AdminArchitectureBanner } from './AdminArchitectureBanner';
import { FileUploadModal } from './FileUploadModal';
import { FileReplaceModal } from './FileReplaceModal';
import { VersionHistoryModal } from './VersionHistoryModal';
import { MetadataEditModal } from './MetadataEditModal';

export const AdminView: React.FC = () => {
  const {
    managedFiles,
    uploadNewFile,
    replaceFile,
    restoreFileVersion,
    removeFile,
    updateFileMetadata,
    toggleFilePublish,
    downloadManagedFile,
    previewManagedFile,
    devotionals,
    addDevotionalItem,
    updateDevotionalItem,
    deleteDevotionalItem,
    articles,
    addArticle,
    updateArticle,
    deleteArticle,
    auditLogs,
    adminRole,
    setAdminRole,
    currentUser,
    isFirestoreConnected,
    signInGoogle,
    purgeOldVersions,
    language,
    setLanguage,
    showToast,
  } = useApp();

  // Admin view language (synced with app, or toggleable locally)
  const currentLang: SupportedLanguage = (language === 'ml' || language === 'ar') ? language : 'en';
  const t = getTranslation(currentLang);

  // Main Tabs
  const [activeTab, setActiveTab] = useState<'files-16' | 'devotionals' | 'articles' | 'audit'>('files-16');

  // File Management Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<ManagedCategory | 'all'>('all');
  const [selectedLanguageFilter, setSelectedLanguageFilter] = useState<'all' | 'ar' | 'ml' | 'en'>('all');
  const [selectedStatusFilter, setSelectedStatusFilter] = useState<'all' | 'published' | 'draft'>('all');
  const [viewMode, setViewMode] = useState<'table' | 'cards'>('table');

  // Modals state
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [activeReplaceItem, setActiveReplaceItem] = useState<ManagedFileItem | null>(null);
  const [activeHistoryItem, setActiveHistoryItem] = useState<ManagedFileItem | null>(null);
  const [activeEditItem, setActiveEditItem] = useState<ManagedFileItem | null>(null);

  // Filtered files
  const filteredFiles = useMemo(() => {
    return managedFiles.filter((item) => {
      // Category filter
      if (selectedCategory !== 'all' && item.category !== selectedCategory) return false;

      // Language filter
      if (selectedLanguageFilter !== 'all' && item.language !== selectedLanguageFilter && item.language !== 'all') {
        return false;
      }

      // Status filter
      if (selectedStatusFilter !== 'all' && item.status !== selectedStatusFilter) return false;

      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesTitle = item.title.toLowerCase().includes(q);
        const matchesMl = item.titleMalayalam?.toLowerCase().includes(q) || false;
        const matchesAr = item.titleArabic?.toLowerCase().includes(q) || false;
        const matchesAuthor = item.author.toLowerCase().includes(q);
        const matchesFileName = item.fileName.toLowerCase().includes(q);
        const matchesDesc = item.description.toLowerCase().includes(q);

        if (!matchesTitle && !matchesMl && !matchesAr && !matchesAuthor && !matchesFileName && !matchesDesc) {
          return false;
        }
      }

      return true;
    });
  }, [managedFiles, selectedCategory, selectedLanguageFilter, selectedStatusFilter, searchQuery]);

  // Counts
  const publishedCount = useMemo(() => managedFiles.filter((f) => f.status === 'published').length, [managedFiles]);
  const draftCount = useMemo(() => managedFiles.filter((f) => f.status === 'draft').length, [managedFiles]);

  const handleRemoveConfirm = (item: ManagedFileItem) => {
    const confirmMsg =
      currentLang === 'ml'
        ? `"${item.title}" (${item.fileName}) ഡാറ്റാബേസിൽ നിന്നും സ്റ്റോറേജിൽ നിന്നും സ്ഥിരമായി നീക്കം ചെയ്യണോ?`
        : currentLang === 'ar'
        ? `هل أنت متأكد من رغبتك في حذف الملف "${item.title}" نهائياً من قاعدة البيانات والتخزين؟`
        : `Are you sure you want to permanently remove "${item.title}" (${item.fileName}) from storage and database?`;

    if (window.confirm(confirmMsg)) {
      removeFile(item.id);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-in fade-in duration-300">
      {/* Top Admin Controls & Language Switcher */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-800 text-white dark:bg-amber-500 dark:text-slate-950 flex items-center justify-center shadow-md">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-bold font-serif text-slate-900 dark:text-white">
              {t.admin}
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {currentLang === 'ml'
                ? 'കണ്ടന്റ് & ഫയൽ മാനേജ്‌മെന്റ് സിസ്റ്റം'
                : currentLang === 'ar'
                ? 'نظام إدارة المحتوى والملفات المعتمدة'
                : 'Content & Media Management System'}
            </p>
          </div>
        </div>

        {/* Trilingual Interface Switcher for Admin Panel */}
        <div className="flex items-center gap-3 flex-wrap">
          {/* Language Pills (Malayalam, Arabic, English) */}
          <div className="flex items-center bg-slate-100 dark:bg-slate-800 p-1 rounded-xl border border-slate-200 dark:border-slate-700">
            <button
              onClick={() => setLanguage('ml')}
              className={`px-3 py-1 rounded-lg text-xs font-semibold transition ${
                language === 'ml'
                  ? 'bg-emerald-700 text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
              }`}
            >
              മലയാളം
            </button>
            <button
              onClick={() => setLanguage('ar')}
              className={`px-3 py-1 rounded-lg text-xs font-semibold font-arabic transition ${
                language === 'ar'
                  ? 'bg-emerald-700 text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
              }`}
            >
              العربية
            </button>
            <button
              onClick={() => setLanguage('en')}
              className={`px-3 py-1 rounded-lg text-xs font-semibold transition ${
                language === 'en'
                  ? 'bg-emerald-700 text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
              }`}
            >
              English
            </button>
          </div>

          {/* Role selector */}
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs">
            <span className="text-slate-500 dark:text-slate-400 font-medium">Role:</span>
            <select
              value={adminRole}
              onChange={(e) => setAdminRole(e.target.value as any)}
              className="bg-transparent font-bold text-slate-800 dark:text-slate-200 focus:outline-none cursor-pointer"
            >
              <option value="super_admin">Chief Administrator (Super)</option>
              <option value="admin">Content Admin</option>
              <option value="scholar">Preservation Scholar</option>
              <option value="editor">Manuscript Editor</option>
            </select>
          </div>
        </div>
      </div>

      {/* Decoupled Storage & Database Architecture Banner */}
      <AdminArchitectureBanner
        currentLang={currentLang}
        totalFiles={managedFiles.length}
        publishedCount={publishedCount}
        draftCount={draftCount}
      />

      {/* Real-time Cloud Firestore & Database Update Rule Banner */}
      <div className="bg-white dark:bg-slate-900 border border-emerald-600/30 rounded-xl p-4 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className={`w-3 h-3 rounded-full ${isFirestoreConnected ? 'bg-emerald-500 animate-pulse' : 'bg-amber-500'}`} />
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-900 dark:text-white flex items-center gap-1.5">
                <Database className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                Cloud Firestore Database: {isFirestoreConnected ? 'Live & Synchronized' : 'Connecting...'}
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 font-mono">
                integral-impulse-2t3g1
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              <strong className="text-emerald-700 dark:text-emerald-400">Data Policy Enforced:</strong> When an Admin replaces or updates a record, changes are committed to Firestore and old versions are deleted.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
          {currentUser ? (
            <div className="flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300 bg-slate-50 dark:bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700">
              <span className="w-2 h-2 rounded-full bg-emerald-500" />
              <span className="font-semibold">{currentUser.email}</span>
            </div>
          ) : (
            <button
              onClick={signInGoogle}
              className="px-3 py-1.5 rounded-lg text-xs font-bold bg-emerald-800 text-white hover:bg-emerald-700 dark:bg-amber-500 dark:text-slate-950 transition flex items-center gap-1.5"
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Admin Google Sign-in</span>
            </button>
          )}
        </div>
      </div>

      {/* Main Tabs Navigation */}
      <div className="flex border-b border-slate-200 dark:border-slate-800 overflow-x-auto gap-2">
        <button
          onClick={() => setActiveTab('files-16')}
          className={`pb-3 px-4 text-sm font-bold flex items-center gap-2 border-b-2 transition whitespace-nowrap ${
            activeTab === 'files-16'
              ? 'border-emerald-600 text-emerald-700 dark:text-emerald-400 dark:border-emerald-400'
              : 'border-transparent text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200'
          }`}
        >
          <FolderOpen className="w-4 h-4" />
          <span>16 Categories CMS & Storage ({managedFiles.length})</span>
          <span className="px-2 py-0.5 rounded-full text-[10px] bg-emerald-100 text-emerald-800 dark:bg-emerald-900/60 dark:text-emerald-300 font-mono font-bold">
            Live
          </span>
        </button>

        <button
          onClick={() => setActiveTab('devotionals')}
          className={`pb-3 px-4 text-sm font-bold flex items-center gap-2 border-b-2 transition whitespace-nowrap ${
            activeTab === 'devotionals'
              ? 'border-emerald-600 text-emerald-700 dark:text-emerald-400 dark:border-emerald-400'
              : 'border-transparent text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200'
          }`}
        >
          <Heart className="w-4 h-4" />
          <span>Devotionals Text ({devotionals.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('articles')}
          className={`pb-3 px-4 text-sm font-bold flex items-center gap-2 border-b-2 transition whitespace-nowrap ${
            activeTab === 'articles'
              ? 'border-emerald-600 text-emerald-700 dark:text-emerald-400 dark:border-emerald-400'
              : 'border-transparent text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200'
          }`}
        >
          <BookOpen className="w-4 h-4" />
          <span>Articles & Research ({articles.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('audit')}
          className={`pb-3 px-4 text-sm font-bold flex items-center gap-2 border-b-2 transition whitespace-nowrap ${
            activeTab === 'audit'
              ? 'border-emerald-600 text-emerald-700 dark:text-emerald-400 dark:border-emerald-400'
              : 'border-transparent text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200'
          }`}
        >
          <History className="w-4 h-4" />
          <span>Audit Logs ({auditLogs.length})</span>
        </button>
      </div>

      {/* ========================================================================= */}
      {/* TAB 1: 16 CATEGORIES CMS & FILE MANAGEMENT SYSTEM                        */}
      {/* ========================================================================= */}
      {activeTab === 'files-16' && (
        <div className="space-y-6">
          {/* Action Bar: Search, Category Filters, and Upload Button */}
          <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-4">
            {/* Search Input */}
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={t.searchPlaceholder}
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-white text-xs placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            {/* Language & Status Quick Filters */}
            <div className="flex items-center gap-2.5 flex-wrap">
              {/* Language Filter */}
              <select
                value={selectedLanguageFilter}
                onChange={(e) => setSelectedLanguageFilter(e.target.value as any)}
                className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200 text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500"
              >
                <option value="all">{t.allLanguages}</option>
                <option value="ar">Arabic (العربية)</option>
                <option value="ml">Malayalam (മലയാളം)</option>
                <option value="en">English</option>
              </select>

              {/* Status Filter */}
              <select
                value={selectedStatusFilter}
                onChange={(e) => setSelectedStatusFilter(e.target.value as any)}
                className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200 text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500"
              >
                <option value="all">All Status</option>
                <option value="published">{t.published}</option>
                <option value="draft">{t.draft}</option>
              </select>

              {/* Upload New File Button */}
              <button
                onClick={() => setIsUploadModalOpen(true)}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-700 to-emerald-900 text-white font-bold text-xs shadow-md shadow-emerald-900/20 hover:from-emerald-800 hover:to-emerald-950 transition"
              >
                <Plus className="w-4 h-4 text-amber-300" />
                <span>{t.uploadNewFile}</span>
              </button>
            </div>
          </div>

          {/* 16 Categories Horizontal Scrollable Filter Strip */}
          <div>
            <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 font-semibold mb-2">
              <span className="uppercase tracking-wider">Categories (16)</span>
              <button
                onClick={() => setSelectedCategory('all')}
                className={`text-xs hover:underline ${selectedCategory === 'all' ? 'text-emerald-600 font-bold' : ''}`}
              >
                {t.allCategories} ({managedFiles.length})
              </button>
            </div>

            <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-thin">
              <button
                onClick={() => setSelectedCategory('all')}
                className={`px-3 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 shrink-0 transition ${
                  selectedCategory === 'all'
                    ? 'bg-emerald-800 text-white shadow-sm'
                    : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-800 hover:bg-slate-50'
                }`}
              >
                <span>✨</span>
                <span>{t.allCategories}</span>
                <span className="opacity-75">({managedFiles.length})</span>
              </button>

              {MANAGED_CATEGORIES.map((cat) => {
                const count = managedFiles.filter((f) => f.category === cat.id).length;
                const isSelected = selectedCategory === cat.id;
                const label = currentLang === 'ml' ? cat.titleMl : currentLang === 'ar' ? cat.titleAr : cat.titleEn;
                return (
                  <button
                    key={cat.id}
                    onClick={() => setSelectedCategory(cat.id)}
                    className={`px-3 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 shrink-0 transition ${
                      isSelected
                        ? 'bg-emerald-800 text-white shadow-sm'
                        : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800'
                    }`}
                  >
                    <span>{cat.emoji}</span>
                    <span>{label}</span>
                    <span className="opacity-75 font-mono">({count})</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Records Count & View Mode Toggle */}
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 pt-2">
            <div>
              Showing <span className="font-bold text-slate-800 dark:text-slate-200">{filteredFiles.length}</span> records
              {selectedCategory !== 'all' && <span> in selected category</span>}
            </div>
            <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-lg">
              <button
                onClick={() => setViewMode('table')}
                className={`px-2.5 py-1 rounded text-xs font-semibold transition ${
                  viewMode === 'table' ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs' : 'text-slate-500'
                }`}
              >
                Table View
              </button>
              <button
                onClick={() => setViewMode('cards')}
                className={`px-2.5 py-1 rounded text-xs font-semibold transition ${
                  viewMode === 'cards' ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs' : 'text-slate-500'
                }`}
              >
                Card View
              </button>
            </div>
          </div>

          {/* TABLE VIEW */}
          {viewMode === 'table' && (
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-700 dark:text-slate-300">
                  <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-500 dark:text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-200 dark:border-slate-800">
                    <tr>
                      <th className="px-4 py-3.5">{t.title} / Metadata</th>
                      <th className="px-4 py-3.5">{t.category}</th>
                      <th className="px-4 py-3.5">{t.storagePath}</th>
                      <th className="px-4 py-3.5 text-center">{t.version}</th>
                      <th className="px-4 py-3.5 text-center">{t.status}</th>
                      <th className="px-4 py-3.5 text-right">{t.actions}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {filteredFiles.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="px-6 py-12 text-center text-slate-400">
                          <FolderOpen className="w-8 h-8 mx-auto mb-2 opacity-40 text-slate-400" />
                          <p className="font-semibold text-sm">No files found matching your criteria</p>
                          <p className="text-xs mt-1">Try resetting filters or upload a new file.</p>
                        </td>
                      </tr>
                    ) : (
                      filteredFiles.map((item) => {
                        const catDef = MANAGED_CATEGORIES.find((c) => c.id === item.category);
                        const catName = currentLang === 'ml' ? catDef?.titleMl : currentLang === 'ar' ? catDef?.titleAr : catDef?.titleEn;

                        return (
                          <tr
                            key={item.id}
                            className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition group"
                          >
                            {/* Title & Metadata */}
                            <td className="px-4 py-3.5 max-w-xs sm:max-w-sm">
                              <div className="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
                                <span>{item.title}</span>
                                {item.lastReplacedNote && (
                                  <span className="text-[9px] px-1.5 py-0.5 rounded bg-amber-100 text-amber-900 dark:bg-amber-950/60 dark:text-amber-300 font-semibold border border-amber-300 dark:border-amber-800" title={item.lastReplacedNote}>
                                    DB Updated · Old Purged
                                  </span>
                                )}
                              </div>
                              {(item.titleMalayalam || item.titleArabic) && (
                                <div className="flex items-center gap-2 mt-0.5 text-[11px] text-slate-500 dark:text-slate-400">
                                  {item.titleMalayalam && <span className="text-emerald-700 dark:text-emerald-400">{item.titleMalayalam}</span>}
                                  {item.titleMalayalam && item.titleArabic && <span>•</span>}
                                  {item.titleArabic && <span className="font-arabic font-semibold">{item.titleArabic}</span>}
                                </div>
                              )}
                              <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 flex items-center gap-2">
                                <span className="font-medium text-slate-700 dark:text-slate-300">{item.author}</span>
                                <span>•</span>
                                <span className="uppercase text-[10px] px-1.5 py-0.2 rounded bg-slate-100 dark:bg-slate-800 font-semibold">
                                  {item.language}
                                </span>
                              </div>
                            </td>

                            {/* Category */}
                            <td className="px-4 py-3.5 whitespace-nowrap">
                              <div className="flex items-center gap-1.5">
                                <span>{catDef?.emoji}</span>
                                <span className="font-semibold text-slate-800 dark:text-slate-200">
                                  {catName || item.category}
                                </span>
                              </div>
                            </td>

                            {/* Storage Info */}
                            <td className="px-4 py-3.5 max-w-[200px]">
                              <div className="font-mono text-slate-800 dark:text-slate-200 font-semibold truncate" title={item.fileName}>
                                {item.fileName}
                              </div>
                              <div className="text-[10px] text-slate-500 dark:text-slate-400 font-mono mt-0.5 flex items-center gap-2">
                                <span>{item.fileSize}</span>
                                <span>•</span>
                                <span className="uppercase">{item.fileType}</span>
                              </div>
                            </td>

                            {/* Version & History */}
                            <td className="px-4 py-3.5 text-center whitespace-nowrap">
                              <div className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full font-mono font-bold text-xs bg-purple-100 text-purple-800 dark:bg-purple-950/60 dark:text-purple-300 border border-purple-200 dark:border-purple-800">
                                v{item.version}
                              </div>
                              {item.previousVersions.length > 0 && (
                                <button
                                  onClick={() => setActiveHistoryItem(item)}
                                  className="block text-[10px] text-purple-600 dark:text-purple-400 font-semibold mt-1 hover:underline cursor-pointer"
                                  title="View previous version backups"
                                >
                                  {item.previousVersions.length} backup{item.previousVersions.length > 1 ? 's' : ''}
                                </button>
                              )}
                            </td>

                            {/* Status (Published vs Draft) */}
                            <td className="px-4 py-3.5 text-center whitespace-nowrap">
                              <button
                                onClick={() => toggleFilePublish(item.id)}
                                className={`px-2.5 py-1 rounded-full text-[11px] font-bold uppercase tracking-wider transition ${
                                  item.status === 'published'
                                    ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300 hover:bg-emerald-200'
                                    : 'bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300 hover:bg-amber-200'
                                }`}
                                title="Click to toggle Draft / Published status"
                              >
                                {item.status === 'published' ? t.published : t.draft}
                              </button>
                            </td>

                            {/* Actions Group */}
                            <td className="px-4 py-3.5 text-right whitespace-nowrap">
                              <div className="flex items-center justify-end gap-1.5">
                                {/* Preview */}
                                <button
                                  onClick={() => previewManagedFile(item)}
                                  className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                                  title={t.preview}
                                >
                                  <Eye className="w-3.5 h-3.5" />
                                </button>

                                {/* Download */}
                                <button
                                  onClick={() => downloadManagedFile(item)}
                                  className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                                  title={t.download}
                                >
                                  <Download className="w-3.5 h-3.5" />
                                </button>

                                {/* Replace */}
                                <button
                                  onClick={() => setActiveReplaceItem(item)}
                                  className="px-2.5 py-1 rounded-lg bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-700 text-amber-800 dark:text-amber-300 hover:bg-amber-100 font-bold text-xs flex items-center gap-1 transition"
                                  title="Replace with new file revision (writes to DB and deletes old version)"
                                >
                                  <RefreshCw className="w-3.5 h-3.5" />
                                  <span className="hidden xl:inline">{t.replaceFile}</span>
                                </button>

                                {item.previousVersions && item.previousVersions.length > 0 && (
                                  <button
                                    onClick={() => purgeOldVersions(item.id)}
                                    className="px-2 py-1 rounded-lg bg-rose-50 dark:bg-rose-950/40 border border-rose-300 dark:border-rose-800 text-rose-700 dark:text-rose-300 hover:bg-rose-100 font-bold text-[11px] transition"
                                    title="Purge historical version backups from database"
                                  >
                                    Purge Old ({item.previousVersions.length})
                                  </button>
                                )}

                                {/* Version History */}
                                <button
                                  onClick={() => setActiveHistoryItem(item)}
                                  className="px-2.5 py-1 rounded-lg bg-purple-50 dark:bg-purple-950/40 border border-purple-300 dark:border-purple-700 text-purple-800 dark:text-purple-300 hover:bg-purple-100 font-bold text-xs flex items-center gap-1 transition"
                                  title="View version backup timeline and restore"
                                >
                                  <History className="w-3.5 h-3.5" />
                                  <span className="hidden xl:inline">History</span>
                                </button>

                                {/* Edit Metadata */}
                                <button
                                  onClick={() => setActiveEditItem(item)}
                                  className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-950/50 transition"
                                  title={t.editMetadata}
                                >
                                  <Edit2 className="w-3.5 h-3.5" />
                                </button>

                                {/* Remove */}
                                <button
                                  onClick={() => handleRemoveConfirm(item)}
                                  className="p-1.5 rounded-lg border border-red-200 dark:border-red-900/60 text-red-600 hover:bg-red-50 dark:hover:bg-red-950/50 transition"
                                  title={t.removeFile}
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* CARDS VIEW */}
          {viewMode === 'cards' && (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
              {filteredFiles.map((item) => {
                const catDef = MANAGED_CATEGORIES.find((c) => c.id === item.category);
                const catName = currentLang === 'ml' ? catDef?.titleMl : currentLang === 'ar' ? catDef?.titleAr : catDef?.titleEn;

                return (
                  <div
                    key={item.id}
                    className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-md transition flex flex-col justify-between"
                  >
                    <div>
                      {/* Top badges */}
                      <div className="flex items-center justify-between gap-2 mb-2">
                        <span className="text-xs px-2.5 py-1 rounded-lg bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-300 font-semibold flex items-center gap-1.5">
                          <span>{catDef?.emoji}</span>
                          <span>{catName}</span>
                        </span>

                        <div className="flex items-center gap-1.5">
                          <span className="px-2 py-0.5 rounded font-mono font-bold text-xs bg-purple-100 text-purple-800 dark:bg-purple-950/60 dark:text-purple-300">
                            v{item.version}
                          </span>
                          <span className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded ${
                            item.status === 'published'
                              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                              : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                          }`}>
                            {item.status === 'published' ? t.published : t.draft}
                          </span>
                        </div>
                      </div>

                      {/* Titles */}
                      <h3 className="font-bold text-slate-900 dark:text-white text-base leading-snug">
                        {item.title}
                      </h3>
                      {item.titleArabic && (
                        <p className="text-xs font-arabic font-semibold text-emerald-700 dark:text-emerald-400 mt-0.5" dir="rtl">
                          {item.titleArabic}
                        </p>
                      )}
                      {item.titleMalayalam && (
                        <p className="text-xs font-semibold text-slate-600 dark:text-slate-300 mt-0.5">
                          {item.titleMalayalam}
                        </p>
                      )}

                      <p className="text-xs text-slate-500 dark:text-slate-400 mt-2 line-clamp-2">
                        {item.description}
                      </p>

                      {/* File Metadata Card */}
                      <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800 text-[11px] font-mono text-slate-600 dark:text-slate-300 mt-3 space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="text-slate-400">File:</span>
                          <span className="truncate max-w-[180px] font-bold" title={item.fileName}>{item.fileName}</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-slate-400">Size:</span>
                          <span>{item.fileSize} ({item.fileType.toUpperCase()})</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-slate-400">Author:</span>
                          <span className="truncate max-w-[180px]">{item.author}</span>
                        </div>
                      </div>
                    </div>

                    {/* Card Actions */}
                    <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2">
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => previewManagedFile(item)}
                          className="p-2 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 text-xs font-semibold"
                          title={t.preview}
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => downloadManagedFile(item)}
                          className="p-2 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 text-xs font-semibold"
                          title={t.download}
                        >
                          <Download className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => setActiveEditItem(item)}
                          className="p-2 rounded-lg bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 hover:bg-blue-100 text-xs font-semibold"
                          title={t.editMetadata}
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                      </div>

                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => setActiveReplaceItem(item)}
                          className="px-2.5 py-1.5 rounded-lg bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-700 text-amber-800 dark:text-amber-300 hover:bg-amber-100 text-xs font-bold flex items-center gap-1"
                        >
                          <RefreshCw className="w-3.5 h-3.5" />
                          <span>Replace</span>
                        </button>

                        <button
                          onClick={() => setActiveHistoryItem(item)}
                          className="px-2.5 py-1.5 rounded-lg bg-purple-50 dark:bg-purple-950/40 border border-purple-300 dark:border-purple-700 text-purple-800 dark:text-purple-300 hover:bg-purple-100 text-xs font-bold flex items-center gap-1"
                        >
                          <History className="w-3.5 h-3.5" />
                          <span>Backup</span>
                        </button>

                        <button
                          onClick={() => handleRemoveConfirm(item)}
                          className="p-2 rounded-lg text-red-600 hover:bg-red-50 dark:hover:bg-red-950/40"
                          title={t.removeFile}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 2: DEVOTIONALS TEXT CONTENT CMS                                      */}
      {/* ========================================================================= */}
      {activeTab === 'devotionals' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              Devotional Text Manuscripts & Stanzas ({devotionals.length})
            </h2>
            <div className="text-xs text-slate-500">
              Directly connected to the public Maulid & Dhikr reader
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {devotionals.map((item) => (
              <div
                key={item.id}
                className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs px-2 py-0.5 rounded bg-emerald-100 dark:bg-emerald-900/60 text-emerald-800 dark:text-emerald-300 font-semibold uppercase">
                      {item.type}
                    </span>
                    <span className="text-xs font-mono text-slate-400">
                      {item.targetCount ? `${item.targetCount}x recitation` : 'Heritage Diwan'}
                    </span>
                  </div>
                  <h3 className="font-bold text-slate-900 dark:text-white text-base">
                    {item.title}
                  </h3>
                  <p className="text-xs font-arabic font-semibold text-emerald-700 dark:text-emerald-400 mt-0.5" dir="rtl">
                    {item.arabicTitle}
                  </p>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 line-clamp-2">
                    {item.description}
                  </p>
                </div>

                <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
                  <span className="text-slate-400">By {item.author || 'Traditional'}</span>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => previewManagedFile({
                        id: item.id,
                        title: item.title,
                        category: 'maulid-pdf',
                        language: 'ar',
                        author: item.author || '',
                        storagePath: item.pdfUrl || 'https://archive.org/download/ManqoosMawlid/Manqoos%20Mawlid.pdf',
                        fileName: `${item.title.toLowerCase().replace(/\s+/g, '-')}.pdf`,
                        fileType: 'pdf',
                        mimeType: 'application/pdf',
                        fileSize: '3.4 MB',
                        version: 1,
                        uploadedBy: 'Admin',
                        uploadDate: '2026-08-12',
                        updatedDate: '2026-08-12',
                        status: 'published',
                        publicVisibility: true,
                        previousVersions: [],
                        description: item.description,
                      })}
                      className="px-2.5 py-1 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 font-semibold text-xs flex items-center gap-1"
                    >
                      <Eye className="w-3 h-3" />
                      <span>PDF</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 3: ARTICLES & RESEARCH CMS                                           */}
      {/* ========================================================================= */}
      {activeTab === 'articles' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              Scholarly Articles & Research Treatises ({articles.length})
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {articles.map((item) => (
              <div
                key={item.id}
                className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm"
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs px-2 py-0.5 rounded bg-blue-100 dark:bg-blue-900/60 text-blue-800 dark:text-blue-300 font-semibold">
                    {item.category}
                  </span>
                  <span className="text-xs text-slate-400">{item.readingTimeMinutes} min read</span>
                </div>
                <h3 className="font-bold text-slate-900 dark:text-white text-base">
                  {item.title}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 line-clamp-2">
                  {item.summary}
                </p>
                <div className="mt-3 text-xs text-slate-400">
                  By {item.author} · Published {item.publishDate}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 4: AUDIT LOGS                                                        */}
      {/* ========================================================================= */}
      {activeTab === 'audit' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              Audit Trail & Immutable Activity Log
            </h2>
          </div>

          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
            <table className="w-full text-left text-xs text-slate-700 dark:text-slate-300">
              <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-500 dark:text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="px-4 py-3">Timestamp</th>
                  <th className="px-4 py-3">Administrator</th>
                  <th className="px-4 py-3">Action</th>
                  <th className="px-4 py-3">Entity & Title</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {auditLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                    <td className="px-4 py-3 font-mono text-slate-500 dark:text-slate-400">
                      {log.timestamp}
                    </td>
                    <td className="px-4 py-3 font-medium text-slate-900 dark:text-white">
                      {log.adminName}
                    </td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                        log.action === 'Created' || log.action === 'Published'
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                          : log.action === 'Deleted'
                          ? 'bg-red-100 text-red-800 dark:bg-red-950 dark:text-red-300'
                          : 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300'
                      }`}>
                        {log.action}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span className="font-semibold text-slate-800 dark:text-slate-200">{log.entity}: </span>
                      <span className="text-slate-600 dark:text-slate-300">{log.entityTitle}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* INTERACTIVE MODALS                                                       */}
      {/* ========================================================================= */}
      {/* 1. Upload New File Modal */}
      <FileUploadModal
        isOpen={isUploadModalOpen}
        onClose={() => setIsUploadModalOpen(false)}
        onUpload={uploadNewFile}
        currentLang={currentLang}
      />

      {/* 2. File Replace Modal */}
      <FileReplaceModal
        isOpen={!!activeReplaceItem}
        fileItem={activeReplaceItem}
        onClose={() => setActiveReplaceItem(null)}
        onReplace={replaceFile}
        currentLang={currentLang}
      />

      {/* 3. Version History & Restore Modal */}
      <VersionHistoryModal
        isOpen={!!activeHistoryItem}
        fileItem={activeHistoryItem}
        onClose={() => setActiveHistoryItem(null)}
        onRestore={restoreFileVersion}
        onPreview={previewManagedFile}
        onDownload={downloadManagedFile}
        currentLang={currentLang}
      />

      {/* 4. Metadata Edit Modal */}
      <MetadataEditModal
        isOpen={!!activeEditItem}
        fileItem={activeEditItem}
        onClose={() => setActiveEditItem(null)}
        onSave={updateFileMetadata}
        currentLang={currentLang}
      />
    </div>
  );
};
