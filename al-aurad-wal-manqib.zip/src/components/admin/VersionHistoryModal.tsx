import React from 'react';
import { X, History, RotateCcw, Download, Eye, CheckCircle2, FileText, Calendar, User } from 'lucide-react';
import { ManagedFileItem, FileVersion } from '../../types/storage';
import { SupportedLanguage, getTranslation } from '../../i18n/translations';

interface Props {
  isOpen: boolean;
  fileItem: ManagedFileItem | null;
  onClose: () => void;
  onRestore: (fileId: string, versionNumber: number) => void;
  onPreview: (fileItem: ManagedFileItem) => void;
  onDownload: (fileItem: ManagedFileItem) => void;
  currentLang: SupportedLanguage;
}

export const VersionHistoryModal: React.FC<Props> = ({
  isOpen,
  fileItem,
  onClose,
  onRestore,
  onPreview,
  onDownload,
  currentLang,
}) => {
  const t = getTranslation(currentLang);

  if (!isOpen || !fileItem) return null;

  const handleRestore = (versionNumber: number) => {
    const confirmMsg =
      currentLang === 'ml'
        ? `ഈ പഴയ വേർഷൻ (v${versionNumber}) തിരികെ സജീവമാക്കാൻ ആഗ്രഹിക്കുന്നുണ്ടോ? നിലവിലെ വേർഷൻ ബാക്കപ്പിലേക്ക് മാറും.`
        : currentLang === 'ar'
        ? `هل تود استرجاع الإصدار السابق (v${versionNumber}) وجعله هو الملف النشط؟`
        : `Are you sure you want to restore Version ${versionNumber}? The current version will be archived to history.`;

    if (window.confirm(confirmMsg)) {
      onRestore(fileItem.id, versionNumber);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 rounded-2xl w-full max-w-2xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/90">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-purple-100 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300">
              <History className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                {t.versionHistory}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {fileItem.title} · Active: v{fileItem.version}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6 max-h-[70vh] overflow-y-auto text-sm">
          {/* Active Version Display */}
          <div>
            <div className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">
              {currentLang === 'ml' ? 'സജീവ വേർഷൻ (Current Active Version)' : currentLang === 'ar' ? 'الإصدار الحالي والنشط' : 'Current Active Version'}
            </div>
            <div className="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-300 dark:border-emerald-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-bold bg-emerald-600 text-white shadow-sm">
                    v{fileItem.version} (Active)
                  </span>
                  <span className="font-semibold text-slate-900 dark:text-white">
                    {fileItem.fileName}
                  </span>
                  <span className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded ${
                    fileItem.status === 'published'
                      ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/60 dark:text-emerald-300'
                      : 'bg-amber-100 text-amber-800 dark:bg-amber-900/60 dark:text-amber-300'
                  }`}>
                    {fileItem.status === 'published' ? t.published : t.draft}
                  </span>
                </div>
                <div className="flex flex-wrap items-center gap-3 text-xs text-slate-600 dark:text-slate-300 mt-2 font-mono">
                  <span>Size: {fileItem.fileSize}</span>
                  <span>•</span>
                  <span>Updated: {fileItem.updatedDate}</span>
                  <span>•</span>
                  <span>By: {fileItem.uploadedBy}</span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => onPreview(fileItem)}
                  className="px-3 py-1.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 hover:bg-slate-50 text-xs font-semibold flex items-center gap-1.5 text-slate-700 dark:text-slate-200 transition"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>{t.preview}</span>
                </button>
                <button
                  onClick={() => onDownload(fileItem)}
                  className="px-3 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold flex items-center gap-1.5 transition"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>{t.download}</span>
                </button>
              </div>
            </div>
          </div>

          {/* Chronological Previous Version Backups */}
          <div>
            <div className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">
              {currentLang === 'ml'
                ? `ബാക്കപ്പ് ചെയ്ത പഴയ വേർഷനുകൾ (${fileItem.previousVersions.length})`
                : currentLang === 'ar'
                ? `النسخ الاحتياطية المؤرشفة (${fileItem.previousVersions.length})`
                : `Archived Previous Versions (${fileItem.previousVersions.length})`}
            </div>

            {fileItem.previousVersions.length === 0 ? (
              <div className="p-8 text-center rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400">
                <History className="w-8 h-8 mx-auto mb-2 opacity-40 text-slate-400" />
                <p className="font-medium text-xs">
                  {currentLang === 'ml'
                    ? 'ഇതുവരെ പഴയ വേർഷനുകളൊന്നും രേഖപ്പെടുത്തിയിട്ടില്ല. ഫയൽ റീപ്ലേസ് ചെയ്യുമ്പോൾ മുൻ വേർഷനുകൾ ഇവിടെ സൂക്ഷിക്കപ്പെടും.'
                    : currentLang === 'ar'
                    ? 'لا توجد نسخ سابقة حتى الآن. عند استبدال الملف، ستظهر النسخ السابقة هنا تلقائياً.'
                    : 'No previous versions recorded yet. When you replace the file, old versions will automatically appear here.'}
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {fileItem.previousVersions.map((version) => (
                  <div
                    key={version.versionNumber}
                    className="p-4 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-purple-400/50 dark:hover:border-purple-500/40 transition shadow-sm"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-bold bg-purple-100 text-purple-800 dark:bg-purple-900/60 dark:text-purple-300">
                            v{version.versionNumber} (Backup)
                          </span>
                          <span className="font-semibold text-slate-900 dark:text-white">
                            {version.fileName}
                          </span>
                        </div>

                        {version.changeNote && (
                          <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 italic">
                            "{version.changeNote}"
                          </p>
                        )}

                        <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500 dark:text-slate-400 mt-2 font-mono">
                          <span>Size: {version.fileSize}</span>
                          <span>•</span>
                          <span>Archived: {version.updatedDate}</span>
                          <span>•</span>
                          <span>By: {version.uploadedBy}</span>
                        </div>
                      </div>

                      {/* Restore & Download Actions */}
                      <div className="flex items-center gap-2">
                        {/* Direct Download of Backup */}
                        <a
                          href={version.storagePath}
                          download={version.fileName}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 text-xs font-medium flex items-center gap-1 transition"
                          title="Download this backup file"
                        >
                          <Download className="w-3.5 h-3.5" />
                        </a>

                        {/* Restore Button */}
                        <button
                          onClick={() => handleRestore(version.versionNumber)}
                          className="px-3.5 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-sm transition"
                        >
                          <RotateCcw className="w-3.5 h-3.5" />
                          <span>{t.restoreVersion}</span>
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-slate-50 dark:bg-slate-900/80 border-t border-slate-200 dark:border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-bold transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
