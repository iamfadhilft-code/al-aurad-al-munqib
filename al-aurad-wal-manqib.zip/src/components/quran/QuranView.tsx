import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  BookOpen,
  Play,
  Pause,
  Bookmark,
  Share2,
  Copy,
  Info,
  Settings2,
  Search,
  CheckCircle,
  Eye,
  EyeOff,
  Volume2,
  Sparkles,
  ChevronLeft,
  ChevronRight,
  Maximize2,
  Minimize2,
} from 'lucide-react';
import { Ayah, Surah } from '../../types';

export const QuranView: React.FC = () => {
  const {
    surahs,
    selectedSurahNumber,
    setSelectedSurahNumber,
    quranSettings,
    updateQuranSettings,
    playAudioTrack,
    isPlaying,
    activeAudioTrack,
    toggleBookmark,
    isBookmarked,
    addNote,
    showToast,
  } = useApp();

  const [surahSearch, setSurahSearch] = useState('');
  const [selectedTafsirAyah, setSelectedTafsirAyah] = useState<Ayah | null>(null);
  const [hifzRevealedVerses, setHifzRevealedVerses] = useState<Record<number, boolean>>({});
  const [noteModalAyah, setNoteModalAyah] = useState<Ayah | null>(null);
  const [noteContent, setNoteContent] = useState('');
  const [mobileSurahMenuOpen, setMobileSurahMenuOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);

  const currentSurah: Surah = surahs.find((s) => s.number === selectedSurahNumber) || surahs[0];

  const filteredSurahs = surahs.filter(
    (s) =>
      s.nameEnglish.toLowerCase().includes(surahSearch.toLowerCase()) ||
      s.nameTranslation.toLowerCase().includes(surahSearch.toLowerCase()) ||
      s.nameArabic.includes(surahSearch) ||
      String(s.number).includes(surahSearch)
  );

  const handlePlayAyah = (ayah: Ayah) => {
    playAudioTrack({
      id: `quran-${currentSurah.number}-${ayah.number}`,
      title: `Surah ${currentSurah.nameEnglish} · Ayah ${ayah.number}`,
      subtitle: `${quranSettings.reciter} · ${currentSurah.nameTranslation}`,
      arabicTitle: currentSurah.nameArabic,
      audioUrl: ayah.audioUrl || `https://everyayah.com/data/Alafasy_128kbps/${String(currentSurah.number).padStart(3, '0')}${String(ayah.number).padStart(3, '0')}.mp3`,
      category: "Qur'an",
    });
  };

  const handleCopyAyah = (ayah: Ayah) => {
    navigator.clipboard.writeText(
      `${ayah.arabic}\n\n"${ayah.translation}"\n[Surah ${currentSurah.nameEnglish} ${currentSurah.number}:${ayah.number}]`
    );
    showToast(`Ayah ${ayah.number} copied`, 'success');
  };

  const handleSaveNote = () => {
    if (!noteModalAyah || !noteContent.trim()) return;
    addNote({
      title: `Reflection on Surah ${currentSurah.nameEnglish} Verse ${noteModalAyah.number}`,
      surahOrTopic: `${currentSurah.nameEnglish} ${currentSurah.number}:${noteModalAyah.number}`,
      content: noteContent,
    });
    setNoteModalAyah(null);
    setNoteContent('');
  };

  const toggleHifzReveal = (num: number) => {
    setHifzRevealedVerses((prev) => ({ ...prev, [num]: !prev[num] }));
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Top Header & Settings bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-emerald-800/50">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setMobileSurahMenuOpen(true)}
            className="lg:hidden p-2 rounded-lg bg-emerald-100 dark:bg-emerald-900/60 text-emerald-800 dark:text-emerald-200 text-xs font-semibold flex items-center gap-1.5"
          >
            <BookOpen className="w-4 h-4" />
            <span>Surahs</span>
          </button>

          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-bold font-serif text-slate-900 dark:text-white">
                Surah {currentSurah.nameEnglish}
              </h1>
              <span className="font-arabic text-xl font-bold text-emerald-800 dark:text-amber-400">
                ({currentSurah.nameArabic})
              </span>
              <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-900/60 text-emerald-900 dark:text-emerald-300 font-semibold">
                {currentSurah.revelationType}
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {currentSurah.nameTranslation} · {currentSurah.ayahCount} Ayahs
            </p>
          </div>
        </div>

        {/* Action Controls & Mode toggles */}
        <div className="flex items-center gap-2">
          {/* Hifz Mode Toggle */}
          <button
            onClick={() => updateQuranSettings({ hifzMode: !quranSettings.hifzMode })}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition border ${
              quranSettings.hifzMode
                ? 'bg-amber-400 text-slate-950 border-amber-300 shadow-sm'
                : 'bg-white dark:bg-emerald-950 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-emerald-800 hover:bg-slate-50'
            }`}
            title="Toggle Memorization / Hifz mode (Hide/show verses for testing)"
          >
            {quranSettings.hifzMode ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
            <span>Hifz Mode {quranSettings.hifzMode ? 'ON' : 'OFF'}</span>
          </button>

          {/* Focus Mode Toggle */}
          <button
            onClick={() => updateQuranSettings({ focusMode: !quranSettings.focusMode })}
            className={`p-2 rounded-lg border transition ${
              quranSettings.focusMode
                ? 'bg-emerald-800 text-white border-emerald-700'
                : 'bg-white dark:bg-emerald-950 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-emerald-800 hover:bg-slate-50'
            }`}
            title="Toggle Distraction-free Focus Mode"
          >
            {quranSettings.focusMode ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>

          {/* Reader Settings Toggle */}
          <button
            onClick={() => setSettingsOpen(!settingsOpen)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold border transition ${
              settingsOpen
                ? 'bg-emerald-800 text-white border-emerald-700'
                : 'bg-white dark:bg-emerald-950 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-emerald-800 hover:bg-slate-50'
            }`}
          >
            <Settings2 className="w-3.5 h-3.5" />
            <span>Reading Settings</span>
          </button>
        </div>
      </div>

      {/* Expandable Settings Bar */}
      {settingsOpen && (
        <div className="bg-white dark:bg-emerald-950 rounded-xl p-4 my-4 border border-slate-200 dark:border-emerald-800 shadow-lg animate-in slide-in-from-top-2 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-200 mb-1">
              Arabic Font Size: {quranSettings.arabicFontSize}px
            </label>
            <input
              type="range"
              min="20"
              max="44"
              value={quranSettings.arabicFontSize}
              onChange={(e) => updateQuranSettings({ arabicFontSize: Number(e.target.value) })}
              className="w-full accent-emerald-700"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-200 mb-1">
              Translation Size: {quranSettings.translationFontSize}px
            </label>
            <input
              type="range"
              min="12"
              max="24"
              value={quranSettings.translationFontSize}
              onChange={(e) => updateQuranSettings({ translationFontSize: Number(e.target.value) })}
              className="w-full accent-emerald-700"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-200 mb-1">Reciter</label>
            <select
              value={quranSettings.reciter}
              onChange={(e) => updateQuranSettings({ reciter: e.target.value })}
              className="w-full px-2.5 py-1.5 rounded-lg bg-slate-50 dark:bg-emerald-900 border border-slate-200 dark:border-emerald-700 text-slate-800 dark:text-slate-100"
            >
              <option value="Mishary Rashid Alafasy">Mishary Rashid Alafasy</option>
              <option value="Abdul Rahman Al-Sudais">Abdul Rahman Al-Sudais</option>
              <option value="Maher Al-Muaiqly">Maher Al-Muaiqly</option>
              <option value="Abu Bakr Al-Shatri">Abu Bakr Al-Shatri</option>
            </select>
          </div>

          <div className="flex flex-col justify-center gap-2">
            <label className="flex items-center gap-2 text-slate-700 dark:text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={quranSettings.showTranslation}
                onChange={(e) => updateQuranSettings({ showTranslation: e.target.checked })}
                className="accent-emerald-700"
              />
              <span>Show English Translation</span>
            </label>
            <label className="flex items-center gap-2 text-slate-700 dark:text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={quranSettings.showTransliteration}
                onChange={(e) => updateQuranSettings({ showTransliteration: e.target.checked })}
                className="accent-emerald-700"
              />
              <span>Show Transliteration</span>
            </label>
          </div>
        </div>
      )}

      {/* Main Reader Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 mt-6 items-start">
        {/* Left Sidebar: Surah Selector List (Hidden in Focus Mode) */}
        {!quranSettings.focusMode && (
          <aside className="hidden lg:block lg:col-span-3 bg-white dark:bg-emerald-950/40 rounded-2xl p-4 border border-slate-200/80 dark:border-emerald-800/40 shadow-sm sticky top-24 max-h-[80vh] flex flex-col">
            <div className="relative mb-3">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Find Surah..."
                value={surahSearch}
                onChange={(e) => setSurahSearch(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 dark:bg-emerald-900/40 rounded-lg border border-slate-200 dark:border-emerald-800 text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none"
              />
            </div>

            <div className="overflow-y-auto space-y-1 pr-1 flex-1">
              {filteredSurahs.map((s) => {
                const isCurrent = s.number === currentSurah.number;
                return (
                  <button
                    key={s.number}
                    onClick={() => {
                      setSelectedSurahNumber(s.number);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className={`w-full flex items-center justify-between p-2.5 rounded-xl text-left transition ${
                      isCurrent
                        ? 'bg-emerald-800 text-white font-semibold shadow-sm'
                        : 'text-slate-700 dark:text-slate-300 hover:bg-emerald-50 dark:hover:bg-emerald-900/40'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <span
                        className={`w-6 h-6 rounded-md flex items-center justify-center text-[10px] font-mono ${
                          isCurrent ? 'bg-amber-400 text-slate-950 font-bold' : 'bg-slate-100 dark:bg-emerald-900 text-slate-600 dark:text-slate-300'
                        }`}
                      >
                        {s.number}
                      </span>
                      <div className="truncate">
                        <span className="block text-xs truncate leading-tight">{s.nameEnglish}</span>
                        <span className={`text-[10px] truncate block ${isCurrent ? 'text-emerald-200' : 'text-slate-400'}`}>
                          {s.ayahCount} Ayahs
                        </span>
                      </div>
                    </div>
                    <span className="font-arabic text-sm font-bold">{s.nameArabic}</span>
                  </button>
                );
              })}
            </div>
          </aside>
        )}

        {/* Center: Ayahs Content Stream */}
        <main className={`${quranSettings.focusMode ? 'lg:col-span-12 max-w-4xl mx-auto' : 'lg:col-span-9'} space-y-4`}>
          {/* Surah Bismillah Banner (except Surah At-Tawbah) */}
          {currentSurah.number !== 9 && (
            <div className="text-center py-6 px-4 bg-gradient-to-b from-emerald-50/50 to-transparent dark:from-emerald-900/20 rounded-2xl border border-emerald-100 dark:border-emerald-800/30">
              <p className="font-arabic text-2xl sm:text-3xl font-bold text-emerald-900 dark:text-amber-300 tracking-wide">
                بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ
              </p>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-2 font-light">
                In the name of Allah, the Entirely Merciful, the Especially Merciful.
              </p>
            </div>
          )}

          {/* Ayahs Cards */}
          <div className="space-y-4">
            {currentSurah.ayahs.map((ayah) => {
              const ayahAudioId = `quran-${currentSurah.number}-${ayah.number}`;
              const isVersePlaying = activeAudioTrack?.id === ayahAudioId && isPlaying;
              const isVerseBookmarked = isBookmarked(ayahAudioId);
              const isHifzHidden = quranSettings.hifzMode && !hifzRevealedVerses[ayah.number];

              return (
                <div
                  key={ayah.number}
                  id={`ayah-${ayah.number}`}
                  className={`p-6 rounded-2xl border transition-all duration-300 ${
                    isVersePlaying
                      ? 'bg-emerald-50/80 dark:bg-emerald-900/40 border-emerald-500 shadow-md ring-1 ring-emerald-500/50'
                      : 'bg-white dark:bg-emerald-950/40 border-slate-200/80 dark:border-emerald-800/40 shadow-sm hover:border-emerald-300'
                  }`}
                >
                  {/* Ayah Top Bar: Verse Number & Action Buttons */}
                  <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-100 dark:border-emerald-900/40 text-xs">
                    <div className="flex items-center gap-2">
                      <span className="w-8 h-8 rounded-lg bg-emerald-100 dark:bg-emerald-900/80 text-emerald-900 dark:text-amber-300 font-mono font-bold flex items-center justify-center text-xs border border-emerald-200 dark:border-emerald-700">
                        {currentSurah.number}:{ayah.number}
                      </span>

                      <button
                        onClick={() => handlePlayAyah(ayah)}
                        className={`flex items-center gap-1 px-3 py-1 rounded-lg transition font-medium text-xs ${
                          isVersePlaying
                            ? 'bg-amber-400 text-slate-950 font-bold'
                            : 'bg-slate-100 dark:bg-emerald-900/60 text-slate-700 dark:text-emerald-200 hover:bg-slate-200'
                        }`}
                      >
                        {isVersePlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 fill-current" />}
                        <span>{isVersePlaying ? 'Playing' : 'Listen'}</span>
                      </button>
                    </div>

                    <div className="flex items-center gap-1">
                      {ayah.tafsir && (
                        <button
                          onClick={() => setSelectedTafsirAyah(ayah)}
                          className="flex items-center gap-1 px-2.5 py-1 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-emerald-900/60 transition"
                          title="Read Tafsir explanation"
                        >
                          <Info className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                          <span className="hidden sm:inline">Tafsir</span>
                        </button>
                      )}

                      <button
                        onClick={() => setNoteModalAyah(ayah)}
                        className="px-2.5 py-1 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-emerald-900/60 transition"
                        title="Add reflection note"
                      >
                        Note
                      </button>

                      <button
                        onClick={() =>
                          toggleBookmark({
                            id: ayahAudioId,
                            type: 'quran',
                            title: `Surah ${currentSurah.nameEnglish} · Verse ${ayah.number}`,
                            subtitle: ayah.translation.substring(0, 45) + '...',
                            pathOrRef: `Surah ${currentSurah.number}`,
                          })
                        }
                        className={`p-1.5 rounded-lg border transition ${
                          isVerseBookmarked
                            ? 'bg-amber-400 text-slate-950 border-amber-300'
                            : 'text-slate-400 hover:text-slate-600 border-transparent hover:border-slate-200'
                        }`}
                        title="Bookmark verse"
                      >
                        <Bookmark className={`w-3.5 h-3.5 ${isVerseBookmarked ? 'fill-current' : ''}`} />
                      </button>

                      <button
                        onClick={() => handleCopyAyah(ayah)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition"
                        title="Copy Ayah text"
                      >
                        <Copy className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Arabic Text Display */}
                  <div className="text-right my-4">
                    {isHifzHidden ? (
                      <div
                        onClick={() => toggleHifzReveal(ayah.number)}
                        className="py-6 px-4 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-dashed border-amber-300 dark:border-amber-700/50 text-center cursor-pointer hover:bg-amber-100/50 transition group"
                      >
                        <span className="text-xs font-semibold text-amber-800 dark:text-amber-300 flex items-center justify-center gap-1.5">
                          <Eye className="w-4 h-4" />
                          <span>Verse hidden for Hifz practice. Click to reveal and verify.</span>
                        </span>
                      </div>
                    ) : (
                      <p
                        style={{ fontSize: `${quranSettings.arabicFontSize}px` }}
                        className="font-arabic leading-[2.3] text-emerald-950 dark:text-emerald-50 select-text"
                        dir="rtl"
                      >
                        {ayah.arabic}
                        <span className="inline-flex items-center justify-center w-7 h-7 mx-2 rounded-full border border-amber-500/60 text-xs font-mono font-bold text-amber-600 dark:text-amber-400 align-middle">
                          {ayah.number}
                        </span>
                      </p>
                    )}
                  </div>

                  {/* Transliteration */}
                  {quranSettings.showTransliteration && (
                    <p className="text-xs text-emerald-700 dark:text-amber-400 font-mono tracking-wide pt-2 border-t border-slate-100 dark:border-emerald-900/30">
                      {ayah.transliteration}
                    </p>
                  )}

                  {/* English Translation */}
                  {quranSettings.showTranslation && (
                    <p
                      style={{ fontSize: `${quranSettings.translationFontSize}px` }}
                      className="text-slate-700 dark:text-slate-200 leading-relaxed font-light mt-1.5"
                    >
                      {ayah.translation}
                    </p>
                  )}
                </div>
              );
            })}
          </div>

          {/* Surah Navigation Buttons */}
          <div className="flex items-center justify-between pt-6 border-t border-slate-200 dark:border-emerald-800/40">
            <button
              onClick={() => {
                const prev = surahs.find((s) => s.number === currentSurah.number - 1);
                if (prev) {
                  setSelectedSurahNumber(prev.number);
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }
              }}
              disabled={currentSurah.number === 1}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-white dark:bg-emerald-950 border border-slate-200 dark:border-emerald-800 text-xs font-semibold text-slate-700 dark:text-slate-200 disabled:opacity-40 disabled:pointer-events-none"
            >
              <ChevronLeft className="w-4 h-4" /> Previous Surah
            </button>

            <span className="text-xs text-slate-500 dark:text-slate-400 font-mono">
              Surah {currentSurah.number} of 114
            </span>

            <button
              onClick={() => {
                const next = surahs.find((s) => s.number === currentSurah.number + 1);
                if (next) {
                  setSelectedSurahNumber(next.number);
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }
              }}
              disabled={currentSurah.number === 114}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-white dark:bg-emerald-950 border border-slate-200 dark:border-emerald-800 text-xs font-semibold text-slate-700 dark:text-slate-200 disabled:opacity-40 disabled:pointer-events-none"
            >
              Next Surah <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </main>
      </div>

      {/* Tafsir Modal */}
      {selectedTafsirAyah && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-xl bg-white dark:bg-emerald-950 rounded-2xl shadow-2xl border border-slate-200 dark:border-emerald-800 p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-emerald-900">
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  Tafsir Insight · Ayah {selectedTafsirAyah.number}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Surah {currentSurah.nameEnglish} ({currentSurah.number}:{selectedTafsirAyah.number})
                </p>
              </div>
              <button
                onClick={() => setSelectedTafsirAyah(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="p-3 bg-emerald-50 dark:bg-emerald-900/30 rounded-xl text-right">
              <p className="font-arabic text-lg text-emerald-950 dark:text-emerald-100" dir="rtl">
                {selectedTafsirAyah.arabic}
              </p>
            </div>

            <div className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed space-y-2">
              <p className="font-semibold text-emerald-800 dark:text-amber-300">
                Scholarly Exegesis & Linguistic Meaning:
              </p>
              <p>{selectedTafsirAyah.tafsir}</p>
            </div>

            <div className="pt-2 text-right">
              <button
                onClick={() => setSelectedTafsirAyah(null)}
                className="px-4 py-2 rounded-xl bg-emerald-800 text-white text-xs font-semibold"
              >
                Close Tafsir
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Note Modal */}
      {noteModalAyah && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-lg bg-white dark:bg-emerald-950 rounded-2xl shadow-2xl border border-slate-200 dark:border-emerald-800 p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-emerald-900">
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                Add Reflection Note ({currentSurah.nameEnglish} {currentSurah.number}:{noteModalAyah.number})
              </h3>
              <button onClick={() => setNoteModalAyah(null)} className="p-1 text-slate-400">
                ✕
              </button>
            </div>

            <textarea
              rows={4}
              placeholder="Record your personal reflections, questions, or lessons derived from this verse..."
              value={noteContent}
              onChange={(e) => setNoteContent(e.target.value)}
              className="w-full p-3 text-xs bg-slate-50 dark:bg-emerald-900/40 rounded-xl border border-slate-200 dark:border-emerald-800 text-slate-800 dark:text-slate-100 focus:outline-none"
            />

            <div className="flex justify-end gap-2">
              <button
                onClick={() => setNoteModalAyah(null)}
                className="px-3 py-1.5 rounded-lg border text-xs text-slate-600 dark:text-slate-300"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveNote}
                className="px-4 py-1.5 rounded-lg bg-emerald-800 text-white text-xs font-semibold"
              >
                Save Note
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Mobile Surah Menu Drawer */}
      {mobileSurahMenuOpen && (
        <div className="fixed inset-0 z-50 flex bg-slate-950/70 backdrop-blur-sm">
          <div className="w-4/5 max-w-xs bg-white dark:bg-emerald-950 h-full p-4 flex flex-col">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-emerald-800">
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">Select Surah</h3>
              <button onClick={() => setMobileSurahMenuOpen(false)} className="p-1 text-slate-400">
                ✕
              </button>
            </div>
            <div className="my-2">
              <input
                type="text"
                placeholder="Search Surah..."
                value={surahSearch}
                onChange={(e) => setSurahSearch(e.target.value)}
                className="w-full px-3 py-1.5 text-xs rounded-lg bg-slate-100 dark:bg-emerald-900 border border-slate-200 dark:border-emerald-700"
              />
            </div>
            <div className="overflow-y-auto flex-1 space-y-1">
              {filteredSurahs.map((s) => (
                <button
                  key={s.number}
                  onClick={() => {
                    setSelectedSurahNumber(s.number);
                    setMobileSurahMenuOpen(false);
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className={`w-full flex items-center justify-between p-2 rounded-lg text-xs ${
                    s.number === currentSurah.number
                      ? 'bg-emerald-800 text-white font-bold'
                      : 'text-slate-700 dark:text-slate-200 hover:bg-slate-100'
                  }`}
                >
                  <span>
                    {s.number}. {s.nameEnglish}
                  </span>
                  <span className="font-arabic">{s.nameArabic}</span>
                </button>
              ))}
            </div>
          </div>
          <div className="flex-1" onClick={() => setMobileSurahMenuOpen(false)}></div>
        </div>
      )}
    </div>
  );
};
