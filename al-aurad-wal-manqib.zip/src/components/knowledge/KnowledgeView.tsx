import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Article } from '../../types';
import { BookOpen, Clock, Search, Bookmark, ArrowRight, Share2, Tag } from 'lucide-react';

export const KnowledgeView: React.FC = () => {
  const { articles, toggleBookmark, isBookmarked, showToast } = useApp();
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [readingArticle, setReadingArticle] = useState<Article | null>(null);

  const categories = [
    { id: 'all', label: 'All Articles' },
    { id: 'Spirituality & Tasawwuf', label: 'Spirituality & Tasawwuf' },
    { id: 'Qur’anic Sciences', label: 'Qur’anic Sciences' },
    { id: 'Prophetic Biography', label: 'Prophetic Biography' },
    { id: 'Daily Jurisprudence', label: 'Daily Jurisprudence' },
  ];

  const filteredArticles = articles.filter((art) => {
    if (art.status !== 'published') return false;
    const matchesCat = selectedCategory === 'all' || art.category === selectedCategory;
    const matchesSearch =
      art.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      art.summary.toLowerCase().includes(searchQuery.toLowerCase()) ||
      art.author.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-emerald-900 to-teal-950 text-white rounded-2xl p-6 sm:p-8 border border-emerald-800 shadow-xl space-y-2">
        <div className="flex items-center gap-1.5 text-amber-400 text-xs font-bold font-cinzel uppercase tracking-wider">
          <BookOpen className="w-4 h-4" />
          <span>Knowledge & Reflections</span>
        </div>
        <h1 className="text-2xl sm:text-4xl font-serif font-bold text-white">
          Scholarly Essays & Spiritual Insights
        </h1>
        <p className="text-xs sm:text-sm text-emerald-100/90 leading-relaxed max-w-2xl font-light">
          Deep, contemplative articles authored by traditional scholars exploring prophetic character, inner spiritual purification, classical theology, and contemporary reflections.
        </p>
      </div>

      {/* Category Filter & Search */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 text-xs">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition font-medium ${
                selectedCategory === cat.id
                  ? 'bg-emerald-800 text-white shadow-sm'
                  : 'bg-white dark:bg-emerald-950 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-emerald-800 hover:bg-slate-50'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search articles..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-white dark:bg-emerald-950 rounded-xl border border-slate-200 dark:border-emerald-800 text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none"
          />
        </div>
      </div>

      {/* Articles Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {filteredArticles.map((art) => {
          const bookmarked = isBookmarked(art.id);
          return (
            <div
              key={art.id}
              className="bg-white dark:bg-emerald-950/40 rounded-2xl border border-slate-200/80 dark:border-emerald-800/40 shadow-sm hover:shadow-xl transition-all duration-300 overflow-hidden flex flex-col justify-between group"
            >
              {art.coverImage && (
                <div className="h-44 w-full overflow-hidden relative">
                  <img
                    src={art.coverImage}
                    alt={art.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                  />
                  <span className="absolute top-3 left-3 text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-slate-950/80 text-amber-300 backdrop-blur-sm">
                    {art.category}
                  </span>
                </div>
              )}

              <div className="p-6 flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between text-xs text-slate-400 dark:text-emerald-400/70 mb-2">
                    <span className="truncate">{art.author}</span>
                    <span className="flex items-center gap-1 shrink-0">
                      <Clock className="w-3 h-3" /> {art.readingTimeMinutes}m read
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-slate-900 dark:text-white group-hover:text-emerald-800 dark:group-hover:text-amber-300 transition line-clamp-2">
                    {art.title}
                  </h3>

                  <p className="text-xs text-slate-600 dark:text-slate-300 mt-2 line-clamp-3 leading-relaxed">
                    {art.summary}
                  </p>
                </div>

                <div className="pt-4 mt-4 border-t border-slate-100 dark:border-emerald-900/40 flex items-center justify-between text-xs">
                  <button
                    onClick={() =>
                      toggleBookmark({
                        id: art.id,
                        type: 'article',
                        title: art.title,
                        subtitle: art.author,
                        pathOrRef: art.category,
                      })
                    }
                    className="text-slate-400 hover:text-amber-500"
                  >
                    <Bookmark className={`w-4 h-4 ${bookmarked ? 'fill-amber-400 text-amber-400' : ''}`} />
                  </button>

                  <button
                    onClick={() => setReadingArticle(art)}
                    className="font-bold text-emerald-800 dark:text-amber-300 hover:underline flex items-center gap-1"
                  >
                    <span>Read Essay</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Full Article Reader Modal */}
      {readingArticle && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in">
          <div className="w-full max-w-3xl max-h-[90vh] bg-white dark:bg-emerald-950 rounded-2xl shadow-2xl border border-slate-200 dark:border-emerald-800 flex flex-col overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 bg-emerald-900 text-white">
              <div>
                <span className="text-[10px] uppercase tracking-wider text-amber-300 font-cinzel font-bold block">
                  {readingArticle.category}
                </span>
                <h2 className="text-lg font-bold font-serif">{readingArticle.title}</h2>
              </div>
              <button
                onClick={() => setReadingArticle(null)}
                className="p-1 rounded-lg hover:bg-emerald-800 text-emerald-200"
              >
                ✕
              </button>
            </div>

            <div className="p-6 sm:p-10 overflow-y-auto space-y-6 text-slate-800 dark:text-slate-200 text-sm leading-relaxed">
              <div className="flex items-center gap-3 text-xs text-slate-400 pb-3 border-b border-slate-100 dark:border-emerald-900">
                <span>By {readingArticle.author}</span>
                <span>·</span>
                <span>{readingArticle.readingTimeMinutes} min read</span>
                <span>·</span>
                <span>Published: {readingArticle.publishDate}</span>
              </div>

              <div className="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-900/30 border border-emerald-200 dark:border-emerald-800 font-serif italic text-emerald-900 dark:text-emerald-100">
                "{readingArticle.summary}"
              </div>

              <div className="space-y-4">
                {(Array.isArray(readingArticle.content)
                  ? readingArticle.content
                  : [readingArticle.content]
                ).map((paragraph: string, idx: number) => (
                  <p key={idx} className="leading-relaxed">
                    {paragraph}
                  </p>
                ))}
              </div>

              {readingArticle.references && (
                <div className="flex flex-wrap gap-1.5 pt-6 border-t border-slate-100 dark:border-emerald-900">
                  {readingArticle.references.map((refItem: string) => (
                    <span
                      key={refItem}
                      className="text-[11px] px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-emerald-900 text-slate-600 dark:text-emerald-300"
                    >
                      {refItem}
                    </span>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
