import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Baby,
  Sparkles,
  BookOpen,
  Star,
  CheckCircle,
  HelpCircle,
  Volume2,
  Heart,
  Smile,
} from 'lucide-react';

export const KidsView: React.FC = () => {
  const { kidsStories, playAudioTrack, showToast } = useApp();
  const [activeTab, setActiveTab] = useState<'stories' | 'alphabet' | 'manners' | 'quiz'>('stories');
  const [selectedStoryId, setSelectedStoryId] = useState<string>(kidsStories[0]?.id || '');
  const [kidsQuizScore, setKidsQuizScore] = useState<number>(0);
  const [kidsQuizCompleted, setKidsQuizCompleted] = useState<boolean>(false);
  const [selectedQuizAnswers, setSelectedQuizAnswers] = useState<Record<number, number>>({});

  const selectedStory = kidsStories.find((s) => s.id === selectedStoryId) || kidsStories[0];

  // Arabic Alphabet interactive dataset
  const alphabet = [
    { letter: 'أ', name: 'Alif', trans: 'A', example: 'أَسَد (Lion)' },
    { letter: 'ب', name: 'Baa', trans: 'B', example: 'بَيْت (House)' },
    { letter: 'ت', name: 'Taa', trans: 'T', example: 'تَمْر (Dates)' },
    { letter: 'ث', name: 'Thaa', trans: 'Th', example: 'ثَعْلَب (Fox)' },
    { letter: 'ج', name: 'Jeem', trans: 'J', example: 'جَمَل (Camel)' },
    { letter: 'ح', name: 'Haa', trans: 'H', example: 'حَلِيب (Milk)' },
    { letter: 'خ', name: 'Khaa', trans: 'Kh', example: 'خُبْز (Bread)' },
    { letter: 'د', name: 'Daal', trans: 'D', example: 'دَفْتَر (Notebook)' },
    { letter: 'ذ', name: 'Dhaal', trans: 'Dh', example: 'ذَهَب (Gold)' },
    { letter: 'ر', name: 'Raa', trans: 'R', example: 'رُمَّان (Pomegranate)' },
    { letter: 'ز', name: 'Zay', trans: 'Z', example: 'زَيْتُون (Olive)' },
    { letter: 'س', name: 'Seen', trans: 'S', example: 'سَمَك (Fish)' },
    { letter: 'ش', name: 'Sheen', trans: 'Sh', example: 'شَمْس (Sun)' },
    { letter: 'ص', name: 'Saad', trans: 'S', example: 'صُبْح (Morning)' },
    { letter: 'ض', name: 'Daad', trans: 'D', example: 'ضَوْء (Light)' },
    { letter: 'ط', name: 'Taa', trans: 'T', example: 'طَيْر (Bird)' },
    { letter: 'ظ', name: 'Dhaa', trans: 'Dh', example: 'ظِلّ (Shadow)' },
    { letter: 'ع', name: 'Ayn', trans: '‘A', example: 'عَيْن (Eye)' },
    { letter: 'غ', name: 'Ghayn', trans: 'Gh', example: 'غَابَة (Forest)' },
    { letter: 'ف', name: 'Faa', trans: 'F', example: 'فِيل (Elephant)' },
    { letter: 'ق', name: 'Qaaf', trans: 'Q', example: 'قَمَر (Moon)' },
    { letter: 'ك', name: 'Kaaf', trans: 'K', example: 'كِتَاب (Book)' },
    { letter: 'ل', name: 'Laam', trans: 'L', example: 'لَيْل (Night)' },
    { letter: 'م', name: 'Meem', trans: 'M', example: 'مَاء (Water)' },
    { letter: 'ن', name: 'Noon', trans: 'N', example: 'نَجْم (Star)' },
    { letter: 'هـ', name: 'Haa', trans: 'H', example: 'هِلال (Crescent)' },
    { letter: 'و', name: 'Waaw', trans: 'W', example: 'وَرْدَة (Rose)' },
    { letter: 'ي', name: 'Yaa', trans: 'Y', example: 'يَد (Hand)' },
  ];

  const kidsQuizQuestions = [
    {
      q: "What do we say before eating or drinking?",
      options: ["Alhamdulillah", "Bismillah", "Allahu Akbar"],
      correct: 1,
    },
    {
      q: "Who was the prophet whose ark saved the believers from the great flood?",
      options: ["Prophet Ibrahim (AS)", "Prophet Nuh (AS)", "Prophet Musa (AS)"],
      correct: 1,
    },
    {
      q: "How many daily obligatory prayers are there for Muslims?",
      options: ["Three (3)", "Five (5)", "Seven (7)"],
      correct: 1,
    },
    {
      q: "Smiling in the face of your brother or sister is counted as...",
      options: ["Charity (Sadaqah)", "Play", "Nothing"],
      correct: 0,
    },
  ];

  const handleSelectQuizAnswer = (qIdx: number, optIdx: number) => {
    setSelectedQuizAnswers((prev) => ({ ...prev, [qIdx]: optIdx }));
  };

  const handleFinishKidsQuiz = () => {
    let score = 0;
    kidsQuizQuestions.forEach((q, idx) => {
      if (selectedQuizAnswers[idx] === q.correct) score++;
    });
    setKidsQuizScore(score);
    setKidsQuizCompleted(true);
    showToast(`Great job! You earned ${score} Golden Stars! ⭐`, 'success');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Playful Header Banner */}
      <div className="bg-gradient-to-r from-amber-600 via-amber-700 to-emerald-800 text-white rounded-2xl p-6 sm:p-8 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-1.5 text-amber-200 text-xs font-bold uppercase font-cinzel">
            <Baby className="w-4 h-4" />
            <span>Kids Islamic Sanctuary</span>
          </div>
          <h1 className="text-2xl sm:text-4xl font-serif font-bold text-white">
            Stories, Good Manners & Fun Quizzes!
          </h1>
          <p className="text-xs sm:text-sm text-amber-100 font-light max-w-xl">
            Gentle, heartwarming stories of the beloved Prophets, Arabic alphabet flashcards, daily sunnah manners, and star badges for young believers.
          </p>
        </div>

        <div className="flex items-center gap-2 bg-white/10 px-4 py-2 rounded-xl backdrop-blur-md border border-white/20">
          <Star className="w-5 h-5 text-amber-300 fill-amber-300 animate-bounce" />
          <span className="text-xs font-bold text-white">Young Seeker of Knowledge</span>
        </div>
      </div>

      {/* Tabs Switcher */}
      <div className="flex items-center gap-2 border-b border-slate-200 dark:border-emerald-800/60 pb-2 overflow-x-auto text-xs">
        {[
          { id: 'stories', label: 'Stories of the Prophets', icon: BookOpen },
          { id: 'alphabet', label: 'Arabic Alphabet Flashcards', icon: Sparkles },
          { id: 'manners', label: 'Golden Islamic Manners', icon: Smile },
          { id: 'quiz', label: 'Kids Star Quiz', icon: Star },
        ].map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl font-bold whitespace-nowrap transition ${
                activeTab === tab.id
                  ? 'bg-amber-500 text-slate-950 shadow-md'
                  : 'bg-white dark:bg-emerald-950 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-emerald-800 hover:bg-slate-50'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab 1: Stories */}
      {activeTab === 'stories' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start animate-in fade-in">
          {/* Story selector sidebar */}
          <div className="lg:col-span-4 space-y-3">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white font-serif">
              Select a Story
            </h3>
            {kidsStories.map((story) => (
              <div
                key={story.id}
                onClick={() => setSelectedStoryId(story.id)}
                className={`p-4 rounded-xl border transition cursor-pointer flex items-center justify-between ${
                  selectedStoryId === story.id
                    ? 'bg-emerald-50 dark:bg-emerald-900/40 border-emerald-500 shadow-sm ring-1 ring-emerald-500'
                    : 'bg-white dark:bg-emerald-950/40 border-slate-200 dark:border-emerald-800 hover:bg-slate-50'
                }`}
              >
                <div>
                  <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                    {story.title}
                  </h4>
                  <span className="text-[11px] text-amber-600 dark:text-amber-400 font-semibold">
                    {story.category}
                  </span>
                </div>
                <BookOpen className="w-4 h-4 text-slate-400" />
              </div>
            ))}
          </div>

          {/* Story Viewer Display */}
          <div className="lg:col-span-8 bg-white dark:bg-emerald-950/40 rounded-2xl p-6 sm:p-8 border border-slate-200 dark:border-emerald-800/40 shadow-sm space-y-6">
            <div className="p-6 rounded-2xl bg-gradient-to-r from-amber-500 to-emerald-700 text-white flex items-center justify-between">
              <div>
                <span className="text-xs uppercase font-bold text-amber-200 font-cinzel">
                  {selectedStory.category} · Stories of Wisdom
                </span>
                <h2 className="text-2xl font-serif font-bold text-white mt-1">
                  {selectedStory.title}
                </h2>
                <p className="text-xs text-amber-100 font-arabic text-right mt-1">
                  {selectedStory.arabicName}
                </p>
              </div>
              <div className="text-4xl">🌟</div>
            </div>

            <div className="p-4 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/40 flex items-center gap-3">
              <Sparkles className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0" />
              <div>
                <span className="text-xs font-bold text-amber-900 dark:text-amber-200 block">
                  Moral Lesson for Life:
                </span>
                <p className="text-xs text-amber-800 dark:text-amber-300">{selectedStory.moral}</p>
              </div>
            </div>

            <div className="text-xs sm:text-sm leading-relaxed text-slate-700 dark:text-slate-200 space-y-4 font-light">
              <p>{selectedStory.fullStory}</p>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Alphabet Flashcards */}
      {activeTab === 'alphabet' && (
        <div className="space-y-6 animate-in fade-in">
          <div>
            <h2 className="text-xl font-bold font-serif text-slate-900 dark:text-white">
              Arabic Alphabet Flashcards (الحروف العربية)
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Tap any letter to read its name, pronunciation, and sample Islamic vocabulary word!
            </p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-3">
            {alphabet.map((item) => (
              <div
                key={item.name}
                className="p-4 bg-white dark:bg-emerald-950/40 rounded-2xl border border-slate-200 dark:border-emerald-800/40 shadow-sm hover:shadow-lg hover:-translate-y-1 transition text-center space-y-2 cursor-pointer group"
              >
                <span className="font-arabic text-4xl font-bold text-emerald-800 dark:text-amber-300 block group-hover:scale-110 transition">
                  {item.letter}
                </span>
                <span className="font-bold text-xs text-slate-800 dark:text-slate-100 block">
                  {item.name} ({item.trans})
                </span>
                <span className="text-[11px] text-slate-500 dark:text-slate-400 block font-arabic truncate">
                  {item.example}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 3: Manners */}
      {activeTab === 'manners' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 animate-in fade-in">
          <div className="p-6 bg-white dark:bg-emerald-950/40 rounded-2xl border border-slate-200 dark:border-emerald-800 space-y-3">
            <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center font-bold">
              1
            </div>
            <h3 className="font-bold text-base text-slate-900 dark:text-white">Eating with the Right Hand</h3>
            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              Say <em>Bismillah</em> before eating, use your right hand, and eat from what is directly in front of you. Finish with <em>Alhamdulillah</em>!
            </p>
          </div>

          <div className="p-6 bg-white dark:bg-emerald-950/40 rounded-2xl border border-slate-200 dark:border-emerald-800 space-y-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">
              2
            </div>
            <h3 className="font-bold text-base text-slate-900 dark:text-white">Smiling & Spreading Peace</h3>
            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              Greet your family and friends with <em>As-Salamu Alaykum</em> (Peace be upon you). Smiling brings joy and earns heavenly rewards!
            </p>
          </div>

          <div className="p-6 bg-white dark:bg-emerald-950/40 rounded-2xl border border-slate-200 dark:border-emerald-800 space-y-3">
            <div className="w-10 h-10 rounded-xl bg-teal-100 text-teal-700 flex items-center justify-center font-bold">
              3
            </div>
            <h3 className="font-bold text-base text-slate-900 dark:text-white">Honoring Parents & Teachers</h3>
            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              Always listen gently to your mother and father, say kind words, help around the home, and say prayers for their longevity and happiness.
            </p>
          </div>
        </div>
      )}

      {/* Tab 4: Kids Quiz */}
      {activeTab === 'quiz' && (
        <div className="max-w-2xl mx-auto bg-white dark:bg-emerald-950/40 rounded-2xl p-6 sm:p-8 border border-slate-200 dark:border-emerald-800 shadow-xl space-y-6 animate-in fade-in">
          <div className="text-center space-y-1">
            <span className="text-xs uppercase font-bold text-amber-600 dark:text-amber-400 font-cinzel">
              Interactive Fun Assessment
            </span>
            <h2 className="text-2xl font-serif font-bold text-slate-900 dark:text-white">
              The Little Believer's Star Challenge! ⭐
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Answer the questions correctly to earn your stars!
            </p>
          </div>

          <div className="space-y-4">
            {kidsQuizQuestions.map((item, qIdx) => (
              <div
                key={qIdx}
                className="p-4 rounded-xl bg-slate-50 dark:bg-emerald-900/20 border border-slate-200 dark:border-emerald-800 space-y-2"
              >
                <h4 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
                  {qIdx + 1}. {item.q}
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1">
                  {item.options.map((opt, optIdx) => {
                    const isSelected = selectedQuizAnswers[qIdx] === optIdx;
                    return (
                      <button
                        key={optIdx}
                        disabled={kidsQuizCompleted}
                        onClick={() => handleSelectQuizAnswer(qIdx, optIdx)}
                        className={`p-2 rounded-lg text-xs font-semibold border transition ${
                          isSelected
                            ? 'bg-amber-400 text-slate-950 border-amber-300'
                            : 'bg-white dark:bg-emerald-950 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-emerald-800 hover:bg-slate-100'
                        }`}
                      >
                        {opt}
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>

          <div className="pt-4 border-t border-slate-100 dark:border-emerald-900/50">
            {!kidsQuizCompleted ? (
              <button
                onClick={handleFinishKidsQuiz}
                className="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md transition"
              >
                Check My Star Score!
              </button>
            ) : (
              <div className="text-center space-y-3 p-4 bg-emerald-50 dark:bg-emerald-900/40 rounded-xl border border-emerald-300">
                <span className="text-3xl block">🌟 🌟 🌟</span>
                <h3 className="font-bold text-base text-emerald-900 dark:text-amber-300">
                  You earned {kidsQuizScore} out of {kidsQuizQuestions.length} Stars!
                </h3>
                <button
                  onClick={() => {
                    setKidsQuizCompleted(false);
                    setSelectedQuizAnswers({});
                  }}
                  className="px-4 py-1.5 rounded-lg bg-slate-800 text-white text-xs font-semibold"
                >
                  Play Again
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
