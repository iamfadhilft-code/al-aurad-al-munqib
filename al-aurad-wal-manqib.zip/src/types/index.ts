export type NavPage =
  | 'home'
  | 'quran'
  | 'hadith'
  | 'worship'
  | 'devotional'
  | 'knowledge'
  | 'learning'
  | 'kids'
  | 'library'
  | 'dashboard'
  | 'admin';

export type Language = 'en' | 'ar' | 'ml';
export type ThemeMode = 'light' | 'dark' | 'sepia';

export * from './storage';

export type ContentCategory =
  | 'quran'
  | 'hadith'
  | 'maulid'
  | 'swalath'
  | 'baith'
  | 'ratheeb'
  | 'dua'
  | 'dhikr'
  | 'article'
  | 'course'
  | 'media';

export type ContentStatus = 'published' | 'draft' | 'review' | 'archived';

export interface Ayah {
  number: number;
  surahNumber: number;
  arabic: string;
  transliteration: string;
  translation: string;
  tafsir?: string;
  audioUrl?: string;
}

export interface Surah {
  number: number;
  nameArabic: string;
  nameEnglish: string;
  nameTranslation: string;
  revelationType: 'Meccan' | 'Medinan';
  ayahCount: number;
  ayahs: Ayah[];
}

export interface Hadith {
  id: string;
  collection: 'Bukhari' | 'Muslim' | 'Abu Dawud' | 'Nawawi 40' | 'Riyad as-Salihin';
  bookNumber?: number;
  hadithNumber: number | string;
  chapter: string;
  narrator: string;
  arabic: string;
  translation: string;
  grade: 'Sahih' | 'Hasan' | 'Muttafaq Alayh';
  reference: string;
}

export interface DevotionalItem {
  id: string;
  type: 'maulid' | 'swalath' | 'baith' | 'ratheeb' | 'dua' | 'dhikr';
  title: string;
  arabicTitle: string;
  author?: string;
  language: string;
  description: string;
  category: string;
  arabicText: string;
  transliteration?: string;
  translation?: string;
  targetCount?: number;
  audioUrl?: string;
  pdfUrl?: string;
  featured?: boolean;
  status: ContentStatus;
  createdAt: string;
  tags?: string[];
  beneficialVirtues?: string;
}

export interface Article {
  id: string;
  title: string;
  arabicTitle?: string;
  category: 'Spiritual' | 'Fiqh' | 'History' | 'Seerah' | 'Contemporary';
  author: string;
  scholarId?: string;
  readingTimeMinutes: number;
  publishDate: string;
  coverImage?: string;
  summary: string;
  content: string[];
  references?: string[];
  status: ContentStatus;
  featured?: boolean;
}

export interface Scholar {
  id: string;
  name: string;
  arabicName: string;
  era: string;
  bio: string;
  specialization: string;
  famousWorks: string[];
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface Lesson {
  id: string;
  title: string;
  duration: string;
  completed?: boolean;
  content: string;
  arabicSnippet?: string;
}

export interface Course {
  id: string;
  title: string;
  arabicTitle?: string;
  instructor: string;
  level: 'Beginner' | 'Intermediate' | 'Advanced';
  duration: string;
  description: string;
  lessons: Lesson[];
  quiz?: QuizQuestion[];
  badgeTitle: string;
  enrolled?: boolean;
  progress?: number;
  coverGradient: string;
}

export interface KidStory {
  id: string;
  title: string;
  arabicName: string;
  category: 'Prophets' | 'Good Manners' | 'Quran Stories' | 'Animals in Quran';
  summary: string;
  fullStory: string;
  moral: string;
  iconName: string;
  quizQuestion?: {
    question: string;
    options: string[];
    correctIndex: number;
  };
}

export interface MediaDocument {
  id: string;
  title: string;
  type: 'pdf' | 'audio' | 'image';
  category: ContentCategory;
  fileSize: string;
  author?: string;
  url: string;
  downloadCount: number;
  associatedTitle?: string;
  uploadedAt: string;
}

export interface AuditLog {
  id: string;
  adminName: string;
  action: 'Created' | 'Updated' | 'Published' | 'Unpublished' | 'Deleted';
  entity: string;
  entityTitle: string;
  timestamp: string;
}

export interface PrayerTimesData {
  city: string;
  country: string;
  dateStr: string;
  hijriDateStr: string;
  times: {
    Fajr: string;
    Sunrise: string;
    Dhuhr: string;
    Asr: string;
    Maghrib: string;
    Isha: string;
  };
}

export interface ActiveAudioTrack {
  id: string;
  title: string;
  subtitle: string;
  arabicTitle?: string;
  audioUrl: string;
  category: string;
}

export interface UserNote {
  id: string;
  title: string;
  surahOrTopic: string;
  content: string;
  date: string;
}

export interface BookmarkItem {
  id: string;
  type: 'quran' | 'hadith' | 'devotional' | 'article';
  title: string;
  subtitle: string;
  pathOrRef: string;
  date: string;
}

export interface DailyAuradItem {
  id: string;
  title: string;
  arabicTitle: string;
  malayalamTitle?: string;
  category: 'ratheeb' | 'wird' | 'salawat' | 'istighfar' | 'quran' | 'tahlil';
  recommendedTime: 'Morning' | 'Evening' | 'After Salah' | 'Night' | 'Anytime';
  targetCount: number;
  virtueDescription?: string;
}

export interface DailyDhikrProgress {
  id: string; // e.g. "dhikr-2026-09-18" or "dhikr-{userId}-2026-09-18"
  userId?: string;
  userEmail?: string;
  date: string; // YYYY-MM-DD
  hijriDate?: string;
  counts: Record<string, number>; // itemId -> count
  completed: Record<string, boolean>; // itemId -> boolean
  totalDhikrCount: number;
  completedAuradCount: number;
  notes?: string;
  updatedAt: string;
}
