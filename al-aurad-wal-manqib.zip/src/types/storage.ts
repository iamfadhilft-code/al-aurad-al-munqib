import { LucideIcon } from 'lucide-react';

export type ManagedCategory =
  | 'quran-pdf'          // 📖 Qur’an PDFs
  | 'quran-translation'  // 📖 Qur’an translations
  | 'tafsir-pdf'         // 📚 Tafsir PDFs
  | 'maulid-pdf'         // 🕌 Maulid PDFs
  | 'swalath-pdf'        // 🤲 Swalath PDFs
  | 'baith-mala-pdf'     // 📜 Baith / Mala PDFs
  | 'ratheeb-pdf'        // 🕋 Ratheeb PDFs
  | 'dua-dhikr-pdf'      // 🤲 Dua & Dhikr PDFs
  | 'islamic-books'      // 📚 Islamic books
  | 'course-materials'   // 🎓 Course materials
  | 'kids-materials'     // 👶 Kids materials
  | 'articles-resources' // 📝 Articles/resources
  | 'audio-files'        // 🎧 Audio files
  | 'images'             // 🖼️ Images
  | 'videos'             // 🎥 Videos
  | 'documents';         // 📄 Documents

export type FileType = 'pdf' | 'audio' | 'image' | 'video' | 'doc';

export interface FileVersion {
  versionNumber: number;
  fileName: string;
  storagePath: string; // URL, Data URL (base64), or blob
  fileSize: string;
  updatedDate: string;
  uploadedBy: string;
  changeNote?: string;
  statusAtTime?: 'draft' | 'published';
}

export interface ManagedFileItem {
  id: string;
  title: string;
  titleArabic?: string;
  titleMalayalam?: string;
  description: string;
  category: ManagedCategory;
  language: 'en' | 'ar' | 'ml' | 'all';
  author: string;
  
  // Storage layer
  storagePath: string; // Actual file Data URL (base64) or cloud storage URL
  fileName: string;
  fileType: FileType;
  mimeType: string;
  fileSize: string;

  // Database layer
  version: number;
  uploadedBy: string;
  uploadDate: string;
  updatedDate: string;
  status: 'draft' | 'published';
  publicVisibility: boolean;

  // History & rollback
  previousVersions: FileVersion[];
  lastReplacedNote?: string;

  // Extensible metadata
  metadata?: {
    pageCount?: number;
    duration?: string;
    associatedItemSlug?: string; // e.g. "maulid-manqoos", "ratheeb-haddad"
    publisher?: string;
    edition?: string;
    downloadCount?: number;
    tags?: string[];
  };
}

export interface CategoryDefinition {
  id: ManagedCategory;
  emoji: string;
  defaultFileType: FileType;
  allowedExtensions: string[];
  titleEn: string;
  titleMl: string;
  titleAr: string;
  descEn: string;
  descMl: string;
  descAr: string;
}
