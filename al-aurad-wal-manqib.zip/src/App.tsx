import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/common/Navbar';
import { BottomNav } from './components/common/BottomNav';
import { AudioPlayerBar } from './components/common/AudioPlayerBar';
import { GlobalSearchModal } from './components/common/GlobalSearchModal';
import { PdfViewerModal } from './components/common/PdfViewerModal';
import { CertificateModal } from './components/common/CertificateModal';
import { Toast } from './components/common/Toast';
import { Footer } from './components/common/Footer';
import { NoorChatModal } from './components/chat/NoorChatModal';
import { Sparkles, Bot } from 'lucide-react';

// Views
import { HomeView } from './components/home/HomeView';
import { QuranView } from './components/quran/QuranView';
import { HadithView } from './components/hadith/HadithView';
import { WorshipView } from './components/worship/WorshipView';
import { DevotionalView } from './components/devotional/DevotionalView';
import { LearningView } from './components/learning/LearningView';
import { KidsView } from './components/kids/KidsView';
import { KnowledgeView } from './components/knowledge/KnowledgeView';
import { DashboardView } from './components/dashboard/DashboardView';
import { AdminView } from './components/admin/AdminView';
import { PublicLibraryView } from './components/library/PublicLibraryView';

const MainAppContent: React.FC = () => {
  const { activePage, isChatOpen, openChat, closeChat, language } = useApp();

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 font-sans selection:bg-amber-400 selection:text-slate-950 transition-colors duration-200 pb-24 xl:pb-20">
      {/* Top Universal Navbar */}
      <Navbar />

      {/* Main Viewport Container */}
      <main className="flex-1 w-full">
        {activePage === 'home' && <HomeView />}
        {activePage === 'quran' && <QuranView />}
        {activePage === 'hadith' && <HadithView />}
        {activePage === 'worship' && <WorshipView />}
        {activePage === 'devotional' && <DevotionalView />}
        {activePage === 'library' && <PublicLibraryView />}
        {activePage === 'learning' && <LearningView />}
        {activePage === 'kids' && <KidsView />}
        {activePage === 'knowledge' && <KnowledgeView />}
        {activePage === 'dashboard' && <DashboardView />}
        {activePage === 'admin' && <AdminView />}
      </main>

      {/* Floating Noor AI Scholar Trigger */}
      <div className="fixed bottom-20 right-4 sm:bottom-24 sm:right-6 z-40">
        <button
          onClick={openChat}
          className="group flex items-center gap-2 px-3.5 py-2.5 sm:px-4 sm:py-3 rounded-full bg-gradient-to-r from-emerald-800 to-teal-900 text-white hover:from-emerald-700 hover:to-teal-800 shadow-xl shadow-emerald-950/30 border border-emerald-500/40 hover:scale-105 active:scale-95 transition-all"
          title="Open Noor AI Scholar (Multi-turn chat & Maps Grounding)"
        >
          <div className="w-6 h-6 rounded-full bg-amber-400/20 text-amber-300 flex items-center justify-center">
            <Sparkles className="w-3.5 h-3.5 animate-pulse" />
          </div>
          <div className="text-left">
            <div className="text-xs font-bold leading-tight flex items-center gap-1">
              <span>Noor AI</span>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
            </div>
            <div className="text-[10px] text-emerald-200 hidden sm:block">
              {language === 'ml' ? 'ഇസ്ലാമിക് സഹായം' : language === 'ar' ? 'المساعد الذكي' : 'Scholar & Maps'}
            </div>
          </div>
        </button>
      </div>

      {/* Platform Global Footer */}
      <Footer />

      {/* Sticky Global Components */}
      <AudioPlayerBar />
      <BottomNav />
      <GlobalSearchModal />
      <NoorChatModal isOpen={isChatOpen} onClose={closeChat} />
      <PdfViewerModal />
      <CertificateModal />
      <Toast />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainAppContent />
    </AppProvider>
  );
}
